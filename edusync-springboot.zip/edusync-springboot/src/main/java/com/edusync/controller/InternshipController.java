package com.edusync.controller;

import com.edusync.model.Internship;
import com.edusync.repository.InternshipRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/internships")
@RequiredArgsConstructor
public class InternshipController {
    private final InternshipRepository internRepo;

    @GetMapping
    public ResponseEntity<List<Internship>> getAll(@RequestParam(required=false) String dept) {
        if (dept != null) return ResponseEntity.ok(internRepo.findByDeptEligible(dept));
        return ResponseEntity.ok(internRepo.findByIsActiveTrue());
    }

    @PostMapping
    public ResponseEntity<Internship> create(@RequestBody Internship internship) {
        return ResponseEntity.status(201).body(internRepo.save(internship));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        internRepo.deleteById(id);
        return ResponseEntity.ok("Internship deleted");
    }
}
