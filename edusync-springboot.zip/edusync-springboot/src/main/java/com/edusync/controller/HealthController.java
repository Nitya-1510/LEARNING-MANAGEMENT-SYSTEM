package com.edusync.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
public class HealthController {

    @GetMapping("/")
    public ResponseEntity<Map<String,Object>> health() {
        Map<String,Object> response = new LinkedHashMap<>();
        response.put("message", "🎓 EduSync Spring Boot API is running!");
        response.put("version", "1.0.0");
        response.put("status", "OK");
        response.put("database", "MySQL Connected ✅");
        response.put("endpoints", Map.of(
            "auth",        "POST /api/auth/login | POST /api/auth/register",
            "departments", "GET  /api/departments | GET /api/departments/{code}",
            "subjects",    "GET  /api/departments/{code}/subjects",
            "assignments", "GET  /api/assignments?dept=CSE",
            "exams",       "GET  /api/exams?dept=CSE",
            "internships", "GET  /api/internships?dept=CSE"
        ));
        return ResponseEntity.ok(response);
    }

    @GetMapping("/api/health")
    public ResponseEntity<String> ping() {
        return ResponseEntity.ok("✅ EduSync Spring Boot is healthy!");
    }
}
