package com.edusync.controller;

import com.edusync.model.Exam;
import com.edusync.repository.ExamRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/exams")
@RequiredArgsConstructor
public class ExamController {
    private final ExamRepository examRepo;

    @GetMapping
    public ResponseEntity<List<Exam>> getAll(@RequestParam(required=false) String dept) {
        if (dept != null) return ResponseEntity.ok(examRepo.findByDept(dept));
        return ResponseEntity.ok(examRepo.findAll());
    }

    @PostMapping
    public ResponseEntity<Exam> create(@RequestBody Exam exam) {
        return ResponseEntity.status(201).body(examRepo.save(exam));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        examRepo.deleteById(id);
        return ResponseEntity.ok("Exam deleted");
    }
}
