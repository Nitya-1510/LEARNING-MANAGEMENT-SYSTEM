package com.edusync.controller;

import com.edusync.model.Assignment;
import com.edusync.repository.AssignmentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/assignments")
@RequiredArgsConstructor
public class AssignmentController {
    private final AssignmentRepository assignRepo;

    @GetMapping
    public ResponseEntity<List<Assignment>> getAll(@RequestParam(required=false) String dept) {
        if (dept != null) return ResponseEntity.ok(assignRepo.findByDept(dept));
        return ResponseEntity.ok(assignRepo.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getOne(@PathVariable Long id) {
        return assignRepo.findById(id).map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Assignment> create(@RequestBody Assignment assignment) {
        return ResponseEntity.status(201).body(assignRepo.save(assignment));
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody Assignment assignment) {
        return assignRepo.findById(id).map(existing -> {
            assignment.setId(id);
            return ResponseEntity.ok(assignRepo.save(assignment));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        assignRepo.deleteById(id);
        return ResponseEntity.ok("Assignment deleted");
    }

    @PutMapping("/{id}/submit")
    public ResponseEntity<?> submit(@PathVariable Long id) {
        return assignRepo.findById(id).map(a -> {
            a.setStatus(Assignment.Status.SUBMITTED);
            return ResponseEntity.ok(assignRepo.save(a));
        }).orElse(ResponseEntity.notFound().build());
    }
}
