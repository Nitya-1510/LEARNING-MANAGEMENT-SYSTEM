package com.edusync.controller;

import com.edusync.model.*;
import com.edusync.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/departments")
@RequiredArgsConstructor
public class DepartmentController {
    private final DepartmentRepository deptRepo;
    private final SubjectRepository subjectRepo;
    private final ExamRepository examRepo;
    private final InternshipRepository internRepo;

    @GetMapping
    public ResponseEntity<List<Department>> getAll() {
        return ResponseEntity.ok(deptRepo.findByIsActiveTrue());
    }

    @GetMapping("/{code}")
    public ResponseEntity<?> getByCode(@PathVariable String code) {
        return deptRepo.findByCode(code.toUpperCase())
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/{code}/subjects")
    public ResponseEntity<List<Subject>> getSubjects(
            @PathVariable String code,
            @RequestParam(defaultValue="5") Integer sem) {
        return ResponseEntity.ok(subjectRepo.findByDeptAndSem(code.toUpperCase(), sem));
    }

    @GetMapping("/{code}/exams")
    public ResponseEntity<List<Exam>> getExams(@PathVariable String code) {
        return ResponseEntity.ok(examRepo.findByDeptOrderByDaysLeftAsc(code.toUpperCase()));
    }

    @GetMapping("/{code}/internships")
    public ResponseEntity<List<Internship>> getInternships(@PathVariable String code) {
        return ResponseEntity.ok(internRepo.findByDeptEligible(code.toUpperCase()));
    }

    @PostMapping
    public ResponseEntity<Department> create(@RequestBody Department dept) {
        return ResponseEntity.status(201).body(deptRepo.save(dept));
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody Department dept) {
        return deptRepo.findById(id).map(existing -> {
            dept.setId(id);
            return ResponseEntity.ok(deptRepo.save(dept));
        }).orElse(ResponseEntity.notFound().build());
    }
}
