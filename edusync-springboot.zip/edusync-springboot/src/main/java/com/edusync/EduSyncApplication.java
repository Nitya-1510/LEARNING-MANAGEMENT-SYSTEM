package com.edusync;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EduSyncApplication {
    public static void main(String[] args) {
        SpringApplication.run(EduSyncApplication.class, args);
        System.out.println("🎓 EduSync Spring Boot API is running!");
        System.out.println("🚀 Server → http://localhost:8080");
        System.out.println("🗄️  Database → MySQL Connected");
    }
}
