package com.edusync.model;
import jakarta.persistence.*;
import lombok.*;

@Entity @Table(name="exams")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Exam {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    @Column(nullable=false) private String subject;
    private String code;
    private String dept;
    private String examDate;
    private String examTime;
    private String hall;
    private String duration;
    private Integer daysLeft;
    private String color;
    @Column(columnDefinition="TEXT") private String syllabus;
}
