package com.edusync.model;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity @Table(name="assignments")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Assignment {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    @Column(nullable=false) private String title;
    private String subject;
    private String code;
    private String dept;
    private String dueDate;
    private Integer daysLeft;
    private Integer maxMarks;
    @Enumerated(EnumType.STRING)
    private Status status = Status.PENDING;
    @Column(columnDefinition="TEXT") private String questions;
    @Column(updatable=false) private LocalDateTime createdAt = LocalDateTime.now();
    public enum Status { PENDING, SUBMITTED, OVERDUE }
}
