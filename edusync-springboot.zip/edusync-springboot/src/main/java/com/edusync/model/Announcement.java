package com.edusync.model;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity @Table(name="announcements")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Announcement {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    @Column(nullable=false) private String title;
    @Column(columnDefinition="TEXT") private String message;
    private String type;
    private String priority;
    @Column(updatable=false) private LocalDateTime createdAt = LocalDateTime.now();
}
