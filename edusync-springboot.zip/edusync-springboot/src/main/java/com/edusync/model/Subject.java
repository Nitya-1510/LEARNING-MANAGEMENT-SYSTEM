package com.edusync.model;
import jakarta.persistence.*;
import lombok.*;

@Entity @Table(name="subjects")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Subject {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    @Column(nullable=false) private String name;
    @Column(nullable=false) private String code;
    @Column(nullable=false) private String dept;
    private Integer sem;
    private Integer credits;
    private String type;
    private String faculty;
    private String color;
    private String syllabus;
}
