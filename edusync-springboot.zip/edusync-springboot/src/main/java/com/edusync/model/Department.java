package com.edusync.model;
import jakarta.persistence.*;
import lombok.*;

@Entity @Table(name="departments")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Department {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    @Column(nullable=false) private String name;
    @Column(nullable=false, unique=true) private String code;
    private String shortName;
    private String hod;
    private Integer totalStudents;
    private String color;
    private String icon;
    private String category;
    private Integer semesters = 8;
    private Boolean isActive = true;
}
