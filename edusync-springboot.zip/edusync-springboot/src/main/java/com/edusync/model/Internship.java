package com.edusync.model;
import jakarta.persistence.*;
import lombok.*;

@Entity @Table(name="internships")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Internship {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    @Column(nullable=false) private String company;
    private String logo;
    private String color;
    private String ctc;
    private String role;
    private String deptEligible;
    private String skills;
    private String type;
    private String mode;
    private String duration;
    private String location;
    private String deadline;
    private String rounds;
    @Column(columnDefinition="TEXT") private String description;
    private Boolean isActive = true;
}
