package com.edusync.model;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity @Table(name="users")
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class User {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    @Column(nullable=false) private String name;
    @Column(nullable=false, unique=true) private String email;
    @Column(nullable=false) private String password;
    @Enumerated(EnumType.STRING) @Column(nullable=false)
    private Role role = Role.STUDENT;
    private String dept;
    private String deptCode;
    private Integer sem = 5;
    private String section = "A";
    private String reg;
    private Double cgpa = 0.0;
    private String phone;
    @Column(updatable=false) private LocalDateTime createdAt = LocalDateTime.now();
    public enum Role { STUDENT, ADMIN }
}
