package com.edusync.dto;
import com.edusync.model.User;
import lombok.*;
@Data @AllArgsConstructor @NoArgsConstructor
public class AuthResponse {
    private String token;
    private String type = "Bearer";
    private User user;
    private String message;
}
