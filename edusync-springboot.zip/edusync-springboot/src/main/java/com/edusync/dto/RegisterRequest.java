package com.edusync.dto;
import lombok.*;
@Data @AllArgsConstructor @NoArgsConstructor
public class RegisterRequest {
    private String name;
    private String email;
    private String password;
    private String dept;
    private String deptCode;
    private Integer sem;
    private String reg;
}
