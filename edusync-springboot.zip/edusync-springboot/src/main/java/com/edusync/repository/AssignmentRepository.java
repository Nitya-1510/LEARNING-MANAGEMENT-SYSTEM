package com.edusync.repository;
import com.edusync.model.Assignment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface AssignmentRepository extends JpaRepository<Assignment, Long> {
    List<Assignment> findByDept(String dept);
    List<Assignment> findByStatus(Assignment.Status status);
}
