package com.edusync.repository;
import com.edusync.model.Exam;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ExamRepository extends JpaRepository<Exam, Long> {
    List<Exam> findByDept(String dept);
    List<Exam> findByDeptOrderByDaysLeftAsc(String dept);
}
