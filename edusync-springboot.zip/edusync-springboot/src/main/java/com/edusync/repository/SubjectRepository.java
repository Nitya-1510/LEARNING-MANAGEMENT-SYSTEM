package com.edusync.repository;
import com.edusync.model.Subject;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface SubjectRepository extends JpaRepository<Subject, Long> {
    List<Subject> findByDept(String dept);
    List<Subject> findByDeptAndSem(String dept, Integer sem);
}
