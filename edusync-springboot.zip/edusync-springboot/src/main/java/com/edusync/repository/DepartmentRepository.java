package com.edusync.repository;
import com.edusync.model.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface DepartmentRepository extends JpaRepository<Department, Long> {
    Optional<Department> findByCode(String code);
    List<Department> findByCategory(String category);
    List<Department> findByIsActiveTrue();
}
