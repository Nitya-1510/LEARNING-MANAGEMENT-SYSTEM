package com.edusync.repository;
import com.edusync.model.Internship;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface InternshipRepository extends JpaRepository<Internship, Long> {
    @Query("SELECT i FROM Internship i WHERE i.deptEligible LIKE %:dept% AND i.isActive = true")
    List<Internship> findByDeptEligible(String dept);
    List<Internship> findByIsActiveTrue();
}
