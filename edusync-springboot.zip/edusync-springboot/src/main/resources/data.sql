-- ============================================
--  EduSync MySQL Database Seed
--  Run automatically when Spring Boot starts
-- ============================================

-- Departments
INSERT IGNORE INTO departments (name, code, short_name, hod, total_students, color, icon, category, semesters, is_active) VALUES
('Computer Science & Engineering',          'CSE',   'CSE',   'Dr. R. Kavitha',  240, '#6375ff', '💻', 'Engineering',  8, true),
('Information Technology',                  'IT',    'IT',    'Dr. S. Priya',    180, '#0891b2', '🌐', 'Engineering',  8, true),
('Electronics & Communication Engineering', 'ECE',   'ECE',   'Dr. P. Ramesh',   200, '#d97706', '📡', 'Engineering',  8, true),
('Electrical & Electronics Engineering',    'EEE',   'EEE',   'Dr. K. Murugan',  160, '#059669', '⚡', 'Engineering',  8, true),
('Mechanical Engineering',                  'MECH',  'MECH',  'Dr. V. Suresh',   220, '#be123c', '⚙️', 'Engineering',  8, true),
('Civil Engineering',                       'CIVIL', 'CIVIL', 'Dr. T. Anand',    160, '#92400e', '🏗️', 'Engineering',  8, true),
('Chemical Engineering',                    'CHEM',  'CHEM',  'Dr. M. Lakshmi',  120, '#065f46', '🧪', 'Engineering',  8, true),
('Aerospace Engineering',                   'AERO',  'AERO',  'Dr. N. Karthik',  100, '#1e3a8a', '✈️', 'Engineering',  8, true),
('VLSI Design',                             'VLSI',  'VLSI',  'Dr. A. Senthil',   60, '#7c3aed', '🔬', 'Specialised',  8, true),
('Artificial Intelligence & ML',            'AIML',  'AIML',  'Dr. B. Divya',    120, '#db2777', '🤖', 'Specialised',  8, true),
('Cyber Security',                          'CYS',   'CyS',   'Dr. C. Vijay',     80, '#dc2626', '🔐', 'Specialised',  8, true),
('Internet of Things',                      'IOT',   'IoT',   'Dr. D. Meena',     60, '#0284c7', '📶', 'Specialised',  8, true),
('Robotics & Automation',                   'ROB',   'ROB',   'Dr. E. Suresh',    60, '#ea580c', '🦾', 'Specialised',  8, true),
('Data Science',                            'DSC',   'DS',    'Dr. F. Nisha',    100, '#0891b2', '📊', 'Specialised',  8, true),
('Biotechnology',                           'BIO',   'BIO',   'Dr. G. Preethi',   80, '#16a34a', '🧬', 'Science',      8, true),
('Biomedical Engineering',                  'BME',   'BME',   'Dr. H. Saranya',   60, '#0d9488', '🏥', 'Science',      8, true),
('Physics',                                 'PHY',   'PHY',   'Dr. I. Ramesh',    60, '#4338ca', '⚛️', 'Science',      8, true),
('Mathematics',                             'MATH',  'MATH',  'Dr. J. Kavya',     60, '#0369a1', '📐', 'Science',      8, true),
('Master of Business Administration',       'MBA',   'MBA',   'Dr. K. Arjun',    120, '#b45309', '📈', 'Management',   4, true),
('Master of Computer Applications',         'MCA',   'MCA',   'Dr. L. Rekha',     60, '#6d28d9', '🖥️', 'Management',   6, true);

-- Users (passwords are BCrypt hashed)
-- aksh@2006 → $2a$10$...
INSERT IGNORE INTO users (name, email, password, role, dept, dept_code, sem, reg, cgpa) VALUES
('Akshaya Darshini', 'akshayadarshini.n@gmail.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhuG', 'ADMIN',   'Computer Science & Engineering', 'CSE',  5, 'CS21001', 8.7),
('Hari Vignesh',     'harivignesh@gmail.com',       '$2a$10$TKh8H1.PfBRlP3skYEZggeA2bsJxANKyO9SQJX.sRHFkYkiQGBg22', 'STUDENT', 'Computer Science & Engineering', 'CSE',  5, 'CS21002', 8.4),
('Priya Dharshini',  'priya.it@gmail.com',           '$2a$10$TKh8H1.PfBRlP3skYEZggeA2bsJxANKyO9SQJX.sRHFkYkiQGBg22', 'STUDENT', 'Information Technology',         'IT',   5, 'IT21001', 8.2),
('Rajan Kumar',      'rajan.ece@gmail.com',          '$2a$10$TKh8H1.PfBRlP3skYEZggeA2bsJxANKyO9SQJX.sRHFkYkiQGBg22', 'STUDENT', 'Electronics & Communication',    'ECE',  5, 'EC21001', 7.9),
('Kavya Senthil',    'kavya.vlsi@gmail.com',         '$2a$10$TKh8H1.PfBRlP3skYEZggeA2bsJxANKyO9SQJX.sRHFkYkiQGBg22', 'STUDENT', 'VLSI Design',                    'VLSI', 5, 'VL21001', 8.5),
('Rahul Sharma',     'rahul.aiml@gmail.com',         '$2a$10$TKh8H1.PfBRlP3skYEZggeA2bsJxANKyO9SQJX.sRHFkYkiQGBg22', 'STUDENT', 'Artificial Intelligence & ML',   'AIML', 5, 'AI21001', 8.9),
('Sneha Priya',      'sneha.bio@gmail.com',           '$2a$10$TKh8H1.PfBRlP3skYEZggeA2bsJxANKyO9SQJX.sRHFkYkiQGBg22', 'STUDENT', 'Biotechnology',                  'BIO',  5, 'BT21001', 8.0);

-- Subjects (CSE Sem 5)
INSERT IGNORE INTO subjects (name, code, dept, sem, credits, type, faculty, color) VALUES
('Data Structures & Algorithms', 'CS3401', 'CSE', 5, 4, 'Theory', 'Prof. A. Kumar',   '#6375ff'),
('Database Management Systems',  'CS3402', 'CSE', 5, 3, 'Theory', 'Prof. B. Priya',   '#0891b2'),
('Operating Systems',            'CS3403', 'CSE', 5, 4, 'Theory', 'Prof. C. Raj',     '#d97706'),
('Computer Networks',            'CS3404', 'CSE', 5, 3, 'Theory', 'Prof. D. Meena',   '#059669'),
('Probability & Statistics',     'MA3451', 'CSE', 5, 4, 'Theory', 'Prof. E. Sathya',  '#7c3aed'),
('DS & Algorithms Lab',          'CS3411', 'CSE', 5, 2, 'Lab',    'Prof. A. Kumar',   '#be123c'),
-- IT Sem 5
('Web Technology',               'IT3401', 'IT',  5, 4, 'Theory', 'Prof. F. Nisha',   '#6375ff'),
('Software Engineering',         'IT3402', 'IT',  5, 3, 'Theory', 'Prof. G. Senthil', '#0891b2'),
('Database Management',          'IT3403', 'IT',  5, 3, 'Theory', 'Prof. H. Radha',   '#d97706'),
('Computer Networks',            'IT3404', 'IT',  5, 4, 'Theory', 'Prof. I. Vijay',   '#059669'),
('Web Technology Lab',           'IT3411', 'IT',  5, 2, 'Lab',    'Prof. F. Nisha',   '#be123c'),
-- VLSI Sem 5
('VLSI Design & Technology',     'VL3501', 'VLSI',5, 4, 'Theory', 'Prof. A1. Senthil','#7c3aed'),
('Analog IC Design',             'VL3502', 'VLSI',5, 3, 'Theory', 'Prof. B1. Deepa',  '#6375ff'),
('FPGA & Embedded Systems',      'VL3503', 'VLSI',5, 4, 'Theory', 'Prof. C1. Ravi',   '#0891b2'),
('Physical Design & EDA',        'VL3504', 'VLSI',5, 3, 'Theory', 'Prof. D1. Priya',  '#d97706'),
('VLSI Design Lab',              'VL3511', 'VLSI',5, 2, 'Lab',    'Prof. A1. Senthil','#be123c'),
-- AIML Sem 5
('Machine Learning',             'AI3501', 'AIML',5, 4, 'Theory', 'Prof. F1. Divya',  '#db2777'),
('Deep Learning',                'AI3502', 'AIML',5, 3, 'Theory', 'Prof. G1. Ramesh', '#7c3aed'),
('Natural Language Processing',  'AI3503', 'AIML',5, 4, 'Theory', 'Prof. H1. Nisha',  '#6375ff'),
('Computer Vision',              'AI3504', 'AIML',5, 3, 'Theory', 'Prof. I1. Vijay',  '#0891b2'),
('ML Lab',                       'AI3511', 'AIML',5, 2, 'Lab',    'Prof. F1. Divya',  '#be123c'),
-- BIO Sem 5
('Molecular Biology',            'BT3501', 'BIO', 5, 4, 'Theory', 'Prof. P1. Preethi','#16a34a'),
('Genetic Engineering',          'BT3502', 'BIO', 5, 3, 'Theory', 'Prof. Q1. Saranya','#0891b2'),
('Biochemistry',                 'BT3503', 'BIO', 5, 4, 'Theory', 'Prof. R1. Ramesh', '#d97706'),
('Bioprocess Technology',        'BT3504', 'BIO', 5, 3, 'Theory', 'Prof. S1. Kavya',  '#7c3aed'),
('Biotech Lab',                  'BT3511', 'BIO', 5, 2, 'Lab',    'Prof. P1. Preethi','#be123c');

-- Exams
INSERT IGNORE INTO exams (subject, code, dept, exam_date, exam_time, hall, duration, days_left, color, syllabus) VALUES
('Data Structures',   'CS3401', 'CSE',  'Mar 15', '10:00 AM', 'Hall A - Block 2', '3 Hours', 2,  '#f87171', 'Units 1-5: Arrays, Trees, Graphs, Sorting'),
('Database Mgmt',     'CS3402', 'CSE',  'Mar 18', '10:00 AM', 'Hall B - Block 2', '3 Hours', 5,  '#fb923c', 'Units 1-5: ER Model, SQL, Normalization'),
('Operating Systems', 'CS3403', 'CSE',  'Mar 22', '10:00 AM', 'Hall A - Block 3', '3 Hours', 9,  '#fbbf24', 'Units 1-5: Process, Memory, File Systems'),
('Computer Networks', 'CS3404', 'CSE',  'Mar 26', '2:00 PM',  'Hall C - Block 1', '3 Hours', 13, '#34d399', 'Units 1-5: OSI, TCP/IP, Routing'),
('Web Technology',    'IT3401', 'IT',   'Mar 16', '10:00 AM', 'Hall E - Block 2', '3 Hours', 3,  '#f87171', 'Units 1-5: HTML, CSS, JS, React, Node.js'),
('VLSI Design',       'VL3501', 'VLSI', 'Mar 15', '10:00 AM', 'Hall K - Block 5', '3 Hours', 2,  '#f87171', 'Units 1-5: MOS, CMOS, Combinational, Sequential'),
('Machine Learning',  'AI3501', 'AIML', 'Mar 16', '10:00 AM', 'Hall L - Block 5', '3 Hours', 3,  '#f87171', 'Units 1-5: Supervised, Unsupervised, Neural Networks'),
('Molecular Biology', 'BT3501', 'BIO',  'Mar 15', '10:00 AM', 'Hall M - Block 6', '3 Hours', 2,  '#f87171', 'Units 1-5: DNA, Transcription, Gene Regulation');

-- Internships
INSERT IGNORE INTO internships (company, logo, color, ctc, role, dept_eligible, skills, type, mode, duration, location, deadline, description, is_active) VALUES
('Google',     'G',  '#4285F4', '₹80,000/mo', 'SWE Intern',         'CSE,IT,AIML,DSC',           'Python,DSA,System Design',           'Paid', 'Hybrid',  '3 months', 'Bangalore', 'Apr 15', 'Work on real Google products.',       true),
('Microsoft',  'M',  '#00A4EF', '₹75,000/mo', 'SDE Intern',         'CSE,IT,ECE,AIML',           'C++,OOP,Azure',                      'Paid', 'Online',  '2 months', 'Hyderabad', 'Apr 20', 'Contribute to Microsoft products.',   true),
('Qualcomm',   'Q',  '#3253DC', '₹70,000/mo', 'VLSI Design Intern', 'VLSI,ECE',                  'VLSI,VHDL,Signal Processing',        'Paid', 'Hybrid',  '6 months', 'Hyderabad', 'Apr 8',  'Chip design with world engineers.',   true),
('ISRO',       'I',  '#FF6600', 'Unpaid',      'Research Intern',    'ECE,EEE,MECH,AERO,VLSI',   'C,Embedded,Signal Processing',       'Free', 'Offline', '2 months', 'Bangalore', 'Mar 30', 'Prestigious government internship.',  true),
('Biocon',     'Bc', '#008000', '₹6 LPA',     'Research Scientist', 'BIO,BME,CHEM',              'Molecular Biology,Cell Culture',     'Paid', 'Offline', '6 months', 'Bangalore', 'Apr 20', 'Drug discovery and development.',     true),
('TCS',        'T',  '#0033A0', '₹7 LPA',     'Systems Engineer',   'CSE,IT,ECE,EEE,MECH,AIML', 'Java,SQL,Aptitude',                  'Paid', 'Hybrid',  '3 months', 'Multiple',  'May 15', 'Enterprise projects exposure.',       true),
('Zoho',       'Z',  '#E42527', '₹12 LPA',    'Software Developer', 'CSE,IT,AIML,MCA',           'Java,React,SQL',                     'Paid', 'Offline', '6 months', 'Chennai',   'Apr 10', 'Product company, high PPO rate.',     true),
('L&T',        'L',  '#D4351C', '₹8 LPA',     'Graduate Apprentice','MECH,CIVIL,EEE,CHEM,AERO', 'AutoCAD,Engineering Design',         'Paid', 'Offline', '6 months', 'Mumbai',    'Apr 25', 'Mega infrastructure projects.',       true);

-- Announcements
INSERT IGNORE INTO announcements (title, message, type, priority) VALUES
('Internal Exam Schedule Released',  'Exams from Mar 15-30, 2026. Check calendar for dept-wise dates and halls.',  'Exam',      'High'),
('Hackathon Registration Open',      'Anna University Hackathon 2026. Team: 2-4 members. Prize: ₹1,00,000.',       'Event',     'Medium'),
('TCS & Infosys Campus Drive',       'Drives Mar 25-28. CSE,IT,ECE,EEE,MECH eligible. Register by Mar 20.',        'Placement', 'High'),
('NPTEL Enrollment Deadline',        'Last date to enroll for NPTEL courses: Mar 31. Elite certificate matters!',  'Academic',  'Medium'),
('Qualcomm VLSI Drive Announced',    'Qualcomm visiting for VLSI Design roles. VLSI & ECE students eligible.',     'Placement', 'High');
