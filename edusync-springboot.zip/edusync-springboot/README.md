# EduSync Spring Boot Backend

## Tech Stack
- Java 17
- Spring Boot 3.2
- Spring Security + JWT
- Spring Data JPA
- MySQL Database

## Setup

### 1. Install Required Tools
- Java JDK 17 → adoptium.net
- MySQL → dev.mysql.com/downloads
- IntelliJ IDEA Community → jetbrains.com

### 2. Create MySQL Database
```sql
CREATE DATABASE edusync;
```

### 3. Update application.properties
```properties
spring.datasource.password=YOUR_MYSQL_PASSWORD
```

### 4. Run the Application
```bash
./mvnw spring-boot:run
```
Or in IntelliJ → Run EduSyncApplication

### 5. Server starts at
```
http://localhost:8080
```

## API Endpoints

| Method | URL | Description |
|--------|-----|-------------|
| POST | /api/auth/login | Login |
| POST | /api/auth/register | Register |
| GET | /api/auth/me | Get current user |
| GET | /api/departments | All departments |
| GET | /api/departments/{code} | Single dept |
| GET | /api/departments/{code}/subjects | Dept subjects |
| GET | /api/departments/{code}/exams | Dept exams |
| GET | /api/assignments?dept=CSE | Assignments |
| GET | /api/exams?dept=CSE | Exams |
| GET | /api/internships?dept=CSE | Internships |
| GET | /api/announcements | Announcements |

## Login Credentials
- Admin: akshayadarshini.n@gmail.com / aksh@2006
- Student: harivignesh@gmail.com / hari@1111
