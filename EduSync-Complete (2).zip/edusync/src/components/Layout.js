import React from 'react';

const NAV = [
  { id:'dashboard',        icon:'🏠', label:'Dashboard',        section:'Main' },
  { id:'departments',      icon:'🏛️', label:'All Departments',   section:null, badge:'New' },
  { id:'assignments',      icon:'📝', label:'Assignments',       section:'Academics', badge:3 },
  { id:'question-papers',  icon:'📄', label:'Question Papers',   section:null },
  { id:'exam-calendar',    icon:'📅', label:'Exam Calendar',     section:null },
  { id:'timetable',        icon:'🗓️', label:'My Timetable',      section:null },
  { id:'timetable-builder',icon:'🔨', label:'Timetable Builder', section:null },
  { id:'quiz',             icon:'🧩', label:'Quiz Practice',     section:'Learning' },
  { id:'courses',          icon:'▶️', label:'Video Courses',     section:null },
  { id:'nptel',            icon:'🎓', label:'NPTEL Courses',     section:null },
  { id:'notes',            icon:'📓', label:'My Notes',          section:null },
  { id:'gpa',              icon:'📊', label:'GPA Calculator',    section:null },
  { id:'internships',      icon:'💼', label:'Internships',       section:'Career' },
  { id:'placements',       icon:'🏢', label:'Upcoming Companies',section:null },
  { id:'roadmap',          icon:'🗺️', label:'Career Roadmap',    section:null },
  { id:'reminders',        icon:'🔔', label:'Reminders',         section:'Tools' },
  { id:'events',           icon:'🎉', label:'Events',            section:null },
  { id:'chatbot',          icon:'🤖', label:'AI Study Bot',      section:null },
  { id:'admin',            icon:'🛡️', label:'Admin Panel',       section:'Admin' },
];

export default function Layout({ activePage, setActivePage, user, onLogout, sidebarOpen }) {
  return (
    <aside className={`sidebar ${sidebarOpen ? 'sidebar-open' : ''}`}>
      {/* Logo */}
      <div className="sidebar-logo">
        <div className="logo-icon">🎓</div>
        <div>
          <div className="logo-text">EduSync</div>
          <div style={{ fontSize:9, color:'rgba(255,255,255,0.35)', marginTop:1 }}>Academic Portal v3.0</div>
        </div>
      </div>

      {/* Nav */}
      <nav className="sidebar-nav">
        {NAV.map(item => (
          <React.Fragment key={item.id}>
            {item.section && <div className="nav-section">{item.section}</div>}
            <button
              className={`nav-item ${activePage === item.id ? 'active' : ''}`}
              onClick={() => setActivePage(item.id)}
            >
              <div className="nav-icon">{item.icon}</div>
              {item.label}
              {item.badge && activePage !== item.id && (
                <span className="nav-badge" style={item.badge==='New'?{background:'#db2777'}:{}}>{item.badge}</span>
              )}
            </button>
          </React.Fragment>
        ))}
      </nav>

      {/* User */}
      <div className="sidebar-user">
        <div className="user-avatar">{user?.name?.[0] || 'A'}</div>
        <div style={{ flex:1, overflow:'hidden' }}>
          <div className="user-name" style={{ overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{user?.name}</div>
          <div className="user-reg">
            {user?.role === 'admin' ? '🛡️ Admin' : `${user?.dept || 'CS'}`} • Sem {user?.sem || 5}
          </div>
        </div>
        <button className="logout-btn" onClick={onLogout} title="Logout">⏻</button>
      </div>
    </aside>
  );
}
