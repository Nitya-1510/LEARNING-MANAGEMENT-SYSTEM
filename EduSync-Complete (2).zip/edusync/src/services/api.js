// ============================================
//  EduSync API Service
//  Connects React frontend to Node.js backend
// ============================================

const BASE_URL = 'http://localhost:5000/api';

// ── Get stored token ──────────────────────
const getToken = () => localStorage.getItem('edusync_token');

// ── Base request helper ───────────────────
const request = async (endpoint, options = {}) => {
  const token = getToken();
  const config = {
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
      ...options.headers,
    },
    ...options,
  };
  try {
    const res  = await fetch(`${BASE_URL}${endpoint}`, config);
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Request failed');
    return data;
  } catch (err) {
    console.warn('API Error:', err.message);
    throw err;
  }
};

// ══════════════════════════════════════════
//  AUTH API
// ══════════════════════════════════════════
export const authAPI = {
  // Login — saves token to localStorage
  login: async (email, password) => {
    const data = await request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    if (data.token) {
      localStorage.setItem('edusync_token', data.token);
      localStorage.setItem('edusync_user',  JSON.stringify(data.user));
    }
    return data;
  },

  // Logout — clears everything
  logout: () => {
    localStorage.removeItem('edusync_token');
    localStorage.removeItem('edusync_user');
    localStorage.removeItem('edusync_page');
  },

  // Get current user from backend
  me: () => request('/auth/me'),

  // Register new user
  register: (userData) => request('/auth/register', {
    method: 'POST',
    body: JSON.stringify(userData),
  }),
};

// ══════════════════════════════════════════
//  DEPARTMENTS API
// ══════════════════════════════════════════
export const deptAPI = {
  getAll:      ()             => request('/departments'),
  getOne:      (code)         => request(`/departments/${code}`),
  getSubjects: (code, sem=5)  => request(`/departments/${code}/subjects?sem=${sem}`),
  getTimetable:(code, sem=5)  => request(`/departments/${code}/timetable?sem=${sem}`),
  getRoadmap:  (code)         => request(`/departments/${code}/roadmap`),
  getInternships:(code)       => request(`/departments/${code}/internships`),
};

// ══════════════════════════════════════════
//  SUBJECTS API
// ══════════════════════════════════════════
export const subjectsAPI = {
  getAll: (dept, sem) => {
    const params = new URLSearchParams();
    if (dept) params.append('dept', dept);
    if (sem)  params.append('sem', sem);
    return request(`/subjects?${params.toString()}`);
  },
  getOne: (id) => request(`/subjects/${id}`),
};

// ══════════════════════════════════════════
//  ASSIGNMENTS API
// ══════════════════════════════════════════
export const assignmentsAPI = {
  getAll:   (dept)    => request(`/assignments${dept ? `?dept=${dept}` : ''}`),
  getOne:   (id)      => request(`/assignments/${id}`),
  create:   (data)    => request('/assignments', { method:'POST', body:JSON.stringify(data) }),
  update:   (id,data) => request(`/assignments/${id}`, { method:'PUT', body:JSON.stringify(data) }),
  delete:   (id)      => request(`/assignments/${id}`, { method:'DELETE' }),
  submit:   (id)      => request(`/assignments/${id}/submit`, { method:'PUT' }),
};

// ══════════════════════════════════════════
//  EXAMS API
// ══════════════════════════════════════════
export const examsAPI = {
  getAll: (dept) => request(`/exams${dept ? `?dept=${dept}` : ''}`),
  getOne: (id)   => request(`/exams/${id}`),
  create: (data) => request('/exams', { method:'POST', body:JSON.stringify(data) }),
};

// ══════════════════════════════════════════
//  INTERNSHIPS API
// ══════════════════════════════════════════
export const internshipsAPI = {
  getAll:  (dept, mode) => {
    const params = new URLSearchParams();
    if (dept) params.append('dept', dept);
    if (mode) params.append('mode', mode);
    return request(`/internships?${params.toString()}`);
  },
  getOne:  (id)      => request(`/internships/${id}`),
  create:  (data)    => request('/internships', { method:'POST', body:JSON.stringify(data) }),
  update:  (id,data) => request(`/internships/${id}`, { method:'PUT', body:JSON.stringify(data) }),
  delete:  (id)      => request(`/internships/${id}`, { method:'DELETE' }),
};

// ══════════════════════════════════════════
//  PLACEMENTS API
// ══════════════════════════════════════════
export const placementsAPI = {
  getAll: (dept) => request(`/placements${dept ? `?dept=${dept}` : ''}`),
};

// ══════════════════════════════════════════
//  NPTEL API
// ══════════════════════════════════════════
export const nptelAPI = {
  getAll:  ()         => request('/nptel'),
  enroll:  (id)       => request(`/nptel/${id}/enroll`, { method:'PUT' }),
};

// ══════════════════════════════════════════
//  NOTES API
// ══════════════════════════════════════════
export const notesAPI = {
  getAll:  ()         => request('/notes'),
  create:  (data)     => request('/notes',      { method:'POST',   body:JSON.stringify(data) }),
  update:  (id, data) => request(`/notes/${id}`,{ method:'PUT',    body:JSON.stringify(data) }),
  delete:  (id)       => request(`/notes/${id}`,{ method:'DELETE' }),
};

// ══════════════════════════════════════════
//  REMINDERS API
// ══════════════════════════════════════════
export const remindersAPI = {
  getAll:  ()         => request('/reminders'),
  create:  (data)     => request('/reminders',       { method:'POST',   body:JSON.stringify(data) }),
  update:  (id, data) => request(`/reminders/${id}`, { method:'PUT',    body:JSON.stringify(data) }),
  delete:  (id)       => request(`/reminders/${id}`, { method:'DELETE' }),
};

// ══════════════════════════════════════════
//  EVENTS API
// ══════════════════════════════════════════
export const eventsAPI = {
  getAll: () => request('/events'),
};

// ══════════════════════════════════════════
//  ANNOUNCEMENTS API
// ══════════════════════════════════════════
export const announcementsAPI = {
  getAll:  ()      => request('/announcements'),
  create:  (data)  => request('/announcements',       { method:'POST',   body:JSON.stringify(data) }),
  delete:  (id)    => request(`/announcements/${id}`, { method:'DELETE' }),
};

// ══════════════════════════════════════════
//  TIMETABLE API
// ══════════════════════════════════════════
export const timetableAPI = {
  get:    (dept, sem=5) => request(`/timetable?dept=${dept}&sem=${sem}`),
  getAll: ()            => request('/timetable/all'),
};

// ══════════════════════════════════════════
//  ROADMAP API
// ══════════════════════════════════════════
export const roadmapAPI = {
  get:    (dept) => request(`/roadmap?dept=${dept}`),
  getAll: ()     => request('/roadmap/all'),
};

// ══════════════════════════════════════════
//  USERS API
// ══════════════════════════════════════════
export const usersAPI = {
  getAll:  ()         => request('/users'),
  getOne:  (id)       => request(`/users/${id}`),
  update:  (id, data) => request(`/users/${id}`, { method:'PUT', body:JSON.stringify(data) }),
  delete:  (id)       => request(`/users/${id}`, { method:'DELETE' }),
};

// ══════════════════════════════════════════
//  HELPER — Check if backend is running
// ══════════════════════════════════════════
export const checkBackend = async () => {
  try {
    const res = await fetch('http://localhost:5000/', { method:'GET' });
    return res.ok;
  } catch {
    return false;
  }
};

export default {
  auth:          authAPI,
  dept:          deptAPI,
  subjects:      subjectsAPI,
  assignments:   assignmentsAPI,
  exams:         examsAPI,
  internships:   internshipsAPI,
  placements:    placementsAPI,
  nptel:         nptelAPI,
  notes:         notesAPI,
  reminders:     remindersAPI,
  events:        eventsAPI,
  announcements: announcementsAPI,
  timetable:     timetableAPI,
  roadmap:       roadmapAPI,
  users:         usersAPI,
  checkBackend,
};
