import React, { useState } from 'react';
import { useDept } from '../context/DeptContext';

export default function Assignments({ showToast }) {
  const { dept, currentDept } = useDept();
  const [asgns, setAsgns] = useState(null);
  const [filter, setFilter] = useState('all');
  const [selected, setSelected] = useState(null);

  const assignments = asgns || dept.assignments || [];

  React.useEffect(() => { setAsgns(null); }, [currentDept]);

  const statusColor = { pending:'#fb923c', submitted:'#34d399', overdue:'#f87171' };

  const submit = (id) => {
    const updated = assignments.map(a => a.id===id ? {...a, status:'submitted', progress:2} : a);
    setAsgns(updated);
    showToast('Assignment submitted! ✅', '✅');
    setSelected(null);
  };

  const filtered = assignments.filter(a => filter==='all' || a.status===filter);

  return (
    <div className="page">
      <div className="page-header">
        <h2>Assignments 📝</h2>
        <p style={{ display:'flex', alignItems:'center', gap:8 }}>
          <span style={{ background:`${dept.color}22`, color:dept.color, padding:'2px 10px', borderRadius:20, fontSize:12, fontWeight:700 }}>{dept.icon} {currentDept}</span>
          Track deadlines and submit your work
        </p>
      </div>

      <div className="grid-4" style={{ marginBottom:18 }}>
        {[
          ['📝','Pending',   assignments.filter(a=>a.status==='pending').length,   '#fb923c'],
          ['✅','Submitted', assignments.filter(a=>a.status==='submitted').length, '#34d399'],
          ['⚠️','Overdue',   assignments.filter(a=>a.status==='overdue').length,   '#f87171'],
          ['📊','Max Marks', assignments.reduce((s,a)=>s+a.maxMarks,0),           '#6375ff'],
        ].map(([icon,label,val,color]) => (
          <div className="card card-sm" key={label} style={{ display:'flex', alignItems:'center', gap:10 }}>
            <div style={{ width:40, height:40, borderRadius:11, background:`${color}22`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:18, flexShrink:0 }}>{icon}</div>
            <div>
              <div style={{ fontSize:22, fontWeight:800, fontFamily:'Syne,sans-serif', color }}>{val}</div>
              <div style={{ fontSize:11, color:'var(--muted)' }}>{label}</div>
            </div>
          </div>
        ))}
      </div>

      <div style={{ display:'flex', gap:8, marginBottom:18 }}>
        {['all','pending','submitted','overdue'].map(f => (
          <button key={f} className={`filter-btn ${filter===f?'active':''}`} onClick={() => setFilter(f)} style={{ textTransform:'capitalize' }}>{f==='all'?'All':f}</button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="card" style={{ textAlign:'center', padding:40 }}>
          <div style={{ fontSize:40, marginBottom:12 }}>📋</div>
          <h4>No assignments for {dept.name}</h4>
          <p style={{ color:'var(--muted)', marginTop:6 }}>Check back later or switch department</p>
        </div>
      ) : (
        filtered.map(a => (
          <div key={a.id} className="card" onClick={() => setSelected(a)} style={{ marginBottom:12, cursor:'pointer', borderLeft:`4px solid ${statusColor[a.status]}`, transition:'.2s' }} onMouseEnter={e=>e.currentTarget.style.transform='translateY(-1px)'} onMouseLeave={e=>e.currentTarget.style.transform='none'}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:10 }}>
              <div>
                <div style={{ fontSize:14, fontWeight:700 }}>{a.title}</div>
                <div style={{ fontSize:12, color:'var(--muted)', marginTop:2 }}>{a.subject} • {a.code}</div>
              </div>
              <span className={`tag tag-${a.status==='submitted'?'green':a.status==='overdue'?'red':'orange'}`} style={{ textTransform:'capitalize' }}>{a.status}</span>
            </div>
            <div style={{ marginBottom:10 }}>
              <div style={{ display:'flex', justifyContent:'space-between', fontSize:11, color:'var(--muted)', marginBottom:5 }}>
                <span>Progress</span>
                <span style={{ color:statusColor[a.status], fontWeight:700 }}>{['Not Started','In Progress','Completed'][a.progress]}</span>
              </div>
              <div className="progress-bar"><div className="progress-fill" style={{ width:`${(a.progress/2)*100}%`, background:statusColor[a.status] }}></div></div>
            </div>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
              <div style={{ display:'flex', gap:8 }}>
                <span className={`tag tag-${a.daysLeft<0?'red':a.daysLeft<=3?'orange':'green'}`}>📅 Due {a.due}</span>
                <span className="tag tag-blue">📊 {a.maxMarks} marks</span>
              </div>
              <button className="btn btn-primary btn-sm" onClick={e=>{e.stopPropagation();setSelected(a);}}>View →</button>
            </div>
          </div>
        ))
      )}

      {selected && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setSelected(null)}>
          <div className="modal modal-lg">
            <div className="modal-header">
              <div><h3>{selected.title}</h3><p style={{color:'var(--muted)',fontSize:13,marginTop:3}}>{selected.subject} • {selected.code} • {selected.maxMarks} marks</p></div>
              <button className="modal-close" onClick={()=>setSelected(null)}>×</button>
            </div>
            <div style={{ marginBottom:16 }}>
              <div style={{ fontWeight:700, fontSize:14, marginBottom:10 }}>📝 Questions</div>
              {selected.questions.map((q,i) => (
                <div key={i} style={{ background:'var(--bg3)', borderRadius:10, padding:'12px 15px', marginBottom:9 }}>
                  <span style={{ fontWeight:700, color:'#6375ff', marginRight:8 }}>Q{i+1}.</span>{q}
                </div>
              ))}
            </div>
            <div className="grid-2" style={{ marginBottom:16 }}>
              {[['📅','Due Date',selected.due],['📊','Max Marks',selected.maxMarks],['🏷️','Status',selected.status],['⏰','Days Left',selected.daysLeft<0?`${Math.abs(selected.daysLeft)}d overdue`:`${selected.daysLeft} days`]].map(([ic,l,v]) => (
                <div key={l} style={{ background:'var(--bg3)', borderRadius:9, padding:'9px 12px' }}>
                  <div style={{ fontSize:10, color:'var(--muted)', fontWeight:700, textTransform:'uppercase', marginBottom:2 }}>{ic} {l}</div>
                  <div style={{ fontSize:13, fontWeight:600, textTransform:'capitalize' }}>{v}</div>
                </div>
              ))}
            </div>
            <div className="modal-actions">
              <button className="btn btn-ghost" onClick={()=>setSelected(null)}>Close</button>
              {selected.status!=='submitted' && <button className="btn btn-primary" onClick={()=>submit(selected.id)}>Submit ✅</button>}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
