import React, { useState, useEffect } from 'react';
import { QUIZ_DATA } from '../data/appData';

export default function Quiz({ showToast }) {
  const [active, setActive] = useState(null);
  const [qi, setQi] = useState(0);
  const [score, setScore] = useState(0);
  const [answered, setAnswered] = useState(false);
  const [chosen, setChosen] = useState(null);
  const [done, setDone] = useState(false);
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    if (!active || answered) return;
    setTimeLeft(active.time * 60);
    const t = setInterval(() => setTimeLeft(p => { if(p<=1){clearInterval(t);return 0;} return p-1; }), 1000);
    return () => clearInterval(t);
  }, [active, qi]);

  const startQuiz = (quiz) => { setActive(quiz); setQi(0); setScore(0); setAnswered(false); setChosen(null); setDone(false); };
  const answer = (idx) => {
    if (answered) return;
    setChosen(idx);
    setAnswered(true);
    if (idx === active.questions[qi].ans) setScore(p => p + 1);
  };
  const next = () => {
    if (qi + 1 >= active.questions.length) { setDone(true); return; }
    setQi(p => p + 1);
    setAnswered(false);
    setChosen(null);
  };
  const finish = () => {
    const pct = Math.round((score / active.questions.length) * 100);
    showToast(`Quiz complete! Score: ${score}/${active.questions.length} (${pct}%) 🎉`, '🏆');
    setDone(true);
  };

  const mins = Math.floor(timeLeft / 60);
  const secs = timeLeft % 60;

  if (!active) return (
    <div className="page">
      <div className="page-header"><h2>Quiz Practice 🧩</h2><p>Test your knowledge across all subjects with explanations</p></div>
      <div className="grid-3" style={{ marginBottom: 24 }}>
        {QUIZ_DATA.map(quiz => (
          <div key={quiz.id} className="card" onClick={() => startQuiz(quiz)} style={{ cursor: 'pointer', borderTop: `3px solid ${quiz.color}`, transition: '.2s', textAlign: 'center' }} onMouseEnter={e=>e.currentTarget.style.transform='translateY(-3px)'} onMouseLeave={e=>e.currentTarget.style.transform='none'}>
            <div style={{ fontSize: 32, marginBottom: 10 }}>{quiz.icon}</div>
            <h4 style={{ fontSize: 14 }}>{quiz.title}</h4>
            <p style={{ fontSize: 12, color: 'var(--muted)', margin: '4px 0 10px' }}>{quiz.subject}</p>
            <div style={{ display: 'flex', gap: 6, justifyContent: 'center', flexWrap: 'wrap', marginBottom: 14 }}>
              <span className={`tag tag-${quiz.difficulty==='Easy'?'green':quiz.difficulty==='Medium'?'orange':'red'}`}>{quiz.difficulty}</span>
              <span className="tag tag-blue">⏱ {quiz.time} min</span>
              <span className="tag tag-purple">{quiz.questions.length} Qs</span>
            </div>
            <button className="btn btn-primary btn-sm" style={{ width: '100%', justifyContent: 'center' }}>Start Quiz →</button>
          </div>
        ))}
      </div>
      <div className="card">
        <div className="section-title">📊 Your Stats</div>
        <div className="grid-3">
          {[['🧩','Total Quizzes','14'],['✅','Average Score','82%'],['🏆','Best Score','100%']].map(([icon,label,val]) => (
            <div key={label} style={{ textAlign: 'center', padding: '14px', background: 'var(--bg3)', borderRadius: 10 }}>
              <div style={{ fontSize: 26, marginBottom: 7 }}>{icon}</div>
              <div style={{ fontSize: 20, fontWeight: 800, fontFamily: 'Syne,sans-serif', color: '#6375ff' }}>{val}</div>
              <div style={{ fontSize: 11, color: 'var(--muted)' }}>{label}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  if (done) {
    const pct = Math.round((score / active.questions.length) * 100);
    return (
      <div className="page" style={{ maxWidth: 600, margin: '0 auto' }}>
        <div className="card" style={{ textAlign: 'center', padding: 40 }}>
          <div style={{ fontSize: 60, marginBottom: 16 }}>{pct >= 80 ? '🏆' : pct >= 60 ? '⭐' : '📚'}</div>
          <h2 style={{ fontSize: 24, marginBottom: 8 }}>Quiz Complete!</h2>
          <div style={{ fontSize: 48, fontWeight: 800, fontFamily: 'Syne,sans-serif', color: pct >= 80 ? '#34d399' : pct >= 60 ? '#fb923c' : '#f87171', marginBottom: 8 }}>{pct}%</div>
          <p style={{ color: 'var(--muted)', marginBottom: 20 }}>You scored {score} out of {active.questions.length} questions</p>
          <span className={`tag tag-${pct>=80?'green':pct>=60?'orange':'red'}`} style={{ fontSize: 13, padding: '6px 16px', marginBottom: 24, display: 'inline-flex' }}>
            {pct >= 80 ? '🏆 Excellent!' : pct >= 60 ? '👍 Good Job!' : '📚 Keep Practicing!'}
          </span>
          <div style={{ display: 'flex', gap: 10, justifyContent: 'center' }}>
            <button className="btn btn-ghost" onClick={() => setActive(null)}>← All Quizzes</button>
            <button className="btn btn-primary" onClick={() => startQuiz(active)}>Retry →</button>
          </div>
        </div>
      </div>
    );
  }

  const q = active.questions[qi];
  return (
    <div className="page" style={{ maxWidth: 700, margin: '0 auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
        <div className="page-header" style={{ marginBottom: 0 }}><h2>{active.title} {active.icon}</h2></div>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <span style={{ background: timeLeft < 60 ? 'rgba(248,113,113,0.15)' : 'rgba(99,117,255,0.15)', color: timeLeft < 60 ? '#f87171' : '#6375ff', padding: '5px 12px', borderRadius: 8, fontSize: 13, fontWeight: 700 }}>
            ⏱ {mins}:{secs.toString().padStart(2,'0')}
          </span>
          <button className="btn btn-ghost btn-sm" onClick={() => setActive(null)}>✕ Exit</button>
        </div>
      </div>
      <div style={{ display: 'flex', gap: 6, marginBottom: 18 }}>
        {active.questions.map((_, i) => (
          <div key={i} style={{ flex: 1, height: 5, borderRadius: 3, background: i < qi ? '#6375ff' : i === qi ? '#a78bfa' : 'var(--bg3)' }} />
        ))}
      </div>
      <div className="card">
        <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 10, display: 'flex', justifyContent: 'space-between' }}>
          <span>Question {qi + 1} of {active.questions.length}</span>
          <span>Score: <b style={{ color: '#6375ff' }}>{score}</b></span>
        </div>
        <div style={{ fontSize: 16, fontWeight: 600, lineHeight: 1.6, marginBottom: 20 }}>{q.q}</div>
        {q.opts.map((opt, i) => (
          <button key={i} className={`quiz-opt ${answered ? (i === q.ans ? 'correct' : chosen === i ? 'wrong' : '') : ''}`} onClick={() => answer(i)} disabled={answered}>
            <span style={{ fontWeight: 700, marginRight: 8 }}>{String.fromCharCode(65+i)}.</span> {opt}
          </button>
        ))}
        {answered && (
          <>
            <div style={{ marginTop: 14, padding: '11px 15px', background: 'rgba(52,211,153,0.08)', border: '1px solid rgba(52,211,153,0.25)', borderRadius: 10, fontSize: 13, color: '#34d399' }}>
              💡 <b>Explanation:</b> {q.explanation}
            </div>
            <div style={{ marginTop: 14, textAlign: 'right' }}>
              {qi < active.questions.length - 1
                ? <button className="btn btn-primary" onClick={next}>Next Question →</button>
                : <button className="btn btn-primary" onClick={finish}>View Results 🏆</button>}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
