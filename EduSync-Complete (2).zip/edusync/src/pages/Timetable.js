import React from 'react';
import { useDept } from '../context/DeptContext';

export default function Timetable() {
  const { dept, currentDept } = useDept();
  const tt = dept.timetable;

  if (!tt) return (
    <div className="page">
      <div className="page-header"><h2>Timetable 🗓️</h2></div>
      <div className="card" style={{textAlign:'center',padding:40}}>
        <div style={{fontSize:40,marginBottom:12}}>🗓️</div>
        <h4>Timetable not available for {dept.name}</h4>
      </div>
    </div>
  );

  return (
    <div className="page">
      <div className="page-header">
        <h2>Timetable 🗓️</h2>
        <p style={{display:'flex',alignItems:'center',gap:8}}>
          <span style={{background:`${dept.color}22`,color:dept.color,padding:'2px 10px',borderRadius:20,fontSize:12,fontWeight:700}}>{dept.icon} {currentDept}</span>
          Semester {dept.sem} Weekly Schedule
        </p>
      </div>

      {/* Subject Legend */}
      <div className="card" style={{marginBottom:16}}>
        <div style={{fontWeight:700,fontSize:13,marginBottom:10}}>📚 Subject Legend</div>
        <div style={{display:'flex',flexWrap:'wrap',gap:8}}>
          {dept.subjects?.map(s => (
            <span key={s.code} style={{background:`${s.color}18`,color:s.color,padding:'4px 11px',borderRadius:20,fontSize:11,fontWeight:600,border:`1px solid ${s.color}33`}}>
              {s.type==='Lab'?'🔬':'📖'} {s.code} — {s.name}
            </span>
          ))}
        </div>
      </div>

      {/* Timetable Grid */}
      <div className="card" style={{overflowX:'auto'}}>
        <table style={{width:'100%',borderCollapse:'collapse',minWidth:600}}>
          <thead>
            <tr>
              <th style={{padding:'10px 12px',background:'var(--bg3)',borderRadius:'8px 0 0 0',fontSize:11,color:'var(--muted)',fontWeight:700,textAlign:'left',width:90}}>Time</th>
              {tt.days.map((day,i) => (
                <th key={day} style={{padding:'10px 8px',background:'var(--bg3)',fontSize:12,fontWeight:700,textAlign:'center',color:dept.color,borderRadius:i===tt.days.length-1?'0 8px 0 0':0}}>
                  {day.slice(0,3).toUpperCase()}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {tt.times.map((time, ti) => (
              <tr key={time}>
                <td style={{padding:'8px 12px',fontSize:10,color:'var(--muted)',fontWeight:600,borderBottom:'1px solid var(--border)',whiteSpace:'nowrap'}}>{time}</td>
                {tt.schedule.map((daySchedule, di) => {
                  const [subject, color] = daySchedule[ti] || ['',''];
                  const isBreak = subject === 'BREAK';
                  const isFree  = subject === 'Free';
                  return (
                    <td key={di} style={{padding:'6px 4px',borderBottom:'1px solid var(--border)',textAlign:'center'}}>
                      {isBreak ? (
                        <div style={{background:'rgba(156,163,175,0.1)',borderRadius:7,padding:'6px 4px',fontSize:10,color:'var(--muted)',fontWeight:600}}>🍱 Lunch</div>
                      ) : isFree ? (
                        <div style={{background:'rgba(156,163,175,0.07)',borderRadius:7,padding:'6px 4px',fontSize:10,color:'var(--muted)'}}>Free</div>
                      ) : subject ? (
                        <div style={{background:`${color}22`,border:`1.5px solid ${color}44`,borderRadius:7,padding:'6px 4px',fontSize:11,fontWeight:700,color}}>
                          {subject}
                        </div>
                      ) : (
                        <div style={{fontSize:10,color:'var(--muted)'}}>—</div>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
