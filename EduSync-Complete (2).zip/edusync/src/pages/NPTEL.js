import React, { useState } from 'react';
import { NPTEL_COURSES } from '../data/appData';

const diffColor = { Beginner:'#34d399', Intermediate:'#6375ff', Advanced:'#fb923c', Expert:'#f87171' };
const cats = [['all','All'],['cs','CS Core'],['ai','AI/ML'],['programming','Programming'],['cloud','Cloud'],['security','Security']];

export default function NPTEL({ showToast }) {
  const [courses, setCourses] = useState(NPTEL_COURSES);
  const [cat, setCat] = useState('all');
  const [diff, setDiff] = useState('All');
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState(null);

  const list = courses.filter(c=>
    (cat==='all'||c.category===cat) &&
    (diff==='All'||c.difficulty===diff) &&
    (!search||c.title.toLowerCase().includes(search.toLowerCase())||c.instructor.toLowerCase().includes(search.toLowerCase()))
  );

  const toggle = (id) => {
    const c = courses.find(c=>c.id===id);
    setCourses(prev=>prev.map(c=>c.id===id?{...c,enrolled:!c.enrolled}:c));
    showToast(c.enrolled?`Unenrolled from ${c.title}`:`Enrolled! Start learning 🎓`,'✅');
  };

  const enrolled = courses.filter(c=>c.enrolled);

  return (
    <div className="page">
      <div className="page-header">
        <h2>NPTEL Courses 🎓</h2>
        <p>IIT & IISc certified online courses — earn certificates recognised by top companies</p>
      </div>

      <div className="grid-4" style={{marginBottom:24}}>
        {[
          {icon:'📚',label:'Available Courses',val:courses.length,color:'#6375ff'},
          {icon:'✅',label:'Enrolled',val:enrolled.length,color:'#34d399'},
          {icon:'📊',label:'Avg Progress',val:enrolled.length?Math.round(enrolled.reduce((a,c)=>a+c.progress,0)/enrolled.length)+'%':'0%',color:'#0891b2'},
          {icon:'🏆',label:'Certificates Earned',val:enrolled.filter(c=>c.progress===100).length,color:'#fbbf24'},
        ].map(s=>(
          <div className="card card-sm" key={s.label} style={{display:'flex',alignItems:'center',gap:12}}>
            <div style={{width:44,height:44,borderRadius:12,background:`${s.color}22`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:20,flexShrink:0}}>{s.icon}</div>
            <div><div style={{fontSize:24,fontWeight:800,fontFamily:'Syne,sans-serif',color:s.color}}>{s.val}</div><div style={{fontSize:12,color:'var(--muted)'}}>{s.label}</div></div>
          </div>
        ))}
      </div>

      {enrolled.length>0&&(
        <div className="card" style={{marginBottom:22}}>
          <div style={{fontWeight:700,fontSize:15,marginBottom:16}}>📊 My Learning Progress</div>
          {enrolled.map(c=>(
            <div key={c.id} style={{marginBottom:14}}>
              <div style={{display:'flex',justifyContent:'space-between',marginBottom:6}}>
                <div>
                  <span style={{fontSize:13,fontWeight:600}}>{c.title}</span>
                  <span style={{fontSize:11,color:'var(--muted)',marginLeft:8}}>{c.inst}</span>
                </div>
                <span style={{fontSize:13,fontWeight:700,color:'#6375ff'}}>{c.progress}%</span>
              </div>
              <div style={{background:'var(--bg3)',borderRadius:6,height:8,overflow:'hidden'}}>
                <div style={{height:'100%',width:`${c.progress}%`,background:'linear-gradient(90deg,#6375ff,#a78bfa)',borderRadius:6,transition:'width .5s'}}></div>
              </div>
              <div style={{fontSize:11,color:'var(--muted)',marginTop:3}}>{c.weeks} weeks • Ends {c.endDate} • 🏆 {c.cert}</div>
            </div>
          ))}
        </div>
      )}

      <div style={{position:'relative',marginBottom:14}}>
        <span style={{position:'absolute',left:14,top:'50%',transform:'translateY(-50%)'}}>🔍</span>
        <input type="text" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search courses or instructors..." style={{paddingLeft:42}} />
      </div>
      <div style={{display:'flex',gap:10,flexWrap:'wrap',marginBottom:22}}>
        <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
          {cats.map(([v,l])=><button key={v} className={`filter-btn ${cat===v?'active':''}`} onClick={()=>setCat(v)} style={{padding:'5px 12px'}}>{l}</button>)}
        </div>
        <div style={{display:'flex',gap:6}}>
          {['All','Beginner','Intermediate','Advanced','Expert'].map(d=><button key={d} className={`filter-btn ${diff===d?'active':''}`} onClick={()=>setDiff(d)} style={{padding:'5px 12px'}}>{d}</button>)}
        </div>
      </div>

      <div className="grid-3">
        {list.map(c=>(
          <div key={c.id} className="card" style={{cursor:'pointer',borderTop:`3px solid ${diffColor[c.difficulty]}`,transition:'.2s'}} onMouseEnter={e=>e.currentTarget.style.transform='translateY(-3px)'} onMouseLeave={e=>e.currentTarget.style.transform='none'} onClick={()=>setSelected(c)}>
            <div style={{display:'flex',justifyContent:'space-between',marginBottom:10}}>
              <span style={{fontSize:11,fontWeight:700,color:'#38bdf8',background:'rgba(56,189,248,0.1)',padding:'3px 8px',borderRadius:6}}>{c.inst}</span>
              <span style={{fontSize:11,fontWeight:700,color:diffColor[c.difficulty],background:`${diffColor[c.difficulty]}18`,padding:'3px 8px',borderRadius:6}}>{c.difficulty}</span>
            </div>
            <h4 style={{fontSize:14,fontWeight:700,lineHeight:1.4,marginBottom:5}}>{c.title}</h4>
            <p style={{fontSize:12,color:'var(--muted)',marginBottom:12}}>{c.instructor}</p>
            <div style={{display:'flex',gap:6,flexWrap:'wrap',marginBottom:14}}>
              <span style={{fontSize:11,background:'rgba(167,139,250,0.15)',color:'#a78bfa',padding:'3px 8px',borderRadius:6}}>⏱ {c.weeks} weeks</span>
              <span style={{fontSize:11,background:'rgba(251,191,36,0.15)',color:'#fbbf24',padding:'3px 8px',borderRadius:6}}>🏆 {c.cert}</span>
              <span style={{fontSize:11,background:'rgba(52,211,153,0.15)',color:'#34d399',padding:'3px 8px',borderRadius:6}}>⭐ {c.rating}</span>
            </div>
            <div style={{fontSize:11,color:'var(--muted)',marginBottom:14}}>👥 {c.enrolled_count} enrolled</div>
            {c.enrolled&&c.progress>0&&(
              <div style={{marginBottom:12}}>
                <div style={{display:'flex',justifyContent:'space-between',fontSize:11,color:'var(--muted)',marginBottom:4}}><span>Progress</span><span style={{color:'#6375ff',fontWeight:700}}>{c.progress}%</span></div>
                <div style={{background:'var(--bg3)',borderRadius:4,height:5}}><div style={{width:`${c.progress}%`,height:'100%',background:'linear-gradient(90deg,#6375ff,#a78bfa)',borderRadius:4}}></div></div>
              </div>
            )}
            <button className={`btn btn-sm ${c.enrolled?'btn-ghost':'btn-primary'}`} style={{width:'100%',justifyContent:'center'}} onClick={e=>{e.stopPropagation();toggle(c.id);}}>
              {c.enrolled?'✅ Enrolled (Click to unenroll)':'+ Enroll Free'}
            </button>
          </div>
        ))}
      </div>

      {selected&&(
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setSelected(null)}>
          <div className="modal modal-lg">
            <div className="modal-header">
              <div><h3 style={{fontSize:18}}>{selected.title}</h3><p style={{color:'var(--muted)',fontSize:13,marginTop:3}}>{selected.instructor} • {selected.inst}</p></div>
              <button className="modal-close" onClick={()=>setSelected(null)}>×</button>
            </div>
            <p style={{fontSize:14,color:'var(--muted)',lineHeight:1.8,marginBottom:18}}>{selected.desc}</p>
            <div className="grid-2" style={{marginBottom:16}}>
              {[['⏱','Duration',`${selected.weeks} weeks`],['📅','Starts',selected.startDate],['🏆','Certificate',selected.cert],['📚','Credits',`${selected.credits} credits`],['⭐','Rating',`${selected.rating}/5.0`],['👥','Enrolled',selected.enrolled_count]].map(([icon,label,val])=>(
                <div key={label} style={{background:'var(--bg3)',borderRadius:10,padding:'10px 14px'}}>
                  <div style={{fontSize:11,color:'var(--muted)',fontWeight:700,textTransform:'uppercase',marginBottom:3}}>{icon} {label}</div>
                  <div style={{fontSize:14,fontWeight:600}}>{val}</div>
                </div>
              ))}
            </div>
            <div style={{display:'flex',gap:8,flexWrap:'wrap',marginBottom:18}}>
              {selected.tags.map(t=><span key={t} style={{background:'rgba(99,117,255,0.15)',color:'#6375ff',padding:'5px 12px',borderRadius:8,fontSize:13,fontWeight:600}}>#{t}</span>)}
            </div>
            <div className="modal-actions">
              <button className="btn btn-ghost" onClick={()=>setSelected(null)}>Close</button>
              <a href="https://nptel.ac.in" target="_blank" rel="noreferrer" className="btn btn-ghost">Open NPTEL ↗</a>
              <button className={`btn ${selected.enrolled?'btn-danger':'btn-primary'}`} onClick={()=>{toggle(selected.id);setSelected(null);}}>
                {selected.enrolled?'Unenroll':'Enroll Now 🎓'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
