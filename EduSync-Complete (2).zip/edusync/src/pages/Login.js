import React, { useState, useEffect } from 'react';
import { authAPI, checkBackend } from '../services/api';

const LOCAL_USERS = [
  { name:'Akshaya Darshini', email:'akshayadarshini.n@gmail.com', password:'aksh@2006', role:'admin',   dept:'Computer Science & Engineering', deptCode:'CSE', sem:5, reg:'CS21001', cgpa:8.7 },
  { name:'Hari Vignesh',     email:'harivignesh@gmail.com',       password:'hari@1111', role:'student', dept:'Computer Science & Engineering', deptCode:'CSE', sem:5, reg:'CS21002', cgpa:8.4 },
  { name:'Priya Dharshini',  email:'priya.it@gmail.com',          password:'priya@123', role:'student', dept:'Information Technology',         deptCode:'IT',  sem:5, reg:'IT21001', cgpa:8.2 },
  { name:'Rajan Kumar',      email:'rajan.ece@gmail.com',         password:'rajan@123', role:'student', dept:'Electronics & Communication',    deptCode:'ECE', sem:5, reg:'EC21001', cgpa:7.9 },
  { name:'Deepa Lakshmi',    email:'deepa.eee@gmail.com',         password:'deepa@123', role:'student', dept:'Electrical & Electronics',       deptCode:'EEE', sem:5, reg:'EE21001', cgpa:8.1 },
  { name:'Arun Prasad',      email:'arun.mech@gmail.com',         password:'arun@123',  role:'student', dept:'Mechanical Engineering',         deptCode:'MECH',sem:5, reg:'ME21001', cgpa:7.8 },
  { name:'Kavya Senthil',    email:'kavya.vlsi@gmail.com',        password:'kavya@123', role:'student', dept:'VLSI Design',                    deptCode:'VLSI',sem:5, reg:'VL21001', cgpa:8.5 },
  { name:'Rahul Sharma',     email:'rahul.aiml@gmail.com',        password:'rahul@123', role:'student', dept:'Artificial Intelligence & ML',   deptCode:'AIML',sem:5, reg:'AI21001', cgpa:8.9 },
  { name:'Sneha Priya',      email:'sneha.bio@gmail.com',         password:'sneha@123', role:'student', dept:'Biotechnology',                  deptCode:'BIO', sem:5, reg:'BT21001', cgpa:8.0 },
];

export default function Login({ onLogin }) {
  const [email,       setEmail]       = useState('');
  const [password,    setPassword]    = useState('');
  const [showPw,      setShowPw]      = useState(false);
  const [error,       setError]       = useState('');
  const [loading,     setLoading]     = useState(false);
  const [backendOn,   setBackendOn]   = useState(false);
  const [checking,    setChecking]    = useState(true);

  // Check if backend is running on mount
  useEffect(() => {
    checkBackend().then(online => {
      setBackendOn(online);
      setChecking(false);
    });
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    // ── Try Backend First ──
    if (backendOn) {
      try {
        const data = await authAPI.login(email, password);
        if (data?.user) {
          onLogin(data.user);
          return;
        }
      } catch (err) {
        console.warn('Backend login failed, trying local:', err.message);
      }
    }

    // ── Fall back to Local Users ──
    await new Promise(r => setTimeout(r, 600));
    const user = LOCAL_USERS.find(u => u.email === email && u.password === password);
    if (user) {
      onLogin(user);
    } else {
      setError('Invalid email or password. Please try again.');
      setLoading(false);
    }
  };

  const quickLogin = (u) => {
    setEmail(u.email);
    setPassword(u.password);
    setError('');
  };

  return (
    <div className="login-page">
      {/* ── Left Panel ── */}
      <div className="login-left">
        <div className="login-logo">🎓</div>
        <h1>EduSync</h1>
        <p>Your complete academic companion for smarter learning, better grades and career success.</p>
        <div className="login-features">
          {[
            ['🏛️','All 20 Departments — CSE to BIO'],
            ['📝','Assignments & Deadlines'],
            ['📅','Exam Calendar & Timetable'],
            ['💼','Internships & Placements'],
            ['🗺️','Career Roadmap Year 1–4'],
            ['🎓','NPTEL Certifications'],
            ['🤖','AI Study Assistant'],
            ['🔬','VLSI, AIML, BIO & More'],
          ].map(([icon, text]) => (
            <div className="login-feat" key={text}><span>{icon}</span>{text}</div>
          ))}
        </div>

        {/* Backend Status */}
        <div style={{ position:'absolute', bottom:60, left:28, right:28 }}>
          <div style={{ background:'rgba(255,255,255,0.07)', borderRadius:10, padding:'10px 14px', display:'flex', alignItems:'center', gap:10 }}>
            <div style={{ width:8, height:8, borderRadius:'50%', background: checking ? '#fbbf24' : backendOn ? '#34d399' : '#f87171', flexShrink:0, boxShadow:`0 0 6px ${checking?'#fbbf24':backendOn?'#34d399':'#f87171'}` }}></div>
            <div>
              <div style={{ fontSize:11, fontWeight:700, color:'rgba(255,255,255,0.9)' }}>
                {checking ? 'Checking server...' : backendOn ? '🚀 Backend Connected' : '💾 Offline Mode'}
              </div>
              <div style={{ fontSize:10, color:'rgba(255,255,255,0.4)', marginTop:1 }}>
                {checking ? 'Please wait...' : backendOn ? 'MongoDB + JWT Auth Active' : 'Using local data — works without backend'}
              </div>
            </div>
          </div>
        </div>

        <div style={{ position:'absolute', bottom:24, left:0, right:0, textAlign:'center', fontSize:11, color:'rgba(255,255,255,0.2)' }}>
          Built for Hackathon 2026 • EduSync v3.0
        </div>
      </div>

      {/* ── Right Panel ── */}
      <div className="login-right">
        <form className="login-form" onSubmit={handleSubmit}>
          {/* Logo */}
          <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:28 }}>
            <div style={{ width:44, height:44, background:'linear-gradient(135deg,#6375ff,#a78bfa)', borderRadius:12, display:'flex', alignItems:'center', justifyContent:'center', fontSize:22 }}>🎓</div>
            <div>
              <div style={{ fontWeight:800, fontSize:20, color:'#1e293b', fontFamily:'Syne,sans-serif' }}>EduSync</div>
              <div style={{ fontSize:12, color:'#94a3b8' }}>Academic Portal v3.0</div>
            </div>
          </div>

          <h2 style={{ fontSize:24, color:'#1e293b', marginBottom:4 }}>Welcome back!</h2>
          <p style={{ color:'#64748b', fontSize:13, marginBottom:24 }}>Sign in to access your dashboard</p>

          {/* Error */}
          {error && <div className="login-error">⚠️ {error}</div>}

          {/* Email */}
          <div className="login-group">
            <label>Email Address</label>
            <input type="email" value={email} onChange={e => { setEmail(e.target.value); setError(''); }} placeholder="your.email@college.edu" required autoFocus />
          </div>

          {/* Password */}
          <div className="login-group" style={{ position:'relative' }}>
            <label>Password</label>
            <input type={showPw ? 'text' : 'password'} value={password} onChange={e => { setPassword(e.target.value); setError(''); }} placeholder="Enter your password" required style={{ paddingRight:44 }} />
            <button type="button" onClick={() => setShowPw(!showPw)} style={{ position:'absolute', right:13, top:34, background:'none', border:'none', cursor:'pointer', fontSize:18, color:'#94a3b8' }}>
              {showPw ? '🙈' : '👁️'}
            </button>
          </div>

          {/* Sign In Button */}
          <button className="btn-login" type="submit" disabled={loading || checking}>
            {loading ? '⏳ Signing in...' : checking ? '⏳ Checking server...' : 'Sign In →'}
          </button>

          {/* Divider */}
          <div style={{ display:'flex', alignItems:'center', gap:12, margin:'20px 0' }}>
            <div style={{ flex:1, height:1, background:'#e2e8f0' }}></div>
            <span style={{ fontSize:11, color:'#94a3b8', fontWeight:600 }}>QUICK LOGIN</span>
            <div style={{ flex:1, height:1, background:'#e2e8f0' }}></div>
          </div>

          {/* Quick Login — Main 4 */}
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginBottom:8 }}>
            {LOCAL_USERS.slice(0, 4).map(u => (
              <button key={u.email} type="button" onClick={() => quickLogin(u)}
                style={{ padding:'9px 8px', background:'#f8fafc', border:'1.5px solid #e2e8f0', borderRadius:10, cursor:'pointer', fontSize:11, fontWeight:600, color:'#374151', fontFamily:'DM Sans,sans-serif', transition:'.2s', textAlign:'center' }}
                onMouseEnter={e => { e.currentTarget.style.background='#f1f5f9'; e.currentTarget.style.borderColor='#6375ff'; }}
                onMouseLeave={e => { e.currentTarget.style.background='#f8fafc'; e.currentTarget.style.borderColor='#e2e8f0'; }}>
                <div style={{ fontSize:16, marginBottom:3 }}>{u.role === 'admin' ? '🛡️' : '👤'}</div>
                <div style={{ fontWeight:700 }}>{u.name.split(' ')[0]}</div>
                <div style={{ fontSize:10, color:'#94a3b8', marginTop:1 }}>{u.deptCode} • {u.role === 'admin' ? 'Admin' : 'Student'}</div>
              </button>
            ))}
          </div>

          {/* Quick Login — Other depts */}
          <div style={{ display:'grid', gridTemplateColumns:'repeat(5,1fr)', gap:6 }}>
            {LOCAL_USERS.slice(4).map(u => (
              <button key={u.email} type="button" onClick={() => quickLogin(u)}
                style={{ padding:'7px 4px', background:'#f8fafc', border:'1.5px solid #e2e8f0', borderRadius:9, cursor:'pointer', fontSize:10, fontWeight:600, color:'#374151', fontFamily:'DM Sans,sans-serif', transition:'.2s', textAlign:'center' }}
                onMouseEnter={e => { e.currentTarget.style.background='#f1f5f9'; e.currentTarget.style.borderColor='#6375ff'; }}
                onMouseLeave={e => { e.currentTarget.style.background='#f8fafc'; e.currentTarget.style.borderColor='#e2e8f0'; }}>
                <div style={{ fontSize:14, marginBottom:2 }}>👤</div>
                <div style={{ fontWeight:700 }}>{u.deptCode}</div>
              </button>
            ))}
          </div>
        </form>
      </div>
    </div>
  );
}
