import React, { useState } from 'react';

const ALL_DEPTS = [
  // Engineering
  { name:'Computer Science & Engineering',         code:'CSE',  shortName:'CSE',  color:'#6375ff', icon:'💻', hod:'Dr. R. Kavitha',  students:240, category:'Engineering',  sems:8, desc:'Core CS with programming, algorithms, AI/ML and software engineering.' },
  { name:'Information Technology',                 code:'IT',   shortName:'IT',   color:'#0891b2', icon:'🌐', hod:'Dr. S. Priya',    students:180, category:'Engineering',  sems:8, desc:'Web development, networking, databases and software systems.' },
  { name:'Electronics & Communication Engg',       code:'ECE',  shortName:'ECE',  color:'#d97706', icon:'📡', hod:'Dr. P. Ramesh',   students:200, category:'Engineering',  sems:8, desc:'Signal processing, communication systems, VLSI and embedded systems.' },
  { name:'Electrical & Electronics Engineering',   code:'EEE',  shortName:'EEE',  color:'#059669', icon:'⚡', hod:'Dr. K. Murugan',  students:160, category:'Engineering',  sems:8, desc:'Power systems, electrical machines, control systems and smart grids.' },
  { name:'Mechanical Engineering',                 code:'MECH', shortName:'MECH', color:'#be123c', icon:'⚙️', hod:'Dr. V. Suresh',   students:220, category:'Engineering',  sems:8, desc:'Manufacturing, thermodynamics, design of machines and fluid mechanics.' },
  { name:'Civil Engineering',                      code:'CIVIL',shortName:'CIVIL',color:'#92400e', icon:'🏗️', hod:'Dr. T. Anand',    students:160, category:'Engineering',  sems:8, desc:'Structural engineering, construction, transportation and environmental engineering.' },
  { name:'Chemical Engineering',                   code:'CHEM', shortName:'CHEM', color:'#065f46', icon:'🧪', hod:'Dr. M. Lakshmi',  students:120, category:'Engineering',  sems:8, desc:'Process design, chemical reactions, plant design and petroleum engineering.' },
  { name:'Aerospace Engineering',                  code:'AERO', shortName:'AERO', color:'#1e3a8a', icon:'✈️', hod:'Dr. N. Karthik',  students:100, category:'Engineering',  sems:8, desc:'Aeronautics, propulsion, flight mechanics and spacecraft design.' },
  // Specialised
  { name:'VLSI Design',                            code:'VLSI', shortName:'VLSI', color:'#7c3aed', icon:'🔬', hod:'Dr. A. Senthil',  students:60,  category:'Specialised', sems:8, desc:'Advanced chip design, FPGA, Cadence EDA tools and physical design.' },
  { name:'Artificial Intelligence & ML',           code:'AIML', shortName:'AIML', color:'#db2777', icon:'🤖', hod:'Dr. B. Divya',    students:120, category:'Specialised', sems:8, desc:'Deep learning, NLP, computer vision, model deployment and AI ethics.' },
  { name:'Cyber Security',                         code:'CYS',  shortName:'CyS',  color:'#dc2626', icon:'🔐', hod:'Dr. C. Vijay',    students:80,  category:'Specialised', sems:8, desc:'Ethical hacking, cryptography, network security and digital forensics.' },
  { name:'Internet of Things',                     code:'IOT',  shortName:'IoT',  color:'#0284c7', icon:'📶', hod:'Dr. D. Meena',    students:60,  category:'Specialised', sems:8, desc:'Embedded sensors, cloud integration, MQTT and smart systems design.' },
  { name:'Robotics & Automation',                  code:'ROB',  shortName:'ROB',  color:'#ea580c', icon:'🦾', hod:'Dr. E. Suresh',   students:60,  category:'Specialised', sems:8, desc:'Robot kinematics, PLC programming, autonomous systems and Industry 4.0.' },
  { name:'Data Science',                           code:'DSC',  shortName:'DS',   color:'#0891b2', icon:'📊', hod:'Dr. F. Nisha',    students:100, category:'Specialised', sems:8, desc:'Statistical learning, big data, visualization and business intelligence.' },
  // Science
  { name:'Biotechnology',                          code:'BIO',  shortName:'BIO',  color:'#16a34a', icon:'🧬', hod:'Dr. G. Preethi',  students:80,  category:'Science',     sems:8, desc:'Genetic engineering, molecular biology, bioprocess and immunology.' },
  { name:'Biomedical Engineering',                 code:'BME',  shortName:'BME',  color:'#0d9488', icon:'🏥', hod:'Dr. H. Saranya',  students:60,  category:'Science',     sems:8, desc:'Medical instruments, imaging, biomechanics and tissue engineering.' },
  { name:'Physics',                                code:'PHY',  shortName:'PHY',  color:'#4338ca', icon:'⚛️', hod:'Dr. I. Ramesh',   students:60,  category:'Science',     sems:8, desc:'Quantum mechanics, optics, condensed matter and computational physics.' },
  { name:'Mathematics',                            code:'MATH', shortName:'MATH', color:'#0369a1', icon:'📐', hod:'Dr. J. Kavya',    students:60,  category:'Science',     sems:8, desc:'Pure & applied math, statistics, numerical methods and operations research.' },
  // Management
  { name:'Master of Business Administration',      code:'MBA',  shortName:'MBA',  color:'#b45309', icon:'📈', hod:'Dr. K. Arjun',    students:120, category:'Management',  sems:4, desc:'Marketing, finance, HR, operations and entrepreneurship for industry leaders.' },
  { name:'Master of Computer Applications',        code:'MCA',  shortName:'MCA',  color:'#6d28d9', icon:'🖥️', hod:'Dr. L. Rekha',    students:60,  category:'Management',  sems:6, desc:'Advanced programming, system software, web and mobile app development.' },
];

const SUBJECTS = {
  CSE:  [{n:'Data Structures & Algorithms',c:'CS3401',cr:4,t:'Theory',col:'#6375ff'},{n:'Database Management Systems',c:'CS3402',cr:3,t:'Theory',col:'#0891b2'},{n:'Operating Systems',c:'CS3403',cr:4,t:'Theory',col:'#d97706'},{n:'Computer Networks',c:'CS3404',cr:3,t:'Theory',col:'#059669'},{n:'Probability & Statistics',c:'MA3451',cr:4,t:'Theory',col:'#7c3aed'},{n:'DS Lab',c:'CS3411',cr:2,t:'Lab',col:'#be123c'}],
  IT:   [{n:'Web Technology',c:'IT3401',cr:4,t:'Theory',col:'#6375ff'},{n:'Software Engineering',c:'IT3402',cr:3,t:'Theory',col:'#0891b2'},{n:'Database Management',c:'IT3403',cr:3,t:'Theory',col:'#d97706'},{n:'Computer Networks',c:'IT3404',cr:4,t:'Theory',col:'#059669'},{n:'Probability & Queueing Theory',c:'MA3452',cr:4,t:'Theory',col:'#7c3aed'},{n:'Web Technology Lab',c:'IT3411',cr:2,t:'Lab',col:'#be123c'}],
  ECE:  [{n:'Digital Signal Processing',c:'EC3501',cr:4,t:'Theory',col:'#6375ff'},{n:'Microprocessors & Controllers',c:'EC3502',cr:3,t:'Theory',col:'#0891b2'},{n:'Electromagnetic Fields',c:'EC3503',cr:4,t:'Theory',col:'#d97706'},{n:'Communication Theory',c:'EC3504',cr:3,t:'Theory',col:'#059669'},{n:'VLSI Design',c:'EC3505',cr:4,t:'Theory',col:'#7c3aed'},{n:'DSP Lab',c:'EC3511',cr:2,t:'Lab',col:'#be123c'}],
  EEE:  [{n:'Power Systems Analysis',c:'EE3501',cr:4,t:'Theory',col:'#6375ff'},{n:'Electrical Machines II',c:'EE3502',cr:3,t:'Theory',col:'#0891b2'},{n:'Control Systems',c:'EE3503',cr:4,t:'Theory',col:'#d97706'},{n:'Power Electronics',c:'EE3504',cr:3,t:'Theory',col:'#059669'},{n:'Signals & Systems',c:'EE3505',cr:4,t:'Theory',col:'#7c3aed'},{n:'Machines Lab',c:'EE3511',cr:2,t:'Lab',col:'#be123c'}],
  MECH: [{n:'Heat & Mass Transfer',c:'ME3501',cr:4,t:'Theory',col:'#6375ff'},{n:'Design of Machine Elements',c:'ME3502',cr:3,t:'Theory',col:'#0891b2'},{n:'Manufacturing Technology II',c:'ME3503',cr:4,t:'Theory',col:'#d97706'},{n:'Fluid Mechanics & Machinery',c:'ME3504',cr:3,t:'Theory',col:'#059669'},{n:'Engineering Materials',c:'ME3505',cr:4,t:'Theory',col:'#7c3aed'},{n:'Manufacturing Lab',c:'ME3511',cr:2,t:'Lab',col:'#be123c'}],
  VLSI: [{n:'VLSI Design & Technology',c:'VL3501',cr:4,t:'Theory',col:'#7c3aed'},{n:'Analog IC Design',c:'VL3502',cr:3,t:'Theory',col:'#6375ff'},{n:'FPGA & Embedded Systems',c:'VL3503',cr:4,t:'Theory',col:'#0891b2'},{n:'Physical Design & EDA',c:'VL3504',cr:3,t:'Theory',col:'#d97706'},{n:'Testing & Verification',c:'VL3505',cr:4,t:'Theory',col:'#059669'},{n:'VLSI Design Lab',c:'VL3511',cr:2,t:'Lab',col:'#be123c'}],
  AIML: [{n:'Machine Learning',c:'AI3501',cr:4,t:'Theory',col:'#db2777'},{n:'Deep Learning',c:'AI3502',cr:3,t:'Theory',col:'#7c3aed'},{n:'Natural Language Processing',c:'AI3503',cr:4,t:'Theory',col:'#6375ff'},{n:'Computer Vision',c:'AI3504',cr:3,t:'Theory',col:'#0891b2'},{n:'AI Ethics & Applications',c:'AI3505',cr:4,t:'Theory',col:'#059669'},{n:'ML Lab (Python/TensorFlow)',c:'AI3511',cr:2,t:'Lab',col:'#be123c'}],
  CYS:  [{n:'Network Security',c:'CY3501',cr:4,t:'Theory',col:'#dc2626'},{n:'Cryptography',c:'CY3502',cr:3,t:'Theory',col:'#7c3aed'},{n:'Ethical Hacking & Pen Testing',c:'CY3503',cr:4,t:'Theory',col:'#6375ff'},{n:'Digital Forensics',c:'CY3504',cr:3,t:'Theory',col:'#0891b2'},{n:'Malware Analysis',c:'CY3505',cr:4,t:'Theory',col:'#059669'},{n:'Cybersecurity Lab',c:'CY3511',cr:2,t:'Lab',col:'#be123c'}],
  BIO:  [{n:'Molecular Biology',c:'BT3501',cr:4,t:'Theory',col:'#16a34a'},{n:'Genetic Engineering',c:'BT3502',cr:3,t:'Theory',col:'#0891b2'},{n:'Biochemistry',c:'BT3503',cr:4,t:'Theory',col:'#d97706'},{n:'Bioprocess Technology',c:'BT3504',cr:3,t:'Theory',col:'#7c3aed'},{n:'Immunology',c:'BT3505',cr:4,t:'Theory',col:'#059669'},{n:'Biotech Lab',c:'BT3511',cr:2,t:'Lab',col:'#be123c'}],
  BME:  [{n:'Medical Instrumentation',c:'BM3501',cr:4,t:'Theory',col:'#0d9488'},{n:'Biomechanics',c:'BM3502',cr:3,t:'Theory',col:'#6375ff'},{n:'DSP for Biomedical',c:'BM3503',cr:4,t:'Theory',col:'#0891b2'},{n:'Medical Imaging',c:'BM3504',cr:3,t:'Theory',col:'#d97706'},{n:'Tissue Engineering',c:'BM3505',cr:4,t:'Theory',col:'#7c3aed'},{n:'Biomedical Lab',c:'BM3511',cr:2,t:'Lab',col:'#be123c'}],
  IOT:  [{n:'IoT Architecture & Protocols',c:'IO3501',cr:4,t:'Theory',col:'#0284c7'},{n:'Embedded Systems for IoT',c:'IO3502',cr:3,t:'Theory',col:'#7c3aed'},{n:'Cloud Computing for IoT',c:'IO3503',cr:4,t:'Theory',col:'#6375ff'},{n:'IoT Security',c:'IO3504',cr:3,t:'Theory',col:'#dc2626'},{n:'IoT Applications',c:'IO3505',cr:4,t:'Theory',col:'#059669'},{n:'IoT Lab',c:'IO3511',cr:2,t:'Lab',col:'#be123c'}],
  DSC:  [{n:'Statistical Learning',c:'DS3501',cr:4,t:'Theory',col:'#0891b2'},{n:'Big Data Analytics',c:'DS3502',cr:3,t:'Theory',col:'#7c3aed'},{n:'Data Visualization',c:'DS3503',cr:4,t:'Theory',col:'#6375ff'},{n:'Database Systems',c:'DS3504',cr:3,t:'Theory',col:'#d97706'},{n:'Business Intelligence',c:'DS3505',cr:4,t:'Theory',col:'#059669'},{n:'Data Science Lab',c:'DS3511',cr:2,t:'Lab',col:'#be123c'}],
};

const CAREERS = {
  CSE:  { jobs:['Software Engineer','Full Stack Dev','DevOps Engineer','Cloud Architect','ML Engineer'], companies:['Google','Microsoft','Amazon','TCS','Infosys'], avgCTC:'₹8–45 LPA', topSalary:'₹1 Cr+ (FAANG)' },
  IT:   { jobs:['Web Developer','System Analyst','IT Consultant','Network Engineer','DB Admin'], companies:['Wipro','HCL','Accenture','TCS','Zoho'], avgCTC:'₹6–20 LPA', topSalary:'₹50 LPA' },
  ECE:  { jobs:['VLSI Engineer','Embedded Engineer','RF Engineer','Signal Processing Eng','Network Eng'], companies:['Qualcomm','Intel','ISRO','Texas Instruments','Samsung'], avgCTC:'₹5–25 LPA', topSalary:'₹60 LPA' },
  EEE:  { jobs:['Power Engineer','Control Systems Eng','EV Engineer','Smart Grid Specialist','Protection Eng'], companies:['BHEL','NTPC','Siemens','ABB','L&T'], avgCTC:'₹5–18 LPA', topSalary:'₹40 LPA (abroad)' },
  MECH: { jobs:['Design Engineer','Manufacturing Eng','CAE Engineer','Automotive Eng','Project Manager'], companies:['TATA Motors','L&T','Mahindra','Caterpillar','Bosch'], avgCTC:'₹4–15 LPA', topSalary:'₹35 LPA' },
  VLSI: { jobs:['VLSI Design Engineer','RTL Designer','Physical Design Engineer','Verification Eng','ASIC Engineer'], companies:['Qualcomm','Intel','ARM','MediaTek','Cadence'], avgCTC:'₹8–35 LPA', topSalary:'₹80 LPA' },
  AIML: { jobs:['ML Engineer','Data Scientist','NLP Engineer','Computer Vision Eng','AI Researcher'], companies:['Google DeepMind','OpenAI','Microsoft','Amazon','Nvidia'], avgCTC:'₹10–50 LPA', topSalary:'₹1.5 Cr+' },
  CYS:  { jobs:['Security Analyst','Pen Tester','Forensic Analyst','SOC Engineer','Cloud Security'], companies:['Palo Alto','CrowdStrike','IBM Security','Deloitte','Wipro CyberSec'], avgCTC:'₹8–30 LPA', topSalary:'₹70 LPA' },
  BIO:  { jobs:['Research Scientist','Bioprocess Engineer','Quality Control Analyst','Clinical Research Assoc','Bioinformatics Scientist'], companies:['Biocon','Dr. Reddys','CSIR','Serum Institute','Pfizer'], avgCTC:'₹4–15 LPA', topSalary:'₹40 LPA (research)' },
  BME:  { jobs:['Biomedical Engineer','Clinical Engineer','Medical Device Designer','R&D Engineer','Hospital Equipment Specialist'], companies:['GE Healthcare','Siemens Healthineers','Philips','Medtronic','Johnson & Johnson'], avgCTC:'₹5–20 LPA', topSalary:'₹50 LPA' },
  IOT:  { jobs:['IoT Solutions Architect','Embedded IoT Engineer','IoT Security Specialist','Cloud IoT Engineer','Product Manager'], companies:['Bosch','Cisco','AWS IoT','Microsoft Azure','Siemens'], avgCTC:'₹7–25 LPA', topSalary:'₹55 LPA' },
  DSC:  { jobs:['Data Scientist','Data Analyst','BI Analyst','ML Engineer','Research Analyst'], companies:['Google','Amazon','Mu Sigma','Fractal Analytics','Accenture Analytics'], avgCTC:'₹8–35 LPA', topSalary:'₹1 Cr+' },
};

const CATEGORIES = ['All', 'Engineering', 'Specialised', 'Science', 'Management'];

export default function Departments({ showToast }) {
  const [search,   setSearch]   = useState('');
  const [cat,      setCat]      = useState('All');
  const [selected, setSelected] = useState(null);
  const [tab,      setTab]      = useState('subjects');

  const filtered = ALL_DEPTS.filter(d =>
    (cat === 'All' || d.category === cat) &&
    (!search || d.name.toLowerCase().includes(search.toLowerCase()) || d.code.toLowerCase().includes(search.toLowerCase()))
  );

  const CAT_STATS = {
    Engineering: ALL_DEPTS.filter(d=>d.category==='Engineering').length,
    Specialised: ALL_DEPTS.filter(d=>d.category==='Specialised').length,
    Science:     ALL_DEPTS.filter(d=>d.category==='Science').length,
    Management:  ALL_DEPTS.filter(d=>d.category==='Management').length,
  };

  return (
    <div className="page">
      {/* Header */}
      <div className="page-header">
        <h2>All Departments 🏛️</h2>
        <p>Explore all {ALL_DEPTS.length} departments — subjects, career paths & opportunities</p>
      </div>

      {/* Stats */}
      <div className="grid-4" style={{marginBottom:22}}>
        {[['🏛️','Total Depts',ALL_DEPTS.length,'#6375ff'],
          ['🎓','Engineering',CAT_STATS.Engineering,'#0891b2'],
          ['⚡','Specialised',CAT_STATS.Specialised,'#db2777'],
          ['🧬','Science & Mgmt',CAT_STATS.Science+CAT_STATS.Management,'#16a34a']
        ].map(([icon,label,val,color])=>(
          <div key={label} className="card card-sm" style={{display:'flex',alignItems:'center',gap:10}}>
            <div style={{width:42,height:42,borderRadius:11,background:`${color}22`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:20,flexShrink:0}}>{icon}</div>
            <div>
              <div style={{fontSize:24,fontWeight:800,fontFamily:'Syne,sans-serif',color}}>{val}</div>
              <div style={{fontSize:11,color:'var(--muted)'}}>{label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Search */}
      <div style={{position:'relative',marginBottom:14}}>
        <span style={{position:'absolute',left:14,top:'50%',transform:'translateY(-50%)'}}>🔍</span>
        <input type="text" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search departments..." style={{paddingLeft:42}}/>
      </div>

      {/* Category Filter */}
      <div style={{display:'flex',gap:8,flexWrap:'wrap',marginBottom:22}}>
        {CATEGORIES.map(c=>(
          <button key={c} className={`filter-btn ${cat===c?'active':''}`} onClick={()=>setCat(c)}>
            {c==='All'?'🏛️ All':c==='Engineering'?'⚙️ Engineering':c==='Specialised'?'⚡ Specialised':c==='Science'?'🧬 Science':'📈 Management'} {c!=='All'&&`(${CAT_STATS[c]||''})`}
          </button>
        ))}
      </div>

      {/* Department Cards Grid */}
      <div className="grid-4" style={{marginBottom:32}}>
        {filtered.map(dept=>(
          <div key={dept.code} className="card" onClick={()=>{setSelected(dept);setTab('subjects');}}
            style={{cursor:'pointer',borderTop:`3px solid ${dept.color}`,transition:'.2s',padding:16}}
            onMouseEnter={e=>e.currentTarget.style.transform='translateY(-4px)'}
            onMouseLeave={e=>e.currentTarget.style.transform='none'}>
            {/* Icon + Category */}
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:10}}>
              <div style={{width:46,height:46,borderRadius:13,background:`${dept.color}18`,border:`2px solid ${dept.color}33`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:22}}>
                {dept.icon}
              </div>
              <span style={{background:`${dept.color}15`,color:dept.color,fontSize:9,fontWeight:700,padding:'3px 8px',borderRadius:20,textTransform:'uppercase'}}>
                {dept.category}
              </span>
            </div>
            {/* Name */}
            <div style={{fontSize:13,fontWeight:700,marginBottom:3,lineHeight:1.3}}>{dept.shortName}</div>
            <div style={{fontSize:10,color:'var(--muted)',marginBottom:10,lineHeight:1.4}}>{dept.name}</div>
            {/* Info Row */}
            <div style={{display:'flex',gap:6,flexWrap:'wrap',marginBottom:10}}>
              <span className="tag tag-blue" style={{fontSize:9}}>👥 {dept.students}</span>
              <span className="tag tag-purple" style={{fontSize:9}}>📚 {dept.sems} Sem</span>
            </div>
            {/* HOD */}
            <div style={{fontSize:10,color:'var(--muted)',borderTop:'1px solid var(--border)',paddingTop:8}}>
              HOD: <span style={{fontWeight:600,color:'var(--text)'}}>{dept.hod.replace('Dr. ','')}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Department Detail Modal */}
      {selected && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setSelected(null)}>
          <div className="modal" style={{maxWidth:720}}>
            {/* Modal Header */}
            <div className="modal-header">
              <div style={{display:'flex',alignItems:'center',gap:14}}>
                <div style={{width:56,height:56,borderRadius:15,background:`${selected.color}18`,border:`2px solid ${selected.color}40`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:26}}>
                  {selected.icon}
                </div>
                <div>
                  <h3 style={{fontSize:17}}>{selected.name}</h3>
                  <p style={{color:'var(--muted)',fontSize:12,marginTop:2}}>Code: {selected.code} • HOD: {selected.hod}</p>
                </div>
              </div>
              <button className="modal-close" onClick={()=>setSelected(null)}>×</button>
            </div>

            {/* Dept Description */}
            <p style={{fontSize:13,color:'var(--muted)',lineHeight:1.8,marginBottom:18}}>{selected.desc}</p>

            {/* Quick Stats */}
            <div className="grid-4" style={{marginBottom:18}}>
              {[['👥','Students',selected.students],['📚','Semesters',selected.sems],['🎓','Category',selected.category],['🏷️','Code',selected.code]].map(([ic,l,v])=>(
                <div key={l} style={{background:'var(--bg3)',borderRadius:10,padding:'10px 12px',textAlign:'center'}}>
                  <div style={{fontSize:11,color:'var(--muted)',marginBottom:3}}>{ic} {l}</div>
                  <div style={{fontSize:14,fontWeight:700}}>{v}</div>
                </div>
              ))}
            </div>

            {/* Tabs */}
            <div style={{display:'flex',gap:8,marginBottom:16}}>
              {[['subjects','📚 Subjects'],['career','💼 Career'],['internships','🏢 Opportunities']].map(([t,l])=>(
                <button key={t} className={`filter-btn ${tab===t?'active':''}`} onClick={()=>setTab(t)} style={{padding:'7px 14px',fontWeight:700}}>{l}</button>
              ))}
            </div>

            {/* Subjects Tab */}
            {tab==='subjects' && (
              <div>
                <div style={{fontSize:13,fontWeight:700,marginBottom:12}}>📚 Semester 5 Subjects</div>
                {(SUBJECTS[selected.code]||[]).length > 0 ? (
                  <div style={{display:'flex',flexDirection:'column',gap:8}}>
                    {(SUBJECTS[selected.code]||[]).map(s=>(
                      <div key={s.c} style={{display:'flex',alignItems:'center',gap:12,background:'var(--bg3)',borderRadius:10,padding:'11px 14px',borderLeft:`3px solid ${s.col}`}}>
                        <div style={{width:36,height:36,borderRadius:9,background:`${s.col}20`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:11,fontWeight:800,color:s.col,flexShrink:0}}>{s.t==='Lab'?'🔬':'📖'}</div>
                        <div style={{flex:1}}>
                          <div style={{fontSize:13,fontWeight:600}}>{s.n}</div>
                          <div style={{fontSize:11,color:'var(--muted)',marginTop:2}}>{s.c} • {s.cr} Credits</div>
                        </div>
                        <span className={`tag ${s.t==='Lab'?'tag-orange':'tag-blue'}`} style={{fontSize:10}}>{s.t}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div style={{textAlign:'center',padding:'30px',color:'var(--muted)',fontSize:13}}>
                    📋 Subjects coming soon for {selected.name}
                  </div>
                )}
              </div>
            )}

            {/* Career Tab */}
            {tab==='career' && (
              <div>
                {CAREERS[selected.code] ? (
                  <>
                    <div className="grid-2" style={{marginBottom:16}}>
                      <div style={{background:'rgba(99,117,255,0.08)',border:'1px solid rgba(99,117,255,0.2)',borderRadius:11,padding:'14px'}}>
                        <div style={{fontSize:12,fontWeight:700,color:'#6375ff',marginBottom:8}}>💰 Salary Range</div>
                        <div style={{fontSize:18,fontWeight:800,fontFamily:'Syne,sans-serif'}}>{CAREERS[selected.code].avgCTC}</div>
                        <div style={{fontSize:11,color:'var(--muted)',marginTop:3}}>Top: {CAREERS[selected.code].topSalary}</div>
                      </div>
                      <div style={{background:'rgba(52,211,153,0.08)',border:'1px solid rgba(52,211,153,0.2)',borderRadius:11,padding:'14px'}}>
                        <div style={{fontSize:12,fontWeight:700,color:'#34d399',marginBottom:8}}>🏢 Top Recruiters</div>
                        {CAREERS[selected.code].companies.slice(0,3).map(co=>(
                          <div key={co} style={{fontSize:12,padding:'3px 0',color:'var(--text)'}}>{co}</div>
                        ))}
                      </div>
                    </div>
                    <div style={{fontSize:13,fontWeight:700,marginBottom:10}}>👔 Job Roles</div>
                    <div style={{display:'flex',flexWrap:'wrap',gap:8}}>
                      {CAREERS[selected.code].jobs.map(j=>(
                        <span key={j} style={{background:`${selected.color}15`,color:selected.color,padding:'6px 13px',borderRadius:20,fontSize:12,fontWeight:600}}>{j}</span>
                      ))}
                    </div>
                  </>
                ) : (
                  <div style={{textAlign:'center',padding:'30px',color:'var(--muted)'}}>Career details coming soon!</div>
                )}
              </div>
            )}

            {/* Internships Tab */}
            {tab==='internships' && (
              <div>
                <div style={{fontSize:13,fontWeight:700,marginBottom:12}}>🏢 Eligible Opportunities for {selected.shortName}</div>
                {[
                  {co:'TCS', ctc:'₹7 LPA', type:'Placement', eligible:['CSE','IT','ECE','EEE','MECH','CYS','DSC','AIML','IOT']},
                  {co:'Infosys', ctc:'₹6.5 LPA', type:'Placement', eligible:['CSE','IT','ECE','AIML','DSC','MBA','MCA']},
                  {co:'Google', ctc:'₹45 LPA', type:'Placement', eligible:['CSE','IT','AIML','DSC','CYS']},
                  {co:'ISRO', ctc:'Unpaid', type:'Internship', eligible:['ECE','EEE','MECH','AERO','VLSI']},
                  {co:'Biocon', ctc:'₹6 LPA', type:'Placement', eligible:['BIO','BME','CHEM']},
                  {co:'Qualcomm', ctc:'₹35 LPA', type:'Placement', eligible:['VLSI','ECE','EEE']},
                  {co:'GE Healthcare', ctc:'₹12 LPA', type:'Placement', eligible:['BME','EEE','ECE']},
                  {co:'L&T', ctc:'₹8 LPA', type:'Placement', eligible:['MECH','CIVIL','EEE','CHEM','AERO']},
                ].filter(op=>op.eligible.includes(selected.code)).map(op=>(
                  <div key={op.co} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'11px 14px',background:'var(--bg3)',borderRadius:10,marginBottom:8}}>
                    <div>
                      <div style={{fontSize:13,fontWeight:700}}>{op.co}</div>
                      <div style={{fontSize:11,color:'var(--muted)',marginTop:2}}>{op.type}</div>
                    </div>
                    <div style={{display:'flex',gap:8,alignItems:'center'}}>
                      <span className="tag tag-green" style={{fontSize:10}}>{op.ctc}</span>
                      <button className="btn btn-primary btn-sm" onClick={()=>{showToast(`Check ${op.co} in Placements page!`,'💼');setSelected(null);}}>View →</button>
                    </div>
                  </div>
                ))}
                {[
                  {co:'TCS', ctc:'₹7 LPA', type:'Placement', eligible:['CSE','IT','ECE','EEE','MECH','CYS','DSC','AIML','IOT']},
                  {co:'Infosys', ctc:'₹6.5 LPA', type:'Placement', eligible:['CSE','IT','ECE','AIML','DSC','MBA','MCA']},
                  {co:'Google', ctc:'₹45 LPA', type:'Placement', eligible:['CSE','IT','AIML','DSC','CYS']},
                  {co:'ISRO', ctc:'Unpaid', type:'Internship', eligible:['ECE','EEE','MECH','AERO','VLSI']},
                  {co:'Biocon', ctc:'₹6 LPA', type:'Placement', eligible:['BIO','BME','CHEM']},
                  {co:'Qualcomm', ctc:'₹35 LPA', type:'Placement', eligible:['VLSI','ECE','EEE']},
                  {co:'GE Healthcare', ctc:'₹12 LPA', type:'Placement', eligible:['BME','EEE','ECE']},
                  {co:'L&T', ctc:'₹8 LPA', type:'Placement', eligible:['MECH','CIVIL','EEE','CHEM','AERO']},
                ].filter(op=>op.eligible.includes(selected.code)).length === 0 && (
                  <div style={{textAlign:'center',padding:'30px',color:'var(--muted)'}}>More opportunities being added for {selected.name}</div>
                )}
              </div>
            )}

            <div className="modal-actions">
              <button className="btn btn-ghost" onClick={()=>setSelected(null)}>Close</button>
              <button className="btn btn-primary" onClick={()=>{showToast(`Viewing ${selected.shortName} roadmap!`,'🗺️');setSelected(null);}}>View Roadmap 🗺️</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
