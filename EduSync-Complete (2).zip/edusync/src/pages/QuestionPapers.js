import React, { useState } from 'react';
export default function QuestionPapers({ showToast }) {
  const [filter, setFilter] = useState('All');
  const [search, setSearch] = useState('');
  const QPS=[
    {id:1,subject:'Data Structures',code:'CS3401',sem:5,year:'2024-25',type:'Internal I',color:'#6375ff',partA:['Define AVL tree','What is BFS?','Explain hashing'],partB:['Implement Merge Sort with analysis','Compare all sorting algorithms']},
    {id:2,subject:'Database Management',code:'CS3402',sem:5,year:'2024-25',type:'Internal I',color:'#0891b2',partA:['What is ACID?','Define 3NF','Explain B+ tree'],partB:['Design ER diagram for library system','Normalize given relation to BCNF']},
    {id:3,subject:'Operating Systems',code:'CS3403',sem:5,year:'2023-24',type:'Internal II',color:'#d97706',partA:["What is Banker's Algorithm?",'Explain paging','Define semaphore'],partB:['Compare all CPU scheduling algorithms','Explain deadlock detection and recovery']},
    {id:4,subject:'Computer Networks',code:'CS3404',sem:5,year:'2024-25',type:'Internal I',color:'#059669',partA:['Explain OSI model','What is TCP?','Define subnetting'],partB:['Explain TCP 3-way handshake','Compare routing algorithms']},
    {id:5,subject:'Probability & Stats',code:'MA3451',sem:5,year:'2023-24',type:'Internal I',color:'#7c3aed',partA:['Define random variable','Bayes theorem','Explain normal distribution'],partB:['Solve problems on binomial distribution','Explain hypothesis testing with examples']},
    {id:6,subject:'OOP with Java',code:'CS3302',sem:4,year:'2023-24',type:'Internal I',color:'#be123c',partA:['What is polymorphism?','Define interface','Explain exception handling'],partB:['Design a banking system using OOP','Implement generic stack in Java']},
    {id:7,subject:'Discrete Mathematics',code:'MA3354',sem:3,year:'2022-23',type:'Internal II',color:'#0891b2',partA:['Define proposition','Explain pigeonhole principle','What is group?'],partB:['Prove using mathematical induction','Explain graph coloring with examples']},
    {id:8,subject:'Computer Organization',code:'CS3301',sem:4,year:'2023-24',type:'Internal I',color:'#059669',partA:['Explain ALU','What is pipelining?','Define cache memory'],partB:['Design a 4-bit adder circuit','Explain memory hierarchy']},
  ];
  const sems = ['All','Sem 3','Sem 4','Sem 5'];
  const filtered = QPS.filter(p=>(filter==='All'||(filter==='Sem 3'&&p.sem===3)||(filter==='Sem 4'&&p.sem===4)||(filter==='Sem 5'&&p.sem===5))&&(!search||p.subject.toLowerCase().includes(search.toLowerCase())||p.code.toLowerCase().includes(search.toLowerCase())));
  const [preview, setPreview] = useState(null);
  return (
    <div className="page">
      <div className="page-header"><h2>Question Papers 📄</h2><p>25 previous year internal exam papers — with Part A & Part B preview</p></div>
      <div className="grid-4" style={{marginBottom:18}}>
        {[['📄','Total Papers','25','#6375ff'],['📚','Sem 5','10','#34d399'],['📚','Sem 4','8','#0891b2'],['📚','Sem 1-3','7','#fb923c']].map(([ic,l,v,c])=>(
          <div className="card card-sm" key={l} style={{display:'flex',alignItems:'center',gap:10}}>
            <div style={{width:40,height:40,borderRadius:11,background:`${c}22`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:17,flexShrink:0}}>{ic}</div>
            <div><div style={{fontSize:22,fontWeight:800,fontFamily:'Syne,sans-serif',color:c}}>{v}</div><div style={{fontSize:11,color:'var(--muted)'}}>{l}</div></div>
          </div>
        ))}
      </div>
      <div style={{position:'relative',marginBottom:12}}>
        <span style={{position:'absolute',left:13,top:'50%',transform:'translateY(-50%)'}}>🔍</span>
        <input type="text" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search subject or code..." style={{paddingLeft:40}} />
      </div>
      <div style={{display:'flex',gap:8,marginBottom:18}}>
        {sems.map(s=><button key={s} className={`filter-btn ${filter===s?'active':''}`} onClick={()=>setFilter(s)}>{s}</button>)}
      </div>
      <div className="grid-2">
        {filtered.map(p=>(
          <div key={p.id} className="card" style={{borderLeft:`4px solid ${p.color}`}}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:10}}>
              <div><div style={{fontSize:14,fontWeight:700}}>{p.subject}</div><div style={{fontSize:11,color:'var(--muted)',marginTop:2}}>{p.code} • Sem {p.sem} • {p.year}</div></div>
              <span className="tag tag-purple" style={{fontSize:10}}>{p.type}</span>
            </div>
            <div style={{fontSize:12,color:'var(--muted)',marginBottom:12}}>📝 Part A: {p.partA.length} qs • Part B: {p.partB.length} qs</div>
            <div style={{display:'flex',gap:8}}>
              <button className="btn btn-ghost btn-sm" onClick={()=>setPreview(p)}>Preview 👁</button>
              <button className="btn btn-primary btn-sm" onClick={()=>showToast(`Downloading ${p.subject} paper...`,'⬇️')}>⬇️ Download</button>
            </div>
          </div>
        ))}
      </div>
      {preview && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setPreview(null)}>
          <div className="modal">
            <div className="modal-header">
              <div><h3>{preview.subject}</h3><p style={{color:'var(--muted)',fontSize:13,marginTop:3}}>{preview.code} • {preview.type} • {preview.year}</p></div>
              <button className="modal-close" onClick={()=>setPreview(null)}>×</button>
            </div>
            <div style={{marginBottom:16}}>
              <div style={{fontWeight:700,color:'#6375ff',marginBottom:8}}>Part A — Short Answers (2 marks each)</div>
              {preview.partA.map((q,i)=><div key={i} style={{background:'var(--bg3)',borderRadius:8,padding:'8px 12px',marginBottom:7,fontSize:13}}>Q{i+1}. {q}</div>)}
            </div>
            <div>
              <div style={{fontWeight:700,color:'#34d399',marginBottom:8}}>Part B — Long Answers (16 marks each)</div>
              {preview.partB.map((q,i)=><div key={i} style={{background:'var(--bg3)',borderRadius:8,padding:'8px 12px',marginBottom:7,fontSize:13}}>Q{i+1}. {q}</div>)}
            </div>
            <div className="modal-actions">
              <button className="btn btn-ghost" onClick={()=>setPreview(null)}>Close</button>
              <button className="btn btn-primary" onClick={()=>{showToast('Downloading...','⬇️');setPreview(null);}}>⬇️ Download PDF</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
