import React, { useState } from 'react';
import { EVENTS } from '../data/appData';
export default function Events({ showToast }) {
  const [events, setEvents] = useState(EVENTS);
  const [filter, setFilter] = useState('All');
  const [selected, setSelected] = useState(null);
  const TYPE_COLORS = { Hackathon:'#6375ff', Technical:'#0891b2', Placement:'#34d399', Symposium:'#fb923c', Workshop:'#a78bfa' };
  const types = ['All', ...new Set(EVENTS.map(e=>e.type))];
  const filtered = events.filter(e => filter==='All' || e.type===filter);
  const register = (id, title) => {
    setEvents(p=>p.map(e=>e.id===id?{...e,registered:true}:e));
    showToast(`Registered for ${title} 🎉`, '🎉');
    setSelected(null);
  };
  return (
    <div className="page">
      <div className="page-header"><h2>Events 🎉</h2><p>Upcoming college events, hackathons, workshops & placement drives</p></div>
      <div className="grid-4" style={{marginBottom:18}}>
        {[['🎉','Total Events',EVENTS.length,'#6375ff'],['✅','Registered',events.filter(e=>e.registered).length,'#34d399'],['💻','Hackathons',EVENTS.filter(e=>e.type==='Hackathon').length,'#a78bfa'],['🏆','Total Prizes','₹2,00,000+','#fbbf24']].map(([ic,l,v,c])=>(
          <div className="card card-sm" key={l} style={{display:'flex',alignItems:'center',gap:10}}>
            <div style={{width:40,height:40,borderRadius:11,background:`${c}22`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:18,flexShrink:0}}>{ic}</div>
            <div><div style={{fontSize:22,fontWeight:800,fontFamily:'Syne,sans-serif',color:c}}>{v}</div><div style={{fontSize:11,color:'var(--muted)'}}>{l}</div></div>
          </div>
        ))}
      </div>
      <div style={{display:'flex',gap:8,flexWrap:'wrap',marginBottom:18}}>
        {types.map(t=><button key={t} className={`filter-btn ${filter===t?'active':''}`} onClick={()=>setFilter(t)}>{t}</button>)}
      </div>
      <div className="grid-2">
        {filtered.map(e=>(
          <div key={e.id} className="card" onClick={()=>setSelected(e)} style={{cursor:'pointer',borderLeft:`4px solid ${TYPE_COLORS[e.type]||'#64748b'}`,transition:'.2s'}} onMouseEnter={el=>el.currentTarget.style.transform='translateY(-2px)'} onMouseLeave={el=>el.currentTarget.style.transform='none'}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:9}}>
              <h4 style={{fontSize:13,flex:1,paddingRight:8}}>{e.title}</h4>
              <div style={{display:'flex',flexDirection:'column',alignItems:'flex-end',gap:4}}>
                <span className="tag" style={{background:`${TYPE_COLORS[e.type]||'#64748b'}22`,color:TYPE_COLORS[e.type]||'#64748b',fontSize:10}}>{e.type}</span>
                {e.registered&&<span className="tag tag-green" style={{fontSize:9}}>✅ Registered</span>}
              </div>
            </div>
            <div style={{display:'flex',gap:5,flexWrap:'wrap',marginBottom:9}}>
              <span className="tag tag-blue" style={{fontSize:10}}>📅 {e.date}</span>
              <span className="tag tag-green" style={{fontSize:10}}>🏆 {e.prize}</span>
              <span className="tag tag-purple" style={{fontSize:10}}>👥 Team: {e.teamSize}</span>
            </div>
            <div style={{fontSize:12,color:'var(--muted)',lineHeight:1.6,marginBottom:10}}>{e.desc.slice(0,90)}...</div>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
              <span style={{fontSize:11,color:'var(--muted)'}}>🗓 Reg deadline: {e.deadline}</span>
              <button className={`btn btn-sm ${e.registered?'btn-ghost':'btn-primary'}`} onClick={el=>{el.stopPropagation();register(e.id,e.title);}}>{e.registered?'✅ Registered':'Register →'}</button>
            </div>
          </div>
        ))}
      </div>
      {selected && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setSelected(null)}>
          <div className="modal">
            <div className="modal-header">
              <div>
                <h3>{selected.title}</h3>
                <span className="tag" style={{background:`${TYPE_COLORS[selected.type]||'#64748b'}22`,color:TYPE_COLORS[selected.type]||'#64748b',marginTop:6}}>{selected.type}</span>
              </div>
              <button className="modal-close" onClick={()=>setSelected(null)}>×</button>
            </div>
            <p style={{fontSize:13,color:'var(--muted)',lineHeight:1.8,marginBottom:16}}>{selected.desc}</p>
            <div className="grid-2" style={{marginBottom:16}}>
              {[['📅','Date',selected.date],['🕒','Time',selected.time],['📍','Venue',selected.venue],['🏆','Prize',selected.prize],['👥','Team Size',selected.teamSize],['⏰','Register By',selected.deadline]].map(([ic,l,v])=>(
                <div key={l} style={{background:'var(--bg3)',borderRadius:10,padding:'9px 12px'}}>
                  <div style={{fontSize:10,color:'var(--muted)',fontWeight:700,textTransform:'uppercase',marginBottom:2}}>{ic} {l}</div>
                  <div style={{fontSize:13,fontWeight:600}}>{v}</div>
                </div>
              ))}
            </div>
            <div className="modal-actions">
              <button className="btn btn-ghost" onClick={()=>setSelected(null)}>Close</button>
              <button className={`btn ${selected.registered?'btn-ghost':'btn-primary'}`} onClick={()=>register(selected.id,selected.title)}>{selected.registered?'✅ Already Registered':'Register Now →'}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
