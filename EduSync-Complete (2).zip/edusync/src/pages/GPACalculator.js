import React, { useState } from 'react';
const GP={'O':10,'A+':9,'A':8,'B+':7,'B':6,'C':5,'F':0};
const PREV_SEMS=[{sem:1,gpa:8.5},{sem:2,gpa:8.7},{sem:3,gpa:8.9},{sem:4,gpa:8.8}];
const INIT_SUBJECTS=[{sub:'Data Structures',code:'CS3401',grade:'O',credits:4},{sub:'Database Mgmt',code:'CS3402',grade:'A+',credits:3},{sub:'Operating Systems',code:'CS3403',grade:'A',credits:4},{sub:'Computer Networks',code:'CS3404',grade:'A+',credits:3},{sub:'Probability & Stats',code:'MA3451',grade:'O',credits:4}];
export default function GPACalculator({ showToast }) {
  const [subjects, setSubjects] = useState(INIT_SUBJECTS);
  const calcGPA = (subs) => { let tp=0,tc=0; subs.forEach(r=>{tp+=GP[r.grade]*r.credits;tc+=r.credits;}); return tc?(tp/tc).toFixed(2):0; };
  const gpa = calcGPA(subjects);
  const prevGPA = (PREV_SEMS.reduce((a,s)=>a+s.gpa,0)/PREV_SEMS.length).toFixed(2);
  const cgpa = ((parseFloat(prevGPA)*PREV_SEMS.length + parseFloat(gpa))/(PREV_SEMS.length+1)).toFixed(2);
  const setGrade = (i, g) => { const s=[...subjects]; s[i]={...s[i],grade:g}; setSubjects(s); };
  const color = (g) => g>=9?'#34d399':g>=8?'#6375ff':g>=7?'#fb923c':'#f87171';
  return (
    <div className="page">
      <div className="page-header"><h2>GPA Calculator 📊</h2><p>Simulate grades and predict your semester GPA & overall CGPA</p></div>
      <div className="grid-3" style={{marginBottom:22}}>
        <div className="card" style={{textAlign:'center',padding:28}}>
          <div style={{fontSize:12,color:'var(--muted)',fontWeight:700,textTransform:'uppercase',letterSpacing:1,marginBottom:8}}>Semester GPA</div>
          <div className="gpa-number">{gpa}</div>
          <div style={{fontSize:12,color:'var(--muted)',marginTop:8}}>Sem 5 • {subjects.length} subjects</div>
          <span className={`tag tag-${gpa>=9?'green':gpa>=8?'blue':gpa>=7?'orange':'red'}`} style={{marginTop:12,fontSize:12,padding:'5px 14px'}}>{gpa>=9?'🏆 Excellent':gpa>=8?'⭐ Very Good':gpa>=7?'👍 Good':'📚 Keep Going'}</span>
        </div>
        <div className="card" style={{textAlign:'center',padding:28}}>
          <div style={{fontSize:12,color:'var(--muted)',fontWeight:700,textTransform:'uppercase',letterSpacing:1,marginBottom:8}}>Overall CGPA</div>
          <div style={{fontFamily:'Syne,sans-serif',fontSize:52,fontWeight:800,color:'#34d399',lineHeight:1}}>{cgpa}</div>
          <div style={{fontSize:12,color:'var(--muted)',marginTop:8}}>Across 5 semesters</div>
        </div>
        <div className="card">
          <div className="section-title">✅ Eligibility</div>
          {[['Google / Microsoft','7.5+'],['Amazon / Adobe','7.0+'],['Infosys / Wipro','6.5+'],['TCS / All','6.0+'],['Govt Jobs (60%)','6.0+']].map(([co,req])=>(
            <div key={co} style={{display:'flex',justifyContent:'space-between',fontSize:12,padding:'6px 0',borderBottom:'1px solid var(--border)'}}>
              <span>{co}</span>
              <span style={{color:'#34d399',fontWeight:700}}>✅ {req}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="grid-2">
        <div className="card">
          <div className="section-title">📚 Semester 5 Grades</div>
          <p style={{fontSize:12,color:'var(--muted)',marginBottom:14}}>Change grades to simulate your GPA in real-time</p>
          {subjects.map((s,i)=>(
            <div key={s.code} style={{display:'flex',alignItems:'center',gap:12,padding:'10px 0',borderBottom:'1px solid var(--border)'}}>
              <div style={{flex:1}}>
                <div style={{fontSize:13,fontWeight:600}}>{s.sub}</div>
                <div style={{fontSize:11,color:'var(--muted)'}}>{s.code} • {s.credits} credits</div>
              </div>
              <select value={s.grade} onChange={e=>setGrade(i,e.target.value)} style={{width:68,padding:'5px 8px',fontSize:13,textAlign:'center'}}>
                {Object.keys(GP).map(g=><option key={g}>{g}</option>)}
              </select>
              <div style={{width:36,height:36,borderRadius:9,background:`${color(GP[s.grade])}18`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:13,fontWeight:800,color:color(GP[s.grade]),flexShrink:0}}>{GP[s.grade]}</div>
            </div>
          ))}
          <div style={{textAlign:'right',marginTop:14,fontSize:16,fontWeight:800,fontFamily:'Syne,sans-serif'}}>
            Sem GPA: <span style={{color:'#6375ff'}}>{gpa}</span>
          </div>
        </div>
        <div className="card">
          <div className="section-title">📈 CGPA History</div>
          {[...PREV_SEMS,{sem:5,gpa:parseFloat(gpa)}].map(s=>(
            <div key={s.sem} style={{marginBottom:14}}>
              <div style={{display:'flex',justifyContent:'space-between',marginBottom:5}}>
                <span style={{fontSize:13,fontWeight:600}}>Semester {s.sem} {s.sem===5?'(Current)':''}</span>
                <span style={{fontSize:13,fontWeight:700,color:color(s.gpa)}}>{s.gpa}</span>
              </div>
              <div className="progress-bar"><div className="progress-fill" style={{width:`${(s.gpa/10)*100}%`,background:color(s.gpa)}}></div></div>
            </div>
          ))}
          <div style={{marginTop:18,padding:'14px',background:'rgba(99,117,255,0.08)',borderRadius:12,border:'1px solid rgba(99,117,255,0.2)'}}>
            <div style={{fontSize:12,fontWeight:700,color:'#6375ff',marginBottom:4}}>🎯 CGPA Target Tip</div>
            <div style={{fontSize:12,color:'var(--muted)',lineHeight:1.7}}>To reach CGPA 9.0+, aim for O grade in DS and Math. Your current trajectory looks great! Keep it up 💪</div>
          </div>
        </div>
      </div>
    </div>
  );
}
