import React, { useState } from 'react';
import { useDept, ALL_DEPARTMENTS } from '../context/DeptContext';

const CATEGORIES = {
  'Engineering':  ['CSE','IT','ECE','EEE','MECH','CIVIL','CHEM','AERO'],
  'Specialised':  ['VLSI','AIML','CYS','IOT','ROB','DSC'],
  'Science':      ['BIO','BME','PHY','MATH'],
  'Management':   ['MBA','MCA'],
};

export default function Dashboard({ setActivePage }) {
  const { currentDept, setCurrentDept, dept } = useDept();
  const [showPicker, setShowPicker] = useState(false);

  return (
    <div className="page">
      {/* ── Department Banner ── */}
      <div style={{ background:`linear-gradient(135deg, ${dept.color}33, ${dept.color}11)`, border:`1px solid ${dept.color}44`, borderRadius:16, padding:'20px 22px', marginBottom:20, position:'relative', overflow:'hidden' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', flexWrap:'wrap', gap:12 }}>
          <div>
            <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:5 }}>
              <span style={{ fontSize:30 }}>{dept.icon}</span>
              <div>
                <h2 style={{ fontSize:20, fontWeight:800 }}>{dept.name}</h2>
                <p style={{ color:'var(--muted)', fontSize:12, marginTop:2 }}>Semester {dept.sem} • CGPA: {dept.cgpa} • {dept.students} Students • HOD: {dept.hod}</p>
              </div>
            </div>
            <div style={{ display:'flex', gap:8, marginTop:12, flexWrap:'wrap' }}>
              <button className="btn btn-primary btn-sm" onClick={() => setActivePage('assignments')}>📝 Assignments</button>
              <button className="btn btn-ghost btn-sm" onClick={() => setActivePage('exam-calendar')}>📅 Exams</button>
              <button className="btn btn-ghost btn-sm" onClick={() => setActivePage('timetable')}>🗓️ Timetable</button>
              <button className="btn btn-ghost btn-sm" onClick={() => setActivePage('chatbot')}>🤖 AI Bot</button>
            </div>
          </div>
          <button
            onClick={() => setShowPicker(!showPicker)}
            style={{ background:`${dept.color}22`, border:`2px solid ${dept.color}55`, borderRadius:12, padding:'10px 16px', cursor:'pointer', color:dept.color, fontWeight:700, fontSize:13, fontFamily:'DM Sans,sans-serif', display:'flex', alignItems:'center', gap:8, transition:'.2s', flexShrink:0 }}
          >
            🔄 Switch Department
          </button>
        </div>

        {/* Department Picker */}
        {showPicker && (
          <div style={{ marginTop:16, background:'var(--bg2)', borderRadius:14, border:'1px solid var(--border)', padding:16 }}>
            <div style={{ fontSize:12, fontWeight:700, color:'var(--muted)', textTransform:'uppercase', letterSpacing:1, marginBottom:14 }}>
              Select Department — Dashboard & all pages update automatically!
            </div>
            {Object.entries(CATEGORIES).map(([cat, codes]) => (
              <div key={cat} style={{ marginBottom:14 }}>
                <div style={{ fontSize:11, fontWeight:700, color:'var(--muted)', marginBottom:8, textTransform:'uppercase', letterSpacing:.5 }}>{cat}</div>
                <div style={{ display:'flex', gap:7, flexWrap:'wrap' }}>
                  {codes.map(code => {
                    const d = ALL_DEPARTMENTS[code];
                    if (!d) return null;
                    return (
                      <button key={code}
                        onClick={() => { setCurrentDept(code); setShowPicker(false); }}
                        style={{ padding:'7px 13px', borderRadius:9, border:`2px solid ${currentDept===code ? d.color : 'var(--border)'}`, background:currentDept===code ? `${d.color}22` : 'var(--bg3)', color:currentDept===code ? d.color : 'var(--text)', fontWeight:600, cursor:'pointer', fontSize:12, fontFamily:'DM Sans,sans-serif', transition:'.15s', display:'flex', alignItems:'center', gap:6 }}>
                        {d.icon} {code}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ── Stats ── */}
      <div className="grid-4" style={{ marginBottom:20 }}>
        {[
          ['📝','rgba(99,117,255,.15)',  dept.assignments?.filter(a=>a.status==='pending').length||0, 'Pending Assignments', `${dept.assignments?.filter(a=>a.daysLeft<=3&&a.daysLeft>=0).length||0} due soon`, '#fb923c'],
          ['📅','rgba(251,146,60,.15)',  dept.exams?.length||0, 'Upcoming Exams', `Next: ${dept.exams?.[0]?.date||'TBA'}`, '#38bdf8'],
          ['📈','rgba(52,211,153,.15)',  dept.cgpa, 'Dept CGPA', `${dept.category} Dept`, '#34d399'],
          ['🏆','rgba(167,139,250,.15)', dept.subjects?.length||0, 'Subjects This Sem', `${dept.subjects?.filter(s=>s.type==='Lab').length||0} lab sessions`, '#a78bfa'],
        ].map(([icon,bg,num,label,change,color]) => (
          <div className="stat-card" key={label}>
            <div className="stat-icon" style={{ background:bg }}>{icon}</div>
            <div className="stat-num">{num}</div>
            <div className="stat-label">{label}</div>
            <div className="stat-change" style={{ color }}>{change}</div>
          </div>
        ))}
      </div>

      {/* ── Academics ── */}
      <div className="section-title">📚 Academics</div>
      <div className="grid-4" style={{ marginBottom:20 }}>
        {[
          ['📝','linear-gradient(135deg,#6375ff,#818cf8)','Assignments',`${dept.assignments?.length||0} tasks`,'assignments'],
          ['📄','linear-gradient(135deg,#0891b2,#38bdf8)','Question Papers','Past year papers','question-papers'],
          ['📅','linear-gradient(135deg,#d97706,#fbbf24)','Exam Calendar',`${dept.exams?.length||0} exams`,'exam-calendar'],
          ['🗓️','linear-gradient(135deg,#7c3aed,#a78bfa)','Timetable','Weekly schedule','timetable'],
        ].map(([icon,bg,title,sub,pg]) => (
          <div className="academic-card" key={title} onClick={() => setActivePage(pg)}>
            <div className="ac-icon" style={{ background:bg }}>{icon}</div>
            <h4>{title}</h4><p>{sub}</p>
          </div>
        ))}
      </div>

      {/* ── Career ── */}
      <div className="section-title">💼 Career & Growth</div>
      <div className="grid-4" style={{ marginBottom:20 }}>
        {[
          ['💼','linear-gradient(135deg,#059669,#34d399)','Internships',`${dept.internships?.length||0}+ opportunities`,'internships'],
          ['🏢','linear-gradient(135deg,#dc2626,#f87171)','Companies',`${dept.companies?.length||0} drives`,'placements'],
          ['🗺️','linear-gradient(135deg,#b45309,#fbbf24)','Roadmap','Year 1 → 4','roadmap'],
          ['🎓','linear-gradient(135deg,#7c3aed,#c026d3)','NPTEL',`${dept.nptelCourses?.length||0} IIT courses`,'nptel'],
        ].map(([icon,bg,title,sub,pg]) => (
          <div className="academic-card" key={title} onClick={() => setActivePage(pg)}>
            <div className="ac-icon" style={{ background:bg }}>{icon}</div>
            <h4>{title}</h4><p>{sub}</p>
          </div>
        ))}
      </div>

      {/* ── Bottom Grid ── */}
      <div className="grid-2">
        {/* Subjects */}
        <div className="card">
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:14 }}>
            <div className="section-title" style={{ margin:0 }}>📚 {currentDept} — Sem {dept.sem} Subjects</div>
            <button className="btn btn-ghost btn-sm" onClick={() => setActivePage('departments')}>All Depts</button>
          </div>
          {dept.subjects?.map((s, i) => (
            <div key={s.code} style={{ display:'flex', alignItems:'center', gap:10, padding:'8px 0', borderBottom:'1px solid var(--border)' }}>
              <div style={{ width:28, height:28, borderRadius:7, background:`${s.color}22`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:10, fontWeight:800, color:s.color, flexShrink:0 }}>{s.type==='Lab'?'🔬':'📖'}</div>
              <div style={{ flex:1 }}>
                <div style={{ fontSize:12, fontWeight:600 }}>{s.name}</div>
                <div style={{ fontSize:10, color:'var(--muted)' }}>{s.code} • {s.credits} Credits • {s.faculty}</div>
              </div>
              <span className={`tag ${s.type==='Lab'?'tag-orange':'tag-blue'}`} style={{ fontSize:9 }}>{s.type}</span>
            </div>
          ))}
        </div>

        <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
          {/* Exams */}
          <div className="card" style={{ flex:1 }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12 }}>
              <div className="section-title" style={{ margin:0 }}>📅 {currentDept} Exam Countdown</div>
              <button className="btn btn-ghost btn-sm" onClick={() => setActivePage('exam-calendar')}>Calendar</button>
            </div>
            {dept.exams?.map(e => (
              <div key={e.code} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'7px 0', borderBottom:'1px solid var(--border)' }}>
                <div>
                  <div style={{ fontSize:12, fontWeight:600 }}>{e.subject}</div>
                  <div style={{ fontSize:10, color:'var(--muted)' }}>{e.date} • {e.hall}</div>
                </div>
                <div style={{ background:`${e.color}18`, color:e.color, padding:'2px 8px', borderRadius:6, fontSize:10, fontWeight:700 }}>{e.days}d</div>
              </div>
            ))}
          </div>

          {/* Dept Career Info */}
          <div className="card">
            <div className="section-title">💼 {currentDept} Career Snapshot</div>
            <div style={{ marginBottom:10 }}>
              <div style={{ fontSize:11, color:'var(--muted)', marginBottom:4 }}>Top Job Roles</div>
              <div style={{ display:'flex', gap:5, flexWrap:'wrap' }}>
                {dept.careerRoles?.slice(0,3).map(r => (
                  <span key={r} style={{ background:`${dept.color}18`, color:dept.color, fontSize:10, fontWeight:600, padding:'3px 8px', borderRadius:20 }}>{r}</span>
                ))}
              </div>
            </div>
            <div style={{ display:'flex', gap:10 }}>
              <div style={{ flex:1, background:'rgba(52,211,153,0.08)', borderRadius:9, padding:'9px 11px' }}>
                <div style={{ fontSize:10, color:'var(--muted)', marginBottom:3 }}>💰 Avg CTC</div>
                <div style={{ fontSize:13, fontWeight:700, color:'#34d399' }}>{dept.avgCTC}</div>
              </div>
              <div style={{ flex:1, background:'rgba(251,191,36,0.08)', borderRadius:9, padding:'9px 11px' }}>
                <div style={{ fontSize:10, color:'var(--muted)', marginBottom:3 }}>🏆 Top CTC</div>
                <div style={{ fontSize:12, fontWeight:700, color:'#fbbf24' }}>{dept.topCTC}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
