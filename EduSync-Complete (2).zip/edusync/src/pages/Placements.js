import React, { useState } from 'react';
import { COMPANIES } from '../data/appData';

const statusColor = { upcoming:'#6375ff', ongoing:'#34d399', completed:'#64748b' };
const roundType = { test:'🧪', tech:'💻', mgr:'👔', hr:'🤝' };

export default function Placements({ showToast }) {
  const [selected, setSelected] = useState(null);
  const [deptFilter, setDeptFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [search, setSearch] = useState('');
  const [registered, setRegistered] = useState([]);

  const filtered = COMPANIES.filter(c =>
    (deptFilter==='All'||c.dept.includes(deptFilter)) &&
    (statusFilter==='All'||c.status===statusFilter) &&
    (!search||c.name.toLowerCase().includes(search.toLowerCase()))
  );

  const register = (id, name) => {
    if (!registered.includes(id)) {
      setRegistered(p=>[...p,id]);
      showToast(`Registered for ${name} drive!`,'✅');
    }
    setSelected(null);
  };

  const logoStyle = (color) => ({
    width:52,height:52,borderRadius:14,background:`${color}18`,
    border:`2px solid ${color}40`,display:'flex',alignItems:'center',
    justifyContent:'center',fontSize:16,fontWeight:900,color,flexShrink:0,fontFamily:'Syne,sans-serif'
  });

  return (
    <div className="page">
      <div className="page-header">
        <h2>Upcoming Companies 🏢</h2>
        <p>Placement drives, interview rounds breakdown, skills & eligibility criteria</p>
      </div>

      <div className="grid-4" style={{marginBottom:24}}>
        {[
          {icon:'🏢',label:'Total Companies',val:COMPANIES.length,color:'#6375ff'},
          {icon:'🟢',label:'Ongoing Drives',val:COMPANIES.filter(c=>c.status==='ongoing').length,color:'#34d399'},
          {icon:'📅',label:'Upcoming',val:COMPANIES.filter(c=>c.status==='upcoming').length,color:'#fb923c'},
          {icon:'💰',label:'Highest CTC',val:'₹45 LPA',color:'#fbbf24'},
        ].map(s=>(
          <div className="card card-sm" key={s.label} style={{display:'flex',alignItems:'center',gap:12}}>
            <div style={{width:44,height:44,borderRadius:12,background:`${s.color}22`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:20,flexShrink:0}}>{s.icon}</div>
            <div><div style={{fontSize:24,fontWeight:800,fontFamily:'Syne,sans-serif',color:s.color}}>{s.val}</div><div style={{fontSize:12,color:'var(--muted)'}}>{s.label}</div></div>
          </div>
        ))}
      </div>

      <div style={{position:'relative',marginBottom:14}}>
        <span style={{position:'absolute',left:14,top:'50%',transform:'translateY(-50%)'}}>🔍</span>
        <input type="text" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search companies..." style={{paddingLeft:42}} />
      </div>
      <div style={{display:'flex',gap:16,flexWrap:'wrap',marginBottom:22}}>
        <div style={{display:'flex',gap:6,alignItems:'center',flexWrap:'wrap'}}>
          <span style={{fontSize:11,fontWeight:700,color:'var(--muted)'}}>DEPT:</span>
          {['All','CS','IT','ECE','EEE','MECH'].map(d=><button key={d} className={`filter-btn ${deptFilter===d?'active':''}`} onClick={()=>setDeptFilter(d)} style={{padding:'5px 12px'}}>{d}</button>)}
        </div>
        <div style={{display:'flex',gap:6,alignItems:'center'}}>
          <span style={{fontSize:11,fontWeight:700,color:'var(--muted)'}}>STATUS:</span>
          {['All','upcoming','ongoing'].map(s=><button key={s} className={`filter-btn ${statusFilter===s?'active':''}`} onClick={()=>setStatusFilter(s)} style={{padding:'5px 12px',textTransform:'capitalize'}}>{s}</button>)}
        </div>
      </div>

      <div className="grid-2">
        {filtered.map(c=>(
          <div className="card" key={c.id} onClick={()=>setSelected(c)} style={{cursor:'pointer',borderLeft:`4px solid ${statusColor[c.status]}`,transition:'.2s'}} onMouseEnter={e=>e.currentTarget.style.transform='translateY(-2px)'} onMouseLeave={e=>e.currentTarget.style.transform='none'}>
            <div style={{display:'flex',alignItems:'flex-start',justifyContent:'space-between',marginBottom:12}}>
              <div style={{display:'flex',alignItems:'center',gap:12}}>
                <div style={logoStyle(c.color)}>{c.logo}</div>
                <div>
                  <div style={{fontSize:16,fontWeight:800}}>{c.name}</div>
                  <div style={{fontSize:12,color:'var(--muted)'}}>{c.roles.join(' • ')}</div>
                </div>
              </div>
              <div style={{display:'flex',flexDirection:'column',alignItems:'flex-end',gap:5}}>
                <span className="tag" style={{background:`${statusColor[c.status]}22`,color:statusColor[c.status],textTransform:'capitalize'}}>{c.status}</span>
                {registered.includes(c.id)&&<span className="tag tag-green">✅ Registered</span>}
              </div>
            </div>
            <div style={{display:'flex',gap:8,flexWrap:'wrap',marginBottom:10}}>
              <span className="tag tag-green">💰 {c.ctc}</span>
              <span className="tag tag-blue">📅 {c.visitDate}</span>
              <span className="tag tag-purple">🔄 {c.rounds.length} Rounds</span>
              {c.commTest&&<span className="tag tag-orange">📢 Comm Test</span>}
            </div>
            <div style={{display:'flex',gap:6,flexWrap:'wrap',marginBottom:10}}>
              {c.skills.map(s=><span key={s} style={{background:'rgba(99,117,255,0.1)',color:'#6375ff',fontSize:11,padding:'3px 8px',borderRadius:6,fontWeight:600}}>{s}</span>)}
            </div>
            <div style={{display:'flex',justifyContent:'space-between',fontSize:12,color:'var(--muted)'}}>
              <span>CGPA Cutoff: <b style={{color:'var(--text)'}}>{c.cgpaCutoff}</b></span>
              <span>Eligible: {c.dept.slice(0,3).join(', ')}{c.dept.length>3?'…':''}</span>
            </div>
          </div>
        ))}
      </div>

      {selected && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setSelected(null)}>
          <div className="modal modal-lg" style={{maxWidth:700}}>
            <div className="modal-header">
              <div style={{display:'flex',alignItems:'center',gap:14}}>
                <div style={logoStyle(selected.color)}>{selected.logo}</div>
                <div><h3>{selected.name}</h3><p style={{color:'var(--muted)',fontSize:13}}>{selected.roles.join(' • ')}</p></div>
              </div>
              <button className="modal-close" onClick={()=>setSelected(null)}>×</button>
            </div>
            <div className="grid-2" style={{marginBottom:16}}>
              {[['💰','Package',selected.ctc],['📅','Drive Date',selected.visitDate],['🎓','CGPA Cutoff',selected.cgpaCutoff],['📋','Backlog Policy',selected.backlogPolicy]].map(([icon,label,val])=>(
                <div key={label} style={{background:'var(--bg3)',borderRadius:10,padding:'10px 14px'}}>
                  <div style={{fontSize:11,color:'var(--muted)',fontWeight:700,textTransform:'uppercase',marginBottom:3}}>{icon} {label}</div>
                  <div style={{fontSize:13,fontWeight:600}}>{val}</div>
                </div>
              ))}
            </div>
            <div style={{marginBottom:16}}>
              <div style={{fontSize:14,fontWeight:700,marginBottom:12}}>🔄 Interview Process</div>
              {selected.rounds.map((r,i)=>(
                <div key={i} style={{display:'flex',gap:12,marginBottom:10}}>
                  <div style={{width:32,height:32,borderRadius:10,background:'linear-gradient(135deg,#6375ff,#a78bfa)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:14,color:'#fff',flexShrink:0}}>{roundType[r.type]||'📌'}</div>
                  <div style={{background:'var(--bg3)',borderRadius:10,padding:'10px 14px',flex:1}}>
                    <div style={{fontWeight:700,fontSize:13,marginBottom:3}}>{r.name}</div>
                    <div style={{fontSize:12,color:'var(--muted)',lineHeight:1.6}}>{r.desc}</div>
                  </div>
                </div>
              ))}
            </div>
            <div style={{marginBottom:16}}>
              <div style={{fontSize:14,fontWeight:700,marginBottom:8}}>⚡ Key Skills Required</div>
              <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>{selected.skills.map(s=><span key={s} style={{background:'rgba(99,117,255,0.15)',color:'#6375ff',padding:'6px 14px',borderRadius:8,fontSize:13,fontWeight:600}}>{s}</span>)}</div>
            </div>
            {selected.commTest&&(
              <div style={{background:'rgba(251,146,60,0.1)',border:'1px solid rgba(251,146,60,0.3)',borderRadius:10,padding:'12px 16px',marginBottom:16}}>
                <div style={{fontSize:13,fontWeight:700,color:'#fb923c',marginBottom:4}}>📢 Communication Test Required</div>
                <div style={{fontSize:13,color:'var(--muted)'}}>This company conducts a group discussion or communication assessment. Practice spoken English and group dynamics before the drive.</div>
              </div>
            )}
            <div className="modal-actions">
              <button className="btn btn-ghost" onClick={()=>setSelected(null)}>Close</button>
              <button className="btn btn-primary" onClick={()=>register(selected.id,selected.name)}>{registered.includes(selected.id)?'✅ Registered':'Register for Drive'}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
