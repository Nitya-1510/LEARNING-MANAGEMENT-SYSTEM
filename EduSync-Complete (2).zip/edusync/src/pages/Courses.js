import React, { useState } from 'react';

const COURSES = [
  {
    id:1,
    title:'Data Structures & Algorithms Full Course',
    channel:'Abdul Bari',
    views:'12M views',
    duration:'40 hrs',
    tag:'DS',
    color:'#6375ff',
    embedId:'RBSGKlAvoiM',
    desc:'Complete DSA course covering arrays, linked lists, trees, graphs, sorting & searching algorithms with analysis.',
    playlist:'https://www.youtube.com/watch?v=RBSGKlAvoiM'
  },
  {
    id:2,
    title:'DBMS Complete Course',
    channel:'Gate Smashers',
    views:'5M views',
    duration:'20 hrs',
    tag:'DBMS',
    color:'#0891b2',
    embedId:'kBdlM6hNDAE',
    desc:'Full DBMS course: ER diagrams, normalization, SQL, transactions, concurrency control and recovery.',
    playlist:'https://www.youtube.com/watch?v=kBdlM6hNDAE'
  },
  {
    id:3,
    title:'Operating Systems Full Course',
    channel:'Neso Academy',
    views:'8M views',
    duration:'25 hrs',
    tag:'OS',
    color:'#d97706',
    embedId:'vBURTt97EkA',
    desc:'Complete OS course: process management, memory management, file systems, deadlock, scheduling algorithms.',
    playlist:'https://www.youtube.com/watch?v=vBURTt97EkA'
  },
  {
    id:4,
    title:'Computer Networks Full Course',
    channel:'Gate Smashers',
    views:'6M views',
    duration:'22 hrs',
    tag:'CN',
    color:'#059669',
    embedId:'JFF2vAiKMHg',
    desc:'Complete CN course: OSI model, TCP/IP, routing, switching, application layer protocols and network security.',
    playlist:'https://www.youtube.com/watch?v=JFF2vAiKMHg'
  },
  {
    id:5,
    title:'React.js Full Course for Beginners',
    channel:'Traversy Media',
    views:'10M views',
    duration:'12 hrs',
    tag:'Web',
    color:'#7c3aed',
    embedId:'w7ejDZ8SWv8',
    desc:'Complete React.js course: components, hooks, state management, routing and building real projects.',
    playlist:'https://www.youtube.com/watch?v=w7ejDZ8SWv8'
  },
  {
    id:6,
    title:'Machine Learning Full Course',
    channel:'Simplilearn',
    views:'15M views',
    duration:'44 hrs',
    tag:'ML',
    color:'#be123c',
    embedId:'GwIo3gDZCVQ',
    desc:'Complete ML course: supervised, unsupervised learning, neural networks, Python implementation with projects.',
    playlist:'https://www.youtube.com/watch?v=GwIo3gDZCVQ'
  },
  {
    id:7,
    title:'Python Full Course for Beginners',
    channel:'Programming with Mosh',
    views:'20M views',
    duration:'6 hrs',
    tag:'Python',
    color:'#0891b2',
    embedId:'_uQrJ0TkZlc',
    desc:'Complete Python course from basics to advanced: OOP, file handling, APIs, automation and more.',
    playlist:'https://www.youtube.com/watch?v=_uQrJ0TkZlc'
  },
  {
    id:8,
    title:'System Design for Beginners',
    channel:'Gaurav Sen',
    views:'3M views',
    duration:'10 hrs',
    tag:'Design',
    color:'#059669',
    embedId:'xpDnVSmNFX0',
    desc:'System design fundamentals: scalability, load balancing, caching, databases, microservices architecture.',
    playlist:'https://www.youtube.com/watch?v=xpDnVSmNFX0'
  },
];

const TAG_COLORS = {
  DS:'#6375ff', DBMS:'#0891b2', OS:'#d97706',
  CN:'#059669', Web:'#7c3aed', ML:'#be123c',
  Python:'#0891b2', Design:'#059669'
};

export default function Courses({ showToast }) {
  const [courses, setCourses] = useState(COURSES);
  const [playing, setPlaying] = useState(null);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ title:'', channel:'', tag:'Custom', embedId:'', desc:'' });
  const [filter, setFilter] = useState('All');

  const tags = ['All', ...new Set(COURSES.map(c => c.tag))];

  const filtered = courses.filter(c =>
    filter === 'All' || c.tag === filter
  );

  // Extract YouTube video ID from any YouTube URL
  const getVideoId = (url) => {
    const patterns = [
      /youtube\.com\/watch\?v=([^&]+)/,
      /youtu\.be\/([^?]+)/,
      /youtube\.com\/embed\/([^?]+)/,
    ];
    for (const pattern of patterns) {
      const match = url.match(pattern);
      if (match) return match[1];
    }
    return url; // assume it's already an ID
  };

  const addCourse = () => {
    if (!form.title || !form.embedId) {
      showToast('Please fill title and YouTube URL!', '⚠️');
      return;
    }
    const videoId = getVideoId(form.embedId);
    const newCourse = {
      id: Date.now(),
      ...form,
      embedId: videoId,
      views: 'New',
      duration: '—',
      color: TAG_COLORS[form.tag] || '#6375ff',
      playlist: `https://www.youtube.com/watch?v=${videoId}`
    };
    setCourses(p => [...p, newCourse]);
    setForm({ title:'', channel:'', tag:'Custom', embedId:'', desc:'' });
    setShowAdd(false);
    showToast(`${form.title} added! ▶️`, '✅');
  };

  return (
    <div className="page">
      {/* Header */}
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:22 }}>
        <div className="page-header" style={{ marginBottom:0 }}>
          <h2>Video Courses ▶️</h2>
          <p>Watch embedded YouTube lectures — click any card to play instantly!</p>
        </div>
        <button className="btn btn-primary btn-sm" onClick={() => setShowAdd(true)}>
          + Add Your Video
        </button>
      </div>

      {/* Stats */}
      <div className="grid-4" style={{ marginBottom:18 }}>
        {[
          ['▶️','Total Courses', courses.length, '#6375ff'],
          ['📚','Subjects', new Set(courses.map(c=>c.tag)).size, '#34d399'],
          ['⭐','Top Rated', '4.8/5', '#fbbf24'],
          ['🕐','Total Hours', courses.reduce((a,c)=>a+(parseInt(c.duration)||0),0)+' hrs', '#fb923c'],
        ].map(([icon,label,val,color]) => (
          <div className="card card-sm" key={label} style={{ display:'flex', alignItems:'center', gap:10 }}>
            <div style={{ width:40, height:40, borderRadius:11, background:`${color}22`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:18, flexShrink:0 }}>{icon}</div>
            <div>
              <div style={{ fontSize:20, fontWeight:800, fontFamily:'Syne,sans-serif', color }}>{val}</div>
              <div style={{ fontSize:11, color:'var(--muted)' }}>{label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Filter Tags */}
      <div style={{ display:'flex', gap:8, flexWrap:'wrap', marginBottom:20 }}>
        {tags.map(t => (
          <button key={t} className={`filter-btn ${filter===t?'active':''}`} onClick={() => setFilter(t)}>{t}</button>
        ))}
      </div>

      {/* Video Grid */}
      <div className="grid-3">
        {filtered.map(c => (
          <div key={c.id} className="card" style={{
            borderTop: `3px solid ${c.color}`,
            transition: '.2s', padding:0, overflow:'hidden'
          }}>

            {/* Video Player or Thumbnail */}
            {playing === c.id ? (
              // ── EMBEDDED YOUTUBE PLAYER ──
              <div style={{ position:'relative', paddingBottom:'56.25%', height:0, background:'#000' }}>
                <iframe
                  style={{ position:'absolute', top:0, left:0, width:'100%', height:'100%', border:'none' }}
                  src={`https://www.youtube.com/embed/${c.embedId}?autoplay=1&rel=0`}
                  title={c.title}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              </div>
            ) : (
              // ── THUMBNAIL with Play Button ──
              <div
                onClick={() => setPlaying(c.id)}
                style={{
                  position:'relative', cursor:'pointer',
                  background:`linear-gradient(135deg, ${c.color}40, ${c.color}15)`,
                  height:160, display:'flex', alignItems:'center', justifyContent:'center',
                  overflow:'hidden'
                }}
              >
                {/* YouTube Thumbnail */}
                <img
                  src={`https://img.youtube.com/vi/${c.embedId}/mqdefault.jpg`}
                  alt={c.title}
                  style={{ width:'100%', height:'100%', objectFit:'cover', position:'absolute', top:0, left:0, opacity:0.7 }}
                  onError={e => { e.target.style.display='none'; }}
                />
                {/* Play Button Overlay */}
                <div style={{
                  position:'relative', zIndex:2,
                  width:56, height:56, borderRadius:'50%',
                  background:'rgba(255,255,255,0.95)',
                  display:'flex', alignItems:'center', justifyContent:'center',
                  boxShadow:'0 4px 20px rgba(0,0,0,0.4)',
                  transition:'.2s'
                }}>
                  <div style={{
                    width:0, height:0,
                    borderTop:'12px solid transparent',
                    borderBottom:'12px solid transparent',
                    borderLeft:`20px solid ${c.color}`,
                    marginLeft:4
                  }}/>
                </div>
                {/* Duration Badge */}
                <div style={{
                  position:'absolute', bottom:8, right:8,
                  background:'rgba(0,0,0,0.8)', color:'#fff',
                  fontSize:10, fontWeight:700, padding:'3px 7px', borderRadius:5
                }}>{c.duration}</div>
              </div>
            )}

            {/* Card Info */}
            <div style={{ padding:'14px' }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:6 }}>
                <h4 style={{ fontSize:13, fontWeight:700, lineHeight:1.4, flex:1, paddingRight:8 }}>{c.title}</h4>
                <span style={{
                  background:`${c.color}18`, color:c.color,
                  fontSize:9, fontWeight:700, padding:'2px 7px', borderRadius:20,
                  flexShrink:0
                }}>{c.tag}</span>
              </div>

              <div style={{ fontSize:11, color:'var(--muted)', marginBottom:8 }}>
                📺 {c.channel}
              </div>

              {c.desc && (
                <p style={{ fontSize:11, color:'var(--muted)', lineHeight:1.6, marginBottom:10 }}>
                  {c.desc.slice(0,80)}...
                </p>
              )}

              <div style={{ display:'flex', gap:5, marginBottom:12 }}>
                <span className="tag tag-blue" style={{ fontSize:9 }}>👁 {c.views}</span>
                <span className="tag tag-purple" style={{ fontSize:9 }}>⏱ {c.duration}</span>
              </div>

              <div style={{ display:'flex', gap:7 }}>
                <button
                  className="btn btn-primary btn-sm"
                  style={{ flex:1, justifyContent:'center' }}
                  onClick={() => setPlaying(playing === c.id ? null : c.id)}
                >
                  {playing === c.id ? '⏸ Pause' : '▶️ Play Now'}
                </button>
                <a
                  href={c.playlist}
                  target="_blank"
                  rel="noreferrer"
                  className="btn btn-ghost btn-sm"
                  title="Open in YouTube"
                >
                  ↗
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add Video Modal */}
      {showAdd && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setShowAdd(false)}>
          <div className="modal">
            <div className="modal-header">
              <h3>➕ Add YouTube Video</h3>
              <button className="modal-close" onClick={() => setShowAdd(false)}>×</button>
            </div>

            <div style={{ background:'rgba(99,117,255,0.08)', border:'1px solid rgba(99,117,255,0.2)', borderRadius:10, padding:'11px 14px', marginBottom:16, fontSize:12, color:'var(--muted)' }}>
              💡 <b>Tip:</b> Paste any YouTube link like:<br/>
              <code style={{ color:'#6375ff' }}>https://www.youtube.com/watch?v=ABC123</code><br/>
              <code style={{ color:'#6375ff' }}>https://youtu.be/ABC123</code>
            </div>

            <div className="form-field">
              <label>Video Title *</label>
              <input type="text" value={form.title} onChange={e => setForm({...form, title:e.target.value})} placeholder="e.g. OS Full Course by Neso Academy" />
            </div>

            <div className="form-field">
              <label>YouTube URL or Video ID *</label>
              <input type="text" value={form.embedId} onChange={e => setForm({...form, embedId:e.target.value})} placeholder="https://www.youtube.com/watch?v=..." />
            </div>

            <div className="form-row">
              <div className="form-field">
                <label>Channel Name</label>
                <input type="text" value={form.channel} onChange={e => setForm({...form, channel:e.target.value})} placeholder="e.g. Neso Academy" />
              </div>
              <div className="form-field">
                <label>Subject Tag</label>
                <select value={form.tag} onChange={e => setForm({...form, tag:e.target.value})}>
                  {['DS','DBMS','OS','CN','Web','ML','Python','Design','Custom'].map(t => <option key={t}>{t}</option>)}
                </select>
              </div>
            </div>

            <div className="form-field">
              <label>Description (optional)</label>
              <textarea rows={2} value={form.desc} onChange={e => setForm({...form, desc:e.target.value})} placeholder="Brief description of the course..." />
            </div>

            <div className="modal-actions">
              <button className="btn btn-ghost" onClick={() => setShowAdd(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={addCourse}>Add Course ▶️</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
