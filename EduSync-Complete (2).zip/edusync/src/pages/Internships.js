import React, { useState } from 'react';
import { useDept } from '../context/DeptContext';

const ALL_INTERNSHIPS = [
  { company:'Google',      logo:'G',  color:'#4285F4', ctc:'₹80,000/mo', role:'SWE Intern',           dept:['CSE','IT','AIML','DSC'],                 skills:['Python','DSA','System Design'],           type:'Paid', mode:'Hybrid',  duration:'3 months', location:'Bangalore',  deadline:'Apr 15', rounds:['OA – 2 DSA problems','Technical Round 1','System Design Round','HR Round'], desc:'Work on real Google products with cutting-edge tech teams.'},
  { company:'Microsoft',   logo:'M',  color:'#00A4EF', ctc:'₹75,000/mo', role:'SDE Intern',           dept:['CSE','IT','ECE','AIML'],                 skills:['C++','OOP','Azure'],                      type:'Paid', mode:'Online',  duration:'2 months', location:'Hyderabad',  deadline:'Apr 20', rounds:['Coding Round – 3 problems','Technical Interview 1','Technical Interview 2','HR'], desc:'Contribute to Microsoft products used by millions.'},
  { company:'Amazon',      logo:'A',  color:'#FF9900', ctc:'₹60,000/mo', role:'SDE Intern',           dept:['CSE','IT','DSC'],                        skills:['Java','DSA','AWS'],                       type:'Paid', mode:'Hybrid',  duration:'6 months', location:'Chennai',    deadline:'May 1',  rounds:['Online Assessment','Technical Loop 1','Technical Loop 2','Bar Raiser'], desc:'Amazon internship with PPO available for top performers.'},
  { company:'Qualcomm',    logo:'Q',  color:'#3253DC', ctc:'₹70,000/mo', role:'VLSI Design Intern',   dept:['VLSI','ECE'],                            skills:['VLSI','VHDL/Verilog','Signal Processing'],type:'Paid', mode:'Hybrid',  duration:'6 months', location:'Hyderabad',  deadline:'Apr 8',  rounds:['OA – DSP/VLSI questions','Technical Round 1','Technical Round 2','HR'], desc:'Work on semiconductor chip design with world-class engineers.'},
  { company:'ISRO',        logo:'I',  color:'#FF6600', ctc:'Unpaid',      role:'Research Intern',      dept:['ECE','EEE','MECH','AERO','VLSI'],        skills:['C','Embedded Systems','Signal Processing'],type:'Free', mode:'Offline', duration:'2 months', location:'Bangalore',  deadline:'Mar 30', rounds:['Application Screening','Technical Interview','Document Verification'], desc:'Prestigious government internship. Certificate adds great value.'},
  { company:'DRDO',        logo:'D',  color:'#1B4F72', ctc:'Unpaid',      role:'Technical Intern',     dept:['ECE','EEE','MECH','AERO','CYS'],         skills:['Signal Processing','Electronics'],         type:'Free', mode:'Offline', duration:'2 months', location:'Hyderabad',  deadline:'Apr 5',  rounds:['Application Screening','Technical Interview'], desc:'Defence research internship. Great for core engineering students.'},
  { company:'TCS',         logo:'T',  color:'#0033A0', ctc:'₹7 LPA',     role:'Systems Engineer',     dept:['CSE','IT','ECE','EEE','MECH','CYS','DSC','AIML','IOT','MBA','MCA','BIO','CIVIL','CHEM','AERO'], skills:['Aptitude','Coding','DBMS'],type:'Paid',mode:'Hybrid',duration:'3 months',location:'Multiple',deadline:'May 15',rounds:['TCS NQT','Technical Interview','Managerial Round','HR Round'], desc:'Mass recruiter with good exposure to enterprise projects.'},
  { company:'Infosys',     logo:'In', color:'#007CC3', ctc:'₹6.5 LPA',   role:'Systems Engineer',     dept:['CSE','IT','ECE','AIML','DSC','MBA','MCA'],skills:['Python','Testing','Agile'],               type:'Paid', mode:'Hybrid',  duration:'3 months', location:'Pune',       deadline:'May 5',  rounds:['InfyTQ Test','Technical Interview','HR Interview'], desc:'Good exposure to large-scale enterprise projects.'},
  { company:'Biocon',      logo:'Bc', color:'#008000', ctc:'₹6 LPA',     role:'Research Scientist',   dept:['BIO','BME','CHEM'],                      skills:['Molecular Biology','Cell Culture'],        type:'Paid', mode:'Offline', duration:'6 months', location:'Bangalore',  deadline:'Apr 20', rounds:['Written Test','Lab Test','Technical Interview','HR'], desc:'Leading biotech company. Work on drug discovery.'},
  { company:'GE Healthcare',logo:'GE',color:'#1F88E5', ctc:'₹12 LPA',   role:'Biomedical Engineer',  dept:['BME','EEE','ECE'],                       skills:['Medical Devices','Signal Processing'],     type:'Paid', mode:'Offline', duration:'6 months', location:'Bangalore',  deadline:'Apr 25', rounds:['Written Test','Technical Interview 1','Technical Interview 2','HR'], desc:'Work on life-saving medical imaging and monitoring devices.'},
  { company:'L&T',         logo:'L',  color:'#D4351C', ctc:'₹8 LPA',     role:'Graduate Apprentice',  dept:['MECH','CIVIL','EEE','CHEM','AERO'],      skills:['AutoCAD','Engineering Design'],            type:'Paid', mode:'Offline', duration:'6 months', location:'Mumbai',     deadline:'Apr 25', rounds:['Written Test','Technical Interview','HR Round'], desc:'Leading engineering company with mega project exposure.'},
  { company:'Zoho',        logo:'Z',  color:'#E42527', ctc:'₹12 LPA',    role:'Software Developer',   dept:['CSE','IT','AIML','MCA'],                 skills:['Java','React','SQL'],                      type:'Paid', mode:'Offline', duration:'6 months', location:'Chennai',    deadline:'Apr 10', rounds:['Written Test','Advanced Programming','Technical Interview','HR'], desc:'Great product company with high PPO rate.'},
  { company:'Palo Alto',   logo:'PA', color:'#FA582D', ctc:'₹18 LPA',    role:'Security Engineer',    dept:['CYS','CSE','IT'],                        skills:['Network Security','Python','Linux'],       type:'Paid', mode:'Hybrid',  duration:'6 months', location:'Bangalore',  deadline:'Apr 15', rounds:['Technical Assessment','Security Round 1','Security Round 2','HR'], desc:'Work on next-gen cybersecurity products.'},
  { company:'ABB Robotics', logo:'AB',color:'#FF0000', ctc:'₹10 LPA',    role:'Robotics Engineer',    dept:['ROB','MECH','EEE','ECE'],                skills:['ROS','PLC','Python'],                      type:'Paid', mode:'Offline', duration:'6 months', location:'Bangalore',  deadline:'Apr 18', rounds:['Technical Test','Practical Assessment','HR Round'], desc:'Work on industrial robotics and automation solutions.'},
  { company:'Bosch IoT',   logo:'B',  color:'#EA0016', ctc:'₹9 LPA',     role:'IoT Engineer',         dept:['IOT','ECE','CSE','MECH'],                skills:['Arduino','MQTT','Cloud'],                  type:'Paid', mode:'Hybrid',  duration:'6 months', location:'Coimbatore', deadline:'Apr 22', rounds:['Technical Assessment','IoT Design Round','HR Round'], desc:'Work on IoT solutions for smart manufacturing.'},
  { company:'BARC',        logo:'BR', color:'#003087', ctc:'Stipend',     role:'Research Intern',      dept:['PHY','CHEM','BME','MATH'],               skills:['Physics','Research Methods','MATLAB'],     type:'Paid', mode:'Offline', duration:'2 months', location:'Mumbai',     deadline:'Apr 1',  rounds:['Written Test','Technical Interview','Medical Checkup'], desc:'Work at India\'s premier nuclear research centre.'},
  { company:'McKinsey',    logo:'Mc', color:'#003087', ctc:'₹25 LPA',    role:'Business Analyst',     dept:['MBA','MATH','DSC','CSE'],                skills:['Excel','PowerPoint','Analytical Thinking'],type:'Paid', mode:'Hybrid',  duration:'3 months', location:'Mumbai',     deadline:'Apr 5',  rounds:['Case Interview 1','Case Interview 2','HR Round'], desc:'Work on strategy consulting projects for Fortune 500 clients.'},
  { company:'L&T Construction',logo:'LC',color:'#D4351C',ctc:'₹7 LPA',   role:'Site Engineer',        dept:['CIVIL','MECH'],                          skills:['AutoCAD','STAAD Pro','MS Project'],        type:'Paid', mode:'Offline', duration:'6 months', location:'Multiple',   deadline:'Apr 28', rounds:['Written Test','Technical Interview','Site Visit','HR'], desc:'Work on mega infrastructure projects across India.'},
];

export default function Internships({ showToast }) {
  const { dept, currentDept } = useDept();
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState(null);
  const [applied, setApplied] = useState([]);

  const eligible = ALL_INTERNSHIPS.filter(i => i.dept.includes(currentDept));

  const filtered = eligible.filter(i =>
    (filter === 'all' || i.type.toLowerCase() === filter || i.mode.toLowerCase() === filter) &&
    (!search || i.company.toLowerCase().includes(search.toLowerCase()) || i.role.toLowerCase().includes(search.toLowerCase()))
  );

  const apply = (company) => {
    setApplied(prev => [...prev, company]);
    showToast(`Applied to ${company}! 🎉`, '💼');
    setSelected(null);
  };

  return (
    <div className="page">
      <div className="page-header">
        <h2>Internships 💼</h2>
        <p style={{display:'flex',alignItems:'center',gap:8}}>
          <span style={{background:`${dept.color}22`,color:dept.color,padding:'2px 10px',borderRadius:20,fontSize:12,fontWeight:700}}>{dept.icon} {currentDept}</span>
          {eligible.length} opportunities eligible for your department
        </p>
      </div>

      <div className="grid-4" style={{marginBottom:18}}>
        {[
          ['💼','Eligible',eligible.length,'#6375ff'],
          ['💰','Paid',eligible.filter(i=>i.type==='Paid').length,'#34d399'],
          ['🎓','Free/Govt',eligible.filter(i=>i.type==='Free').length,'#fb923c'],
          ['✅','Applied',applied.length,'#a78bfa'],
        ].map(([icon,label,val,color])=>(
          <div className="card card-sm" key={label} style={{display:'flex',alignItems:'center',gap:10}}>
            <div style={{width:40,height:40,borderRadius:11,background:`${color}22`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:18,flexShrink:0}}>{icon}</div>
            <div>
              <div style={{fontSize:22,fontWeight:800,fontFamily:'Syne,sans-serif',color}}>{val}</div>
              <div style={{fontSize:11,color:'var(--muted)'}}>{label}</div>
            </div>
          </div>
        ))}
      </div>

      <div style={{position:'relative',marginBottom:12}}>
        <span style={{position:'absolute',left:14,top:'50%',transform:'translateY(-50%)'}}>🔍</span>
        <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search companies or roles..." style={{paddingLeft:42}}/>
      </div>

      <div style={{display:'flex',gap:8,flexWrap:'wrap',marginBottom:18}}>
        {['all','paid','free','hybrid','online','offline'].map(f=>(
          <button key={f} className={`filter-btn ${filter===f?'active':''}`} onClick={()=>setFilter(f)} style={{textTransform:'capitalize'}}>{f==='all'?'All':f}</button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="card" style={{textAlign:'center',padding:40}}>
          <div style={{fontSize:40,marginBottom:12}}>💼</div>
          <h4>No internships found for selected filters</h4>
          <p style={{color:'var(--muted)',marginTop:6}}>Try changing filters or switch department</p>
        </div>
      ) : (
        <div className="grid-2">
          {filtered.map(intern => (
            <div key={intern.company} className="card" onClick={()=>setSelected(intern)} style={{cursor:'pointer',borderTop:`3px solid ${intern.color}`,transition:'.2s'}} onMouseEnter={e=>e.currentTarget.style.transform='translateY(-3px)'} onMouseLeave={e=>e.currentTarget.style.transform='none'}>
              <div style={{display:'flex',alignItems:'center',gap:12,marginBottom:12}}>
                <div style={{width:44,height:44,borderRadius:12,background:`${intern.color}18`,border:`2px solid ${intern.color}33`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:16,fontWeight:800,color:intern.color,flexShrink:0}}>{intern.logo}</div>
                <div style={{flex:1}}>
                  <div style={{fontSize:14,fontWeight:700}}>{intern.company}</div>
                  <div style={{fontSize:12,color:'var(--muted)'}}>{intern.role}</div>
                </div>
                {applied.includes(intern.company) && <span className="tag tag-green" style={{fontSize:9}}>✅ Applied</span>}
              </div>
              <p style={{fontSize:12,color:'var(--muted)',marginBottom:10,lineHeight:1.5}}>{intern.desc}</p>
              <div style={{display:'flex',gap:7,flexWrap:'wrap',marginBottom:10}}>
                <span className="tag tag-green" style={{fontSize:10}}>{intern.ctc}</span>
                <span className="tag tag-blue" style={{fontSize:10}}>{intern.mode}</span>
                <span className="tag tag-orange" style={{fontSize:10}}>{intern.duration}</span>
                <span className="tag tag-purple" style={{fontSize:10}}>📅 {intern.deadline}</span>
              </div>
              <div style={{display:'flex',gap:5,flexWrap:'wrap',marginBottom:10}}>
                {intern.skills.slice(0,3).map(s=>(
                  <span key={s} style={{background:`${intern.color}10`,color:intern.color,fontSize:10,padding:'2px 8px',borderRadius:20,fontWeight:600}}>{s}</span>
                ))}
              </div>
              <button className="btn btn-primary btn-sm" style={{width:'100%'}} onClick={e=>{e.stopPropagation();setSelected(intern);}}>View Details →</button>
            </div>
          ))}
        </div>
      )}

      {selected && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setSelected(null)}>
          <div className="modal modal-lg">
            <div className="modal-header">
              <div style={{display:'flex',alignItems:'center',gap:14}}>
                <div style={{width:52,height:52,borderRadius:14,background:`${selected.color}18`,border:`2px solid ${selected.color}33`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:20,fontWeight:800,color:selected.color}}>{selected.logo}</div>
                <div>
                  <h3>{selected.company}</h3>
                  <p style={{color:'var(--muted)',fontSize:12,marginTop:2}}>{selected.role} • {selected.location} • {selected.duration}</p>
                </div>
              </div>
              <button className="modal-close" onClick={()=>setSelected(null)}>×</button>
            </div>
            <p style={{fontSize:13,color:'var(--muted)',marginBottom:16,lineHeight:1.7}}>{selected.desc}</p>
            <div className="grid-2" style={{marginBottom:16}}>
              {[['💰','CTC',selected.ctc],['🌐','Mode',selected.mode],['⏱️','Duration',selected.duration],['📅','Deadline',selected.deadline]].map(([ic,l,v])=>(
                <div key={l} style={{background:'var(--bg3)',borderRadius:9,padding:'9px 12px'}}>
                  <div style={{fontSize:10,color:'var(--muted)',fontWeight:700,textTransform:'uppercase',marginBottom:2}}>{ic} {l}</div>
                  <div style={{fontSize:13,fontWeight:600}}>{v}</div>
                </div>
              ))}
            </div>
            <div style={{marginBottom:16}}>
              <div style={{fontWeight:700,fontSize:13,marginBottom:10}}>🔄 Interview Rounds</div>
              {selected.rounds.map((r,i)=>(
                <div key={i} style={{display:'flex',alignItems:'center',gap:10,padding:'8px 0',borderBottom:'1px solid var(--border)'}}>
                  <div style={{width:24,height:24,borderRadius:6,background:`${selected.color}22`,color:selected.color,fontSize:11,fontWeight:800,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>{i+1}</div>
                  <span style={{fontSize:13}}>{r}</span>
                </div>
              ))}
            </div>
            <div style={{marginBottom:16}}>
              <div style={{fontWeight:700,fontSize:13,marginBottom:10}}>🛠️ Skills Required</div>
              <div style={{display:'flex',flexWrap:'wrap',gap:7}}>
                {selected.skills.map(s=>(
                  <span key={s} style={{background:`${selected.color}15`,color:selected.color,padding:'5px 12px',borderRadius:20,fontSize:12,fontWeight:600}}>{s}</span>
                ))}
              </div>
            </div>
            <div className="modal-actions">
              <button className="btn btn-ghost" onClick={()=>setSelected(null)}>Close</button>
              <button className="btn btn-primary" onClick={()=>apply(selected.company)} disabled={applied.includes(selected.company)}>
                {applied.includes(selected.company)?'✅ Applied!':'Apply Now →'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
