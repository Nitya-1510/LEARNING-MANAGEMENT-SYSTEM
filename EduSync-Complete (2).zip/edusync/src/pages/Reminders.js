import React, { useState } from 'react';
const INIT=[{id:1,text:'Study for DS exam — Units 3-5',time:'Mar 14, 8:00 PM',cat:'Study',done:false},{id:2,text:'Submit DBMS ER Diagram assignment',time:'Mar 22, 11:59 PM',cat:'Assignment',done:false},{id:3,text:'Register for TCS placement drive',time:'Mar 20, 5:00 PM',cat:'Placement',done:true},{id:4,text:'NPTEL DSA weekly test submission',time:'Mar 15, 6:00 PM',cat:'NPTEL',done:false}];
const CATS=['Study','Assignment','Exam','Placement','NPTEL','General'];
const CAT_COLORS={'Study':'#6375ff','Assignment':'#fb923c','Exam':'#f87171','Placement':'#34d399','NPTEL':'#a78bfa','General':'#64748b'};
export default function Reminders({ showToast }) {
  const [reminders, setReminders] = useState(INIT);
  const [form, setForm] = useState({ text:'', time:'', cat:'Study' });
  const [show, setShow] = useState(false);
  const add = () => {
    if (!form.text || !form.time) return;
    setReminders(p=>[{ id:Date.now(), ...form, done:false }, ...p]);
    setForm({ text:'', time:'', cat:'Study' });
    setShow(false);
    showToast('Reminder added! 🔔','✅');
  };
  const toggle = (id) => setReminders(p=>p.map(r=>r.id===id?{...r,done:!r.done}:r));
  const del = (id) => { setReminders(p=>p.filter(r=>r.id!==id)); showToast('Reminder removed','🗑️'); };
  const pending = reminders.filter(r=>!r.done);
  const done = reminders.filter(r=>r.done);
  return (
    <div className="page">
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:22}}>
        <div className="page-header" style={{marginBottom:0}}><h2>Reminders 🔔</h2><p>Stay on top of deadlines, study sessions & important tasks</p></div>
        <button className="btn btn-primary btn-sm" onClick={()=>setShow(true)}>+ Add Reminder</button>
      </div>
      <div className="grid-4" style={{marginBottom:20}}>
        {[['🔔','Total',reminders.length,'#6375ff'],['⏰','Pending',pending.length,'#fb923c'],['✅','Done',done.length,'#34d399'],['📅','Today',1,'#a78bfa']].map(([ic,l,v,c])=>(
          <div className="card card-sm" key={l} style={{display:'flex',alignItems:'center',gap:10}}>
            <div style={{width:38,height:38,borderRadius:10,background:`${c}22`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:17,flexShrink:0}}>{ic}</div>
            <div><div style={{fontSize:22,fontWeight:800,fontFamily:'Syne,sans-serif',color:c}}>{v}</div><div style={{fontSize:11,color:'var(--muted)'}}>{l}</div></div>
          </div>
        ))}
      </div>
      {pending.length > 0 && <>
        <div className="section-title">⏰ Pending ({pending.length})</div>
        <div style={{display:'flex',flexDirection:'column',gap:9,marginBottom:22}}>
          {pending.map(r=>(
            <div key={r.id} className="card card-sm" style={{display:'flex',alignItems:'center',gap:12,borderLeft:`4px solid ${CAT_COLORS[r.cat]||'#64748b'}`}}>
              <input type="checkbox" checked={r.done} onChange={()=>toggle(r.id)} style={{width:16,height:16,cursor:'pointer',accentColor:'#6375ff',flexShrink:0}} />
              <div style={{flex:1}}>
                <div style={{fontSize:13,fontWeight:600}}>{r.text}</div>
                <div style={{display:'flex',gap:8,marginTop:3,alignItems:'center'}}>
                  <span style={{fontSize:11,color:'var(--muted)'}}>⏰ {r.time}</span>
                  <span style={{background:`${CAT_COLORS[r.cat]||'#64748b'}18`,color:CAT_COLORS[r.cat]||'#64748b',fontSize:10,fontWeight:700,padding:'1px 7px',borderRadius:20}}>{r.cat}</span>
                </div>
              </div>
              <button className="btn btn-danger btn-sm" onClick={()=>del(r.id)} style={{padding:'3px 8px',fontSize:11}}>✕</button>
            </div>
          ))}
        </div>
      </>}
      {done.length > 0 && <>
        <div className="section-title" style={{color:'var(--muted)'}}>✅ Completed ({done.length})</div>
        <div style={{display:'flex',flexDirection:'column',gap:9}}>
          {done.map(r=>(
            <div key={r.id} className="card card-sm" style={{display:'flex',alignItems:'center',gap:12,opacity:.55}}>
              <input type="checkbox" checked={r.done} onChange={()=>toggle(r.id)} style={{width:16,height:16,cursor:'pointer',accentColor:'#34d399',flexShrink:0}} />
              <div style={{flex:1}}><div style={{fontSize:13,fontWeight:600,textDecoration:'line-through'}}>{r.text}</div><div style={{fontSize:11,color:'var(--muted)',marginTop:2}}>⏰ {r.time}</div></div>
              <button className="btn btn-danger btn-sm" onClick={()=>del(r.id)} style={{padding:'3px 8px',fontSize:11}}>✕</button>
            </div>
          ))}
        </div>
      </>}
      {show && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setShow(false)}>
          <div className="modal">
            <div className="modal-header"><h3>🔔 New Reminder</h3><button className="modal-close" onClick={()=>setShow(false)}>×</button></div>
            <div className="form-field"><label>Reminder Text *</label><input type="text" value={form.text} onChange={e=>setForm({...form,text:e.target.value})} placeholder="What to remind you..." /></div>
            <div className="form-row">
              <div className="form-field"><label>Date & Time *</label><input type="text" value={form.time} onChange={e=>setForm({...form,time:e.target.value})} placeholder="e.g. Mar 20, 5:00 PM" /></div>
              <div className="form-field"><label>Category</label><select value={form.cat} onChange={e=>setForm({...form,cat:e.target.value})}>{CATS.map(c=><option key={c}>{c}</option>)}</select></div>
            </div>
            <div className="modal-actions">
              <button className="btn btn-ghost" onClick={()=>setShow(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={add}>Add Reminder 🔔</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
