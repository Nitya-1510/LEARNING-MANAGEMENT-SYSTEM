import React, { useState } from 'react';
import { useDept } from '../context/DeptContext';

export default function Roadmap() {
  const { dept, currentDept } = useDept();
  const [activeYear, setActiveYear] = useState(3);

  const years = [
    { year:1, title:'Foundation Year',     emoji:'🌱', color:'#6375ff', focus:'Build strong basics', highlights: dept.roadmapHighlights?.[0] || 'Core subjects and fundamentals' },
    { year:2, title:'Core Building Year',  emoji:'🔨', color:'#0891b2', focus:'Deep dive into core subjects', highlights: dept.roadmapHighlights?.[1] || 'Core engineering subjects' },
    { year:3, title:'Specialization Year', emoji:'⚡', color:'#d97706', focus:'Internships & specialization', highlights: dept.roadmapHighlights?.[2] || 'Specialization and internships' },
    { year:4, title:'Placement Ready',     emoji:'🚀', color:'#059669', focus:'Crack placements!', highlights: dept.roadmapHighlights?.[3] || 'Placements and final project' },
  ];

  return (
    <div className="page">
      <div className="page-header">
        <h2>Career Roadmap 🗺️</h2>
        <p style={{display:'flex',alignItems:'center',gap:8}}>
          <span style={{background:`${dept.color}22`,color:dept.color,padding:'2px 10px',borderRadius:20,fontSize:12,fontWeight:700}}>{dept.icon} {currentDept}</span>
          Year 1 → Year 4 guide for {dept.name}
        </p>
      </div>

      {/* Year Selector */}
      <div style={{display:'flex',gap:10,marginBottom:20,flexWrap:'wrap'}}>
        {years.map(y => (
          <button key={y.year} onClick={()=>setActiveYear(y.year)}
            style={{flex:1,minWidth:100,padding:'12px 10px',borderRadius:12,border:`2px solid ${activeYear===y.year?y.color:'var(--border)'}`,background:activeYear===y.year?`${y.color}18`:'var(--bg2)',cursor:'pointer',transition:'.2s',fontFamily:'DM Sans,sans-serif',textAlign:'center'}}>
            <div style={{fontSize:22,marginBottom:4}}>{y.emoji}</div>
            <div style={{fontSize:12,fontWeight:700,color:activeYear===y.year?y.color:'var(--text)'}}>Year {y.year}</div>
            <div style={{fontSize:10,color:'var(--muted)'}}>{y.title}</div>
          </button>
        ))}
      </div>

      {/* Active Year Detail */}
      {years.filter(y=>y.year===activeYear).map(y => (
        <div key={y.year}>
          <div style={{background:`linear-gradient(135deg,${y.color}33,${y.color}11)`,border:`1px solid ${y.color}44`,borderRadius:16,padding:20,marginBottom:20}}>
            <div style={{display:'flex',alignItems:'center',gap:12,marginBottom:8}}>
              <span style={{fontSize:32}}>{y.emoji}</span>
              <div>
                <div style={{fontSize:18,fontWeight:800,fontFamily:'Syne,sans-serif'}}>Year {y.year} — {y.title}</div>
                <div style={{fontSize:13,color:'var(--muted)',marginTop:2}}>🎯 Focus: {y.focus}</div>
              </div>
            </div>
            <div style={{background:'rgba(0,0,0,0.15)',borderRadius:10,padding:'10px 14px',fontSize:13}}>
              📌 {y.highlights}
            </div>
          </div>

          {/* Skills & Certifications */}
          <div className="grid-2" style={{marginBottom:20}}>
            <div className="card">
              <div style={{fontWeight:700,fontSize:13,marginBottom:12}}>🛠️ Key Skills for {currentDept}</div>
              <div style={{display:'flex',flexWrap:'wrap',gap:7}}>
                {dept.skills?.map(s => (
                  <span key={s} style={{background:`${dept.color}15`,color:dept.color,padding:'5px 12px',borderRadius:20,fontSize:11,fontWeight:600}}>{s}</span>
                ))}
              </div>
            </div>
            <div className="card">
              <div style={{fontWeight:700,fontSize:13,marginBottom:12}}>🏆 Certifications to Target</div>
              {dept.certifications?.map(c => (
                <div key={c} style={{display:'flex',alignItems:'center',gap:8,padding:'6px 0',borderBottom:'1px solid var(--border)'}}>
                  <span style={{color:'#34d399',fontSize:14}}>✅</span>
                  <span style={{fontSize:12}}>{c}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Clubs & Career */}
          <div className="grid-2">
            <div className="card">
              <div style={{fontWeight:700,fontSize:13,marginBottom:12}}>🎯 Clubs to Join</div>
              {dept.clubs?.map(c => (
                <div key={c} style={{display:'flex',alignItems:'center',gap:8,padding:'7px 0',borderBottom:'1px solid var(--border)'}}>
                  <span>⭐</span>
                  <span style={{fontSize:12,fontWeight:600}}>{c}</span>
                </div>
              ))}
            </div>
            <div className="card">
              <div style={{fontWeight:700,fontSize:13,marginBottom:12}}>💼 Career After {currentDept}</div>
              <div style={{marginBottom:10}}>
                <div style={{fontSize:11,color:'var(--muted)',marginBottom:5}}>Top Roles</div>
                {dept.careerRoles?.map(r => (
                  <div key={r} style={{display:'flex',alignItems:'center',gap:8,padding:'5px 0'}}>
                    <span style={{color:dept.color}}>→</span>
                    <span style={{fontSize:12}}>{r}</span>
                  </div>
                ))}
              </div>
              <div style={{display:'flex',gap:10,marginTop:8}}>
                <div style={{flex:1,background:'rgba(52,211,153,0.08)',borderRadius:8,padding:'8px 10px',textAlign:'center'}}>
                  <div style={{fontSize:10,color:'var(--muted)'}}>Avg CTC</div>
                  <div style={{fontWeight:700,color:'#34d399',fontSize:13}}>{dept.avgCTC}</div>
                </div>
                <div style={{flex:1,background:'rgba(251,191,36,0.08)',borderRadius:8,padding:'8px 10px',textAlign:'center'}}>
                  <div style={{fontSize:10,color:'var(--muted)'}}>Top CTC</div>
                  <div style={{fontWeight:700,color:'#fbbf24',fontSize:12}}>{dept.topCTC}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
