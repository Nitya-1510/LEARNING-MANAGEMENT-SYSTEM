import React, { useState } from 'react';
const INIT = [
  {id:1,title:'DS Revision',content:'BFS uses Queue, DFS uses Stack. Dijkstra = shortest path in weighted graph (no negative edges). Prim = MST. Kruskal = MST (sort edges). AVL keeps balance factor ≤ 1.',tag:'DS',date:'Mar 10'},
  {id:2,title:'DBMS Key Concepts',content:'ACID: Atomicity+Consistency+Isolation+Durability. 1NF→2NF→3NF→BCNF→4NF. LEFT JOIN = all left rows + matching right. Transaction isolation levels: Read Uncommitted, Read Committed, Repeatable Read, Serializable.',tag:'DBMS',date:'Mar 9'},
  {id:3,title:'OS Important Points',content:'Deadlock: 4 conditions must hold. Banker\'s Algorithm = deadlock avoidance. TLB caches page table entries. Paging = no external fragmentation. Segmentation = no internal fragmentation. FCFS may cause convoy effect.',tag:'OS',date:'Mar 8'},
];
export default function Notes({ showToast }) {
  const [notes, setNotes] = useState(INIT);
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [preview, setPreview] = useState(null);
  const [form, setForm] = useState({ title:'', content:'', tag:'General' });
  const filtered = notes.filter(n => !search || n.title.toLowerCase().includes(search.toLowerCase()) || n.content.toLowerCase().includes(search.toLowerCase()));
  const add = () => {
    if (!form.title || !form.content) return;
    setNotes(p => [{ id: Date.now(), ...form, date: 'Mar 13' }, ...p]);
    setForm({ title:'', content:'', tag:'General' });
    setShowModal(false);
    showToast('Note saved! 📓', '✅');
  };
  const del = (id) => { setNotes(p => p.filter(n => n.id !== id)); showToast('Note deleted', '🗑️'); };
  const COLORS = { DS:'#6375ff', DBMS:'#0891b2', OS:'#d97706', CN:'#059669', Math:'#7c3aed', General:'#64748b' };
  return (
    <div className="page">
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:18 }}>
        <div className="page-header" style={{marginBottom:0}}><h2>My Notes 📓</h2><p>Create and organize your study notes by subject</p></div>
        <button className="btn btn-primary btn-sm" onClick={() => setShowModal(true)}>+ New Note</button>
      </div>
      <div style={{ position:'relative', marginBottom:16 }}>
        <span style={{ position:'absolute', left:13, top:'50%', transform:'translateY(-50%)' }}>🔍</span>
        <input type="text" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search notes..." style={{ paddingLeft:40 }} />
      </div>
      <div className="grid-3">
        {filtered.map(n => (
          <div key={n.id} className="card" onClick={() => setPreview(n)} style={{ cursor:'pointer', borderTop:`3px solid ${COLORS[n.tag]||'#64748b'}`, transition:'.2s' }} onMouseEnter={e=>e.currentTarget.style.transform='translateY(-3px)'} onMouseLeave={e=>e.currentTarget.style.transform='none'}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:8 }}>
              <h4 style={{ fontSize:14, flex:1 }}>{n.title}</h4>
              <span className="tag tag-purple" style={{ fontSize:10, marginLeft:6 }}>{n.tag}</span>
            </div>
            <p style={{ fontSize:12, color:'var(--muted)', lineHeight:1.65, marginBottom:12 }}>{n.content.slice(0,100)}{n.content.length>100?'...':''}</p>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
              <span style={{ fontSize:11, color:'var(--muted)' }}>{n.date}</span>
              <button className="btn btn-danger btn-sm" onClick={e=>{e.stopPropagation();del(n.id);}} style={{ padding:'3px 8px', fontSize:10 }}>🗑</button>
            </div>
          </div>
        ))}
        <div className="card" onClick={() => setShowModal(true)} style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', border:'2px dashed var(--border)', cursor:'pointer', minHeight:130, transition:'.2s' }} onMouseEnter={e=>e.currentTarget.style.borderColor='#6375ff'} onMouseLeave={e=>e.currentTarget.style.borderColor='var(--border)'}>
          <div style={{ fontSize:28, marginBottom:8 }}>📝</div>
          <div style={{ fontSize:12, color:'var(--muted)' }}>Add New Note</div>
        </div>
      </div>
      {showModal && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setShowModal(false)}>
          <div className="modal">
            <div className="modal-header"><h3>📝 New Note</h3><button className="modal-close" onClick={()=>setShowModal(false)}>×</button></div>
            <div className="form-field"><label>Title *</label><input type="text" value={form.title} onChange={e=>setForm({...form,title:e.target.value})} placeholder="Note title..." /></div>
            <div className="form-field"><label>Subject Tag</label>
              <select value={form.tag} onChange={e=>setForm({...form,tag:e.target.value})}>
                {['DS','DBMS','OS','CN','Math','General'].map(t=><option key={t}>{t}</option>)}
              </select>
            </div>
            <div className="form-field"><label>Content *</label><textarea rows={5} value={form.content} onChange={e=>setForm({...form,content:e.target.value})} placeholder="Write your notes here..." /></div>
            <div className="modal-actions">
              <button className="btn btn-ghost" onClick={()=>setShowModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={add}>Save Note 💾</button>
            </div>
          </div>
        </div>
      )}
      {preview && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setPreview(null)}>
          <div className="modal">
            <div className="modal-header">
              <div><h3>{preview.title}</h3><span className="tag tag-purple" style={{marginTop:6}}>{preview.tag}</span></div>
              <button className="modal-close" onClick={()=>setPreview(null)}>×</button>
            </div>
            <p style={{ fontSize:14, lineHeight:1.8, color:'var(--muted)', whiteSpace:'pre-wrap' }}>{preview.content}</p>
            <div style={{ fontSize:12, color:'var(--muted)', marginTop:14 }}>Created: {preview.date}</div>
          </div>
        </div>
      )}
    </div>
  );
}
