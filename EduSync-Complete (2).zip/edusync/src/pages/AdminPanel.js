import React, { useState } from 'react';

const ADMIN_EMAIL = 'akshayadarshini.n@gmail.com';

export default function AdminPanel({ user, showToast }) {
  const isAdmin = user?.email === ADMIN_EMAIL;
  const [announcements, setAnnouncements] = useState([
    { id:1, title:'Internal Exam Schedule Released', date:'Mar 5, 2026', type:'Exam', msg:'Internal exams will be held from Mar 15 to Mar 30. Check the calendar for subject-wise dates and hall assignments.', priority:'High' },
    { id:2, title:'Hackathon Registration Open', date:'Mar 3, 2026', type:'Event', msg:'Anna University Hackathon 2026 registrations are open. Team size: 2-4. Prizes worth ₹1,00,000. Register before Mar 15.', priority:'Medium' },
    { id:3, title:'TCS & Infosys Campus Drive', date:'Mar 1, 2026', type:'Placement', msg:'TCS and Infosys placement drives are scheduled for Mar 25-28. Eligible students must register with placement cell by Mar 20.', priority:'High' },
  ]);
  const [form, setForm] = useState({ title:'', msg:'', type:'General', priority:'Medium' });
  const [showForm, setShowForm] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');

  const STATS = [
    {icon:'👥',label:'Total Students',val:'1,240',sub:'+12 this week',color:'#6375ff'},
    {icon:'📝',label:'Active Assignments',val:'18',sub:'5 due today',color:'#fb923c'},
    {icon:'💼',label:'Internship Listings',val:'8',sub:'3 closing soon',color:'#34d399'},
    {icon:'🏢',label:'Company Drives',val:'6',sub:'2 ongoing',color:'#0891b2'},
    {icon:'🎓',label:'NPTEL Enrollments',val:'147',sub:'Across all courses',color:'#a78bfa'},
    {icon:'📅',label:'Upcoming Exams',val:'5',sub:'Mar 15 – Mar 30',color:'#fbbf24'},
  ];

  const MANAGE = [
    {icon:'💼',title:'Internships',desc:'Add, edit, remove listings',color:'#6375ff',count:8},
    {icon:'🏢',title:'Placements',desc:'Manage company drives',color:'#34d399',count:6},
    {icon:'▶️',title:'Courses',desc:'Add video materials',color:'#0891b2',count:24},
    {icon:'📄',title:'Question Papers',desc:'Upload past papers',color:'#fb923c',count:25},
    {icon:'📅',title:'Exam Calendar',desc:'Set exam schedules',color:'#a78bfa',count:5},
    {icon:'🎉',title:'Events',desc:'Create/manage events',color:'#fbbf24',count:6},
    {icon:'🎓',title:'NPTEL',desc:'Update course listings',color:'#f87171',count:9},
    {icon:'👥',title:'Students',desc:'View & manage students',color:'#38bdf8',count:1240},
  ];

  const postAnnounce = () => {
    if (!form.title||!form.msg) return;
    setAnnouncements(prev=>[{id:Date.now(),...form,date:'Mar 10, 2026'},...prev]);
    setForm({title:'',msg:'',type:'General',priority:'Medium'});
    setShowForm(false);
    showToast('📢 Announcement sent to all students!','✅');
  };

  if (!isAdmin) return (
    <div className="page">
      <div style={{textAlign:'center',padding:'80px 20px'}}>
        <div style={{fontSize:64,marginBottom:20}}>🔒</div>
        <h2>Admin Access Only</h2>
        <p style={{color:'var(--muted)',marginTop:8}}>This section is restricted to administrators.</p>
        <p style={{color:'var(--muted)',fontSize:13,marginTop:6}}>Logged in as: {user?.email}</p>
        <p style={{color:'var(--muted)',fontSize:13}}>Only Akshaya Darshini has admin access.</p>
      </div>
    </div>
  );

  return (
    <div className="page">
      <div className="page-header">
        <div style={{display:'flex',alignItems:'center',gap:14}}>
          <div style={{width:52,height:52,borderRadius:14,background:'linear-gradient(135deg,#6375ff,#a78bfa)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:24}}>🛡️</div>
          <div><h2>Admin Panel</h2><p>Welcome, {user.name} — Full administrative access</p></div>
        </div>
      </div>

      <div style={{display:'flex',gap:8,marginBottom:24,flexWrap:'wrap'}}>
        {[['overview','📊 Overview'],['manage','⚙️ Manage'],['announce','📢 Announcements']].map(([id,label])=>(
          <button key={id} className={`filter-btn ${activeTab===id?'active':''}`} onClick={()=>setActiveTab(id)} style={{padding:'8px 18px',fontWeight:700}}>{label}</button>
        ))}
      </div>

      {activeTab==='overview' && (
        <>
          <div className="grid-3" style={{marginBottom:28}}>
            {STATS.map(s=>(
              <div className="card card-sm" key={s.label} style={{display:'flex',alignItems:'center',gap:14}}>
                <div style={{width:48,height:48,borderRadius:13,background:`${s.color}22`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:22,flexShrink:0}}>{s.icon}</div>
                <div><div style={{fontSize:26,fontWeight:800,fontFamily:'Syne,sans-serif',color:s.color}}>{s.val}</div><div style={{fontSize:12,fontWeight:600}}>{s.label}</div><div style={{fontSize:11,color:'var(--muted)'}}>{s.sub}</div></div>
              </div>
            ))}
          </div>
          <div className="card">
            <div style={{fontWeight:700,fontSize:15,marginBottom:16}}>📈 Quick Summary</div>
            {[['Total Internships Active','8','💼','#6375ff'],['Students Registered for Placement','342 / 1240','🏢','#34d399'],['NPTEL Courses Offered','9','🎓','#fb923c'],['Events This Month','6','🎉','#a78bfa'],['Question Papers Available','25','📄','#0891b2'],['Pending Assignment Submissions','47','📝','#fbbf24']].map(([label,val,icon,color])=>(
              <div key={label} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'10px 0',borderBottom:'1px solid var(--border)'}}>
                <span style={{fontSize:13,display:'flex',gap:8,alignItems:'center'}}><span>{icon}</span>{label}</span>
                <span style={{fontSize:14,fontWeight:700,color}}>{val}</span>
              </div>
            ))}
          </div>
        </>
      )}

      {activeTab==='manage' && (
        <div className="grid-4">
          {MANAGE.map(m=>(
            <div key={m.title} className="card" onClick={()=>showToast(`Opening ${m.title} management...`,'⚙️')} style={{cursor:'pointer',borderTop:`3px solid ${m.color}`,textAlign:'center',transition:'.2s'}} onMouseEnter={e=>e.currentTarget.style.transform='translateY(-3px)'} onMouseLeave={e=>e.currentTarget.style.transform='none'}>
              <div style={{fontSize:30,marginBottom:10}}>{m.icon}</div>
              <div style={{fontWeight:700,fontSize:14}}>{m.title}</div>
              <div style={{fontSize:12,color:'var(--muted)',margin:'4px 0 8px'}}>{m.desc}</div>
              <div style={{fontSize:11,fontWeight:700,color:m.color,background:`${m.color}18`,padding:'3px 10px',borderRadius:20,display:'inline-block'}}>{m.count} records</div>
            </div>
          ))}
        </div>
      )}

      {activeTab==='announce' && (
        <>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:20}}>
            <div style={{fontWeight:700,fontSize:16}}>📢 Announcements to Students</div>
            <button className="btn btn-primary" onClick={()=>setShowForm(!showForm)}>+ New Announcement</button>
          </div>
          {showForm&&(
            <div className="card" style={{marginBottom:20,border:'1px solid #6375ff'}}>
              <div style={{fontWeight:700,marginBottom:16}}>📢 Create Announcement</div>
              <div className="form-field"><label>Title *</label><input type="text" value={form.title} onChange={e=>setForm({...form,title:e.target.value})} placeholder="Announcement title..." /></div>
              <div className="form-row">
                <div className="form-field"><label>Type</label><select value={form.type} onChange={e=>setForm({...form,type:e.target.value})}>{['General','Exam','Event','Placement','Holiday','Workshop'].map(t=><option key={t}>{t}</option>)}</select></div>
                <div className="form-field"><label>Priority</label><select value={form.priority} onChange={e=>setForm({...form,priority:e.target.value})}>{['High','Medium','Low'].map(p=><option key={p}>{p}</option>)}</select></div>
              </div>
              <div className="form-field"><label>Message *</label><textarea rows={3} value={form.msg} onChange={e=>setForm({...form,msg:e.target.value})} placeholder="Type your announcement here..." /></div>
              <div className="modal-actions" style={{marginTop:0}}>
                <button className="btn btn-ghost" onClick={()=>setShowForm(false)}>Cancel</button>
                <button className="btn btn-primary" onClick={postAnnounce}>📢 Send to All Students</button>
              </div>
            </div>
          )}
          <div style={{display:'flex',flexDirection:'column',gap:12}}>
            {announcements.map(a=>{
              const pc = a.priority==='High'?'#f87171':a.priority==='Medium'?'#fb923c':'#34d399';
              return (
                <div key={a.id} className="card card-sm" style={{borderLeft:`4px solid ${pc}`}}>
                  <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:8}}>
                    <div style={{fontWeight:700,fontSize:14}}>{a.title}</div>
                    <div style={{display:'flex',gap:6}}>
                      <span style={{background:`${pc}22`,color:pc,padding:'2px 8px',borderRadius:20,fontSize:11,fontWeight:700}}>{a.priority}</span>
                      <span style={{background:'rgba(56,189,248,0.15)',color:'#38bdf8',padding:'2px 8px',borderRadius:20,fontSize:11,fontWeight:700}}>{a.type}</span>
                    </div>
                  </div>
                  <p style={{fontSize:13,color:'var(--muted)',lineHeight:1.6,marginBottom:6}}>{a.msg}</p>
                  <div style={{fontSize:11,color:'var(--muted)'}}>{a.date} • Sent to all students</div>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}
