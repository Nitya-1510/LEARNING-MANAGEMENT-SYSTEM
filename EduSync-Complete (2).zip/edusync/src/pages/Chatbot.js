import React, { useState, useRef, useEffect } from 'react';
import { useDept } from '../context/DeptContext';

const GEMINI_API_KEY = 'AIzaSyCxuOXijafnZZe0ERsdDGKSQvrFAn8j2qM';

const SUGGESTED = [
  'What is a parse tree?',
  'Explain recursion with example',
  'Write bubble sort in Python',
  'How to crack TCS interview?',
  'What is machine learning?',
  'Explain VLSI design simply',
  'How to improve CGPA?',
  'What is CRISPR technology?',
  'Difference between TCP and UDP',
  'How do I write a good resume?',
];

export default function Chatbot() {
  const { dept, currentDept } = useDept();
  const [messages,  setMessages]  = useState([{
    role: 'assistant',
    text: `Hi! 👋 I'm EduSync AI powered by Google Gemini!\n\nI can answer **ANY question** — academic, coding, career, general knowledge, maths, anything!\n\nAsk me anything! 😊`,
    time: new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'}),
  }]);
  const [input,   setInput]   = useState('');
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState([]);
  const bottomRef   = useRef(null);
  const textareaRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior:'smooth' });
  }, [messages, loading]);

  const sendMessage = async (text) => {
    if (!text.trim() || loading) return;

    const userMsg = {
      role: 'user',
      text: text.trim(),
      time: new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'}),
    };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    if (textareaRef.current) textareaRef.current.style.height = 'auto';
    setLoading(true);

    try {
      // ── Build conversation for Gemini ──
      const systemInstruction = `You are EduSync AI, a smart academic assistant for engineering students in India.
Student context: ${currentDept} department, Semester ${dept.sem}.
Current subjects: ${dept.subjects?.map(s => s.name).join(', ')}.
Career roles: ${dept.careerRoles?.join(', ')}.
Skills needed: ${dept.skills?.join(', ')}.

RULES:
- Answer EVERY question clearly and helpfully
- Use simple language with emojis
- For code questions, provide working code
- For math, show step by step
- Keep answers well structured
- Never refuse to answer any question
- Answer in the language the student asks`;

      // Build messages array with history
      const contents = [];

      // Add history
      history.forEach(h => contents.push(h));

      // Add current message
      contents.push({
        role: 'user',
        parts: [{ text: `${systemInstruction}\n\nQuestion: ${text.trim()}` }]
      });

      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents,
            generationConfig: {
              temperature:      0.7,
              maxOutputTokens:  1000,
              topP:             0.9,
            },
          }),
        }
      );

      const data = await response.json();
      console.log('Gemini response:', data);

      // Extract text from response
      const aiText = data?.candidates?.[0]?.content?.parts?.[0]?.text;

      if (aiText) {
        // Save to history
        setHistory(prev => [
          ...prev,
          { role:'user',  parts:[{ text: text.trim() }] },
          { role:'model', parts:[{ text: aiText        }] },
        ]);

        setMessages(prev => [...prev, {
          role: 'assistant',
          text: aiText,
          time: new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'}),
          isAI: true,
        }]);
      } else {
        // Show actual error from Gemini
        const errorMsg = data?.error?.message || JSON.stringify(data);
        throw new Error(errorMsg);
      }

    } catch (err) {
      console.error('Gemini error:', err);
      setMessages(prev => [...prev, {
        role: 'assistant',
        text: `⚠️ Error: ${err.message}\n\nPlease try again in a moment!`,
        time: new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'}),
        isError: true,
      }]);
    }

    setLoading(false);
  };

  const handleKey = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  };

  const clearChat = () => {
    setHistory([]);
    setMessages([{
      role: 'assistant',
      text: `Chat cleared! 🔄 Ask me anything!\n\n📚 Subjects • 💻 Coding • 🧮 Maths • 💼 Career • 🌍 Anything!`,
      time: new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'}),
    }]);
  };

  const formatText = (text) => {
    return text
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g,     '<em>$1</em>')
      .replace(/`(.*?)`/g,       '<code style="background:rgba(99,117,255,0.2);padding:2px 6px;border-radius:4px;font-size:12px;font-family:monospace">$1</code>')
      .replace(/```[\w]*\n?([\s\S]*?)```/g, '<pre style="background:rgba(0,0,0,0.3);padding:12px;border-radius:8px;overflow-x:auto;font-size:12px;font-family:monospace;margin:8px 0;white-space:pre-wrap;line-height:1.5">$1</pre>')
      .replace(/^#{3}\s(.+)/gm,  '<strong style="font-size:14px">$1</strong>')
      .replace(/^#{2}\s(.+)/gm,  '<strong style="font-size:15px">$1</strong>')
      .replace(/^#{1}\s(.+)/gm,  '<strong style="font-size:16px">$1</strong>')
      .replace(/^[-•]\s(.+)/gm,  '• $1')
      .replace(/\n/g, '<br/>');
  };

  return (
    <div className="page" style={{display:'flex', flexDirection:'column', height:'calc(100vh - 60px)'}}>

      {/* Header */}
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12, flexShrink:0}}>
        <div style={{display:'flex', alignItems:'center', gap:12}}>
          <div style={{width:46, height:46, borderRadius:13, background:'linear-gradient(135deg,#6375ff,#db2777)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:22}}>🤖</div>
          <div>
            <div style={{fontSize:16, fontWeight:800, fontFamily:'Syne,sans-serif'}}>EduSync AI Assistant</div>
            <div style={{display:'flex', alignItems:'center', gap:6, marginTop:2, flexWrap:'wrap'}}>
              <span style={{width:7, height:7, borderRadius:'50%', background:'#34d399', display:'inline-block', boxShadow:'0 0 6px #34d399'}}></span>
              <span style={{fontSize:11, color:'#34d399', fontWeight:600}}>Gemini AI Active</span>
              <span style={{background:`${dept.color}22`, color:dept.color, padding:'1px 8px', borderRadius:20, fontSize:10, fontWeight:700}}>{dept.icon} {currentDept}</span>
            </div>
          </div>
        </div>
        <button onClick={clearChat} style={{background:'var(--bg3)', border:'1px solid var(--border)', borderRadius:9, padding:'7px 13px', cursor:'pointer', fontSize:12, fontWeight:600, color:'var(--muted)', fontFamily:'DM Sans,sans-serif'}}>
          🗑️ Clear
        </button>
      </div>

      {/* Messages */}
      <div style={{flex:1, overflowY:'auto', paddingRight:2, marginBottom:10}}>
        {messages.map((msg, i) => (
          <div key={i} style={{display:'flex', justifyContent:msg.role==='user'?'flex-end':'flex-start', marginBottom:14, alignItems:'flex-end', gap:8}}>
            {msg.role === 'assistant' && (
              <div style={{width:32, height:32, borderRadius:9, background:'linear-gradient(135deg,#6375ff,#db2777)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:15, flexShrink:0}}>🤖</div>
            )}
            <div style={{maxWidth:'80%'}}>
              <div
                style={{
                  background: msg.role==='user' ? 'linear-gradient(135deg,#6375ff,#818cf8)' : msg.isError ? 'rgba(239,68,68,0.1)' : 'var(--bg2)',
                  color:      msg.role==='user' ? '#fff' : 'var(--text)',
                  padding:    '13px 16px',
                  borderRadius: msg.role==='user' ? '18px 18px 4px 18px' : '4px 18px 18px 18px',
                  fontSize:   13,
                  lineHeight: 1.8,
                  border:     msg.role==='assistant' ? `1px solid ${msg.isError?'rgba(239,68,68,0.3)':'var(--border)'}` : 'none',
                }}
                dangerouslySetInnerHTML={{ __html: formatText(msg.text) }}
              />
              <div style={{fontSize:10, color:'var(--muted)', marginTop:3, textAlign:msg.role==='user'?'right':'left', display:'flex', alignItems:'center', gap:5, justifyContent:msg.role==='user'?'flex-end':'flex-start'}}>
                {msg.time}
                {msg.isAI && <span style={{color:'#6375ff', fontSize:9, fontWeight:600}}>✨ Gemini AI</span>}
              </div>
            </div>
            {msg.role === 'user' && (
              <div style={{width:32, height:32, borderRadius:9, background:'linear-gradient(135deg,#6375ff,#a78bfa)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:15, flexShrink:0}}>👤</div>
            )}
          </div>
        ))}

        {/* Typing */}
        {loading && (
          <div style={{display:'flex', alignItems:'flex-end', gap:8, marginBottom:14}}>
            <div style={{width:32, height:32, borderRadius:9, background:'linear-gradient(135deg,#6375ff,#db2777)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:15}}>🤖</div>
            <div style={{background:'var(--bg2)', border:'1px solid var(--border)', borderRadius:'4px 18px 18px 18px', padding:'13px 18px', display:'flex', alignItems:'center', gap:5}}>
              <span style={{fontSize:12, color:'var(--muted)', marginRight:4}}>Thinking...</span>
              {[0,1,2].map(i=>(
                <div key={i} style={{width:7, height:7, borderRadius:'50%', background:'#6375ff', animationName:'bounce', animationDuration:'1.2s', animationIterationCount:'infinite', animationDelay:`${i*0.15}s`}}></div>
              ))}
            </div>
          </div>
        )}
        <div ref={bottomRef}/>
      </div>

      {/* Suggested */}
      <div style={{display:'flex', gap:7, overflowX:'auto', paddingBottom:8, flexShrink:0, scrollbarWidth:'none'}}>
        {SUGGESTED.map(q=>(
          <button key={q} onClick={()=>sendMessage(q)}
            style={{background:'var(--bg2)', border:'1px solid var(--border)', borderRadius:20, padding:'6px 13px', fontSize:11, fontWeight:600, cursor:'pointer', color:'var(--text)', whiteSpace:'nowrap', fontFamily:'DM Sans,sans-serif', flexShrink:0, transition:'.2s'}}
            onMouseEnter={e=>{e.currentTarget.style.borderColor='#6375ff'; e.currentTarget.style.color='#6375ff';}}
            onMouseLeave={e=>{e.currentTarget.style.borderColor='var(--border)'; e.currentTarget.style.color='var(--text)';}}>
            {q}
          </button>
        ))}
      </div>

      {/* Input */}
      <div style={{display:'flex', gap:10, alignItems:'flex-end', flexShrink:0, marginTop:6}}>
        <textarea
          ref={textareaRef}
          value={input}
          onChange={e=>setInput(e.target.value)}
          onKeyDown={handleKey}
          placeholder="Ask me ANYTHING — type your question here... (Enter to send)"
          rows={1}
          style={{flex:1, resize:'none', borderRadius:14, padding:'13px 16px', fontSize:13, fontFamily:'DM Sans,sans-serif', background:'var(--bg2)', border:'2px solid var(--border)', color:'var(--text)', outline:'none', lineHeight:1.6, maxHeight:120, overflow:'auto'}}
          onInput={e=>{e.target.style.height='auto'; e.target.style.height=Math.min(e.target.scrollHeight,120)+'px';}}
        />
        <button
          onClick={()=>sendMessage(input)}
          disabled={!input.trim()||loading}
          style={{width:48, height:48, borderRadius:14, background:(!input.trim()||loading)?'var(--bg3)':'linear-gradient(135deg,#6375ff,#818cf8)', border:'none', cursor:(!input.trim()||loading)?'not-allowed':'pointer', fontSize:20, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0, transition:'.2s', color:(!input.trim()||loading)?'var(--muted)':'#fff'}}>
          {loading ? '⏳' : '➤'}
        </button>
      </div>

      <style>{`
        @keyframes bounce {
          0%, 60%, 100% { transform: translateY(0); }
          30% { transform: translateY(-6px); }
        }
      `}</style>
    </div>
  );
}
