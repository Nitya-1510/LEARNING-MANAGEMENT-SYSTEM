import React, { useState } from 'react';

const DAYS = ['Monday','Tuesday','Wednesday','Thursday','Friday'];
const TIMES = ['8:00-9:00','9:00-10:00','10:00-11:00','11:00-12:00','12:00-1:00','2:00-3:00','3:00-4:00','4:00-5:00'];
const DEFAULT_SUBJECTS = [
  {name:'DS',color:'#6375ff'},{name:'DBMS',color:'#0891b2'},{name:'OS',color:'#d97706'},
  {name:'CN',color:'#059669'},{name:'Math',color:'#7c3aed'},{name:'Lab',color:'#be123c'},
];
const PRESET = { 'Monday-0':'DS','Monday-1':'DBMS','Monday-2':'OS','Monday-4':'CN','Monday-5':'Math','Monday-6':'Lab','Tuesday-0':'DBMS','Tuesday-1':'DS','Tuesday-2':'CN','Tuesday-4':'OS','Tuesday-5':'Math','Tuesday-6':'DS','Wednesday-0':'CN','Wednesday-1':'Math','Wednesday-2':'DBMS','Wednesday-4':'DS','Wednesday-5':'Lab','Wednesday-6':'Lab','Thursday-0':'OS','Thursday-1':'DS','Thursday-2':'Math','Thursday-4':'DBMS','Thursday-5':'CN','Thursday-6':'OS','Friday-0':'Math','Friday-1':'OS','Friday-2':'DS','Friday-4':'CN','Friday-5':'DBMS' };

export default function TimetableBuilder({ showToast }) {
  const [subjects, setSubjects] = useState(DEFAULT_SUBJECTS);
  const [slots, setSlots] = useState({});
  const [active, setActive] = useState(null);
  const [eraser, setEraser] = useState(false);
  const [newName, setNewName] = useState('');
  const [newColor, setNewColor] = useState('#6375ff');

  const getColor = n => subjects.find(s=>s.name===n)?.color||'#444';

  const clickCell = (day, ti) => {
    if (ti===4) return; // break
    const key=`${day}-${ti}`;
    if (eraser){ const s={...slots};delete s[key];setSlots(s);return; }
    if (active) setSlots(p=>({...p,[key]:active}));
  };

  const addSubject = () => {
    if (!newName.trim()) return;
    setSubjects(p=>[...p,{name:newName.trim(),color:newColor}]);
    setActive(newName.trim());
    setNewName('');
    showToast(`Added ${newName} subject!`,'📚');
  };

  const removeSubject = (name) => {
    setSubjects(p=>p.filter(s=>s.name!==name));
    const s={...slots};
    Object.keys(s).forEach(k=>{if(s[k]===name)delete s[k];});
    setSlots(s);
    if(active===name)setActive(null);
  };

  return (
    <div className="page">
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:24,flexWrap:'wrap',gap:12}}>
        <div className="page-header" style={{marginBottom:0}}>
          <h2>Timetable Builder 🔨</h2>
          <p>Build your perfect custom weekly schedule</p>
        </div>
        <div style={{display:'flex',gap:8}}>
          <button className="btn btn-ghost btn-sm" onClick={()=>{setSlots(PRESET);showToast('Loaded CS Sem 5 preset!','📅');}}>Load CS Sem 5</button>
          <button className="btn btn-danger btn-sm" onClick={()=>{setSlots({});showToast('Cleared!','🗑');}}>Clear All</button>
          <button className="btn btn-primary btn-sm" onClick={()=>showToast('Timetable saved! ✨','💾')}>Save 💾</button>
        </div>
      </div>

      <div className="grid-2" style={{marginBottom:22,alignItems:'start'}}>
        <div className="card">
          <div style={{fontWeight:700,fontSize:15,marginBottom:14}}>📚 Subject Palette</div>
          <div style={{display:'flex',gap:8,marginBottom:14}}>
            <button className={`filter-btn ${!eraser?'active':''}`} onClick={()=>{setEraser(false);}}>✏️ Draw</button>
            <button className={`filter-btn ${eraser?'active':''}`} onClick={()=>{setEraser(true);setActive(null);}} style={{color:eraser?'#f87171':'',borderColor:eraser?'#f87171':''}}>🗑 Erase</button>
          </div>
          <div style={{display:'flex',flexWrap:'wrap',gap:8,marginBottom:16}}>
            {subjects.map(s=>(
              <div key={s.name} style={{display:'flex',alignItems:'center',gap:2}}>
                <button onClick={()=>{setActive(s.name);setEraser(false);}} style={{padding:'7px 12px',borderRadius:10,border:`2px solid ${active===s.name?s.color:'transparent'}`,background:`${s.color}20`,color:s.color,fontWeight:700,cursor:'pointer',fontSize:13,fontFamily:'DM Sans,sans-serif',transform:active===s.name?'scale(1.08)':'scale(1)',transition:'.15s'}}>{s.name}</button>
                <button onClick={()=>removeSubject(s.name)} style={{background:'none',border:'none',color:'var(--muted)',cursor:'pointer',fontSize:14,padding:'2px 4px',lineHeight:1}} title="Remove">×</button>
              </div>
            ))}
          </div>
          {active&&!eraser&&<div style={{background:`${getColor(active)}18`,border:`1px solid ${getColor(active)}40`,borderRadius:10,padding:'10px 14px',fontSize:13,color:getColor(active),fontWeight:600,marginBottom:14}}>✏️ Click any cell → place <b>{active}</b></div>}
          {eraser&&<div style={{background:'rgba(248,113,113,0.1)',border:'1px solid rgba(248,113,113,0.3)',borderRadius:10,padding:'10px 14px',fontSize:13,color:'#f87171',fontWeight:600,marginBottom:14}}>🗑 Click any cell to erase</div>}
          <div style={{borderTop:'1px solid var(--border)',paddingTop:14}}>
            <div style={{fontSize:12,fontWeight:700,color:'var(--muted)',textTransform:'uppercase',marginBottom:10}}>Add New Subject</div>
            <div style={{display:'flex',gap:8,alignItems:'center'}}>
              <input type="text" value={newName} onChange={e=>setNewName(e.target.value)} onKeyDown={e=>e.key==='Enter'&&addSubject()} placeholder="Subject name..." style={{flex:1}} />
              <input type="color" value={newColor} onChange={e=>setNewColor(e.target.value)} style={{width:38,height:38,borderRadius:8,border:'1px solid var(--border)',padding:2,cursor:'pointer',background:'none'}} />
              <button className="btn btn-primary btn-sm" onClick={addSubject}>Add</button>
            </div>
          </div>
        </div>
        <div className="card">
          <div style={{fontWeight:700,fontSize:15,marginBottom:14}}>📋 Instructions</div>
          {[['1️⃣','Click a subject to select it (highlighted border)'],['2️⃣','Click any grid cell to place it in the timetable'],['3️⃣','Switch to Erase mode to remove placed subjects'],['4️⃣','Add custom subjects with any color you choose'],['5️⃣','Load the CS Sem 5 preset to see a sample'],['6️⃣','Hit Save when you are happy with your schedule']].map(([n,t])=>(
            <div key={n} style={{display:'flex',gap:10,marginBottom:10,alignItems:'flex-start'}}>
              <span style={{fontSize:16,flexShrink:0}}>{n}</span>
              <span style={{fontSize:13,color:'var(--muted)',lineHeight:1.6}}>{t}</span>
            </div>
          ))}
          <div style={{marginTop:14,padding:'12px',background:'rgba(99,117,255,0.08)',borderRadius:10,fontSize:13,color:'var(--muted)'}}>
            💡 <b>Tip:</b> Cells showing <i>12:00-1:00</i> are lunch breaks — clicking them does nothing.
          </div>
        </div>
      </div>

      <div className="card" style={{overflowX:'auto'}}>
        <div style={{fontWeight:700,fontSize:15,marginBottom:16}}>📅 Weekly Schedule Grid</div>
        <table style={{width:'100%',borderCollapse:'collapse',minWidth:580}}>
          <thead>
            <tr>
              <th style={{background:'var(--bg3)',padding:'10px',fontSize:11,fontWeight:700,color:'var(--muted)',border:'1px solid var(--border)',textTransform:'uppercase',minWidth:95}}>Time</th>
              {DAYS.map(d=><th key={d} style={{background:'var(--bg3)',padding:'10px',fontSize:11,fontWeight:700,color:'var(--muted)',border:'1px solid var(--border)',textTransform:'uppercase'}}>{d.slice(0,3)}</th>)}
            </tr>
          </thead>
          <tbody>
            {TIMES.map((time,ti)=>(
              <tr key={ti}>
                <td style={{padding:'6px 10px',border:'1px solid var(--border)',fontSize:11,color:ti===4?'var(--muted)':'var(--text)',fontWeight:600,whiteSpace:'nowrap',background:'var(--bg2)',textAlign:'center'}}>{time}</td>
                {DAYS.map(day=>{
                  const key=`${day}-${ti}`;
                  const sub=slots[key];
                  const col=sub?getColor(sub):null;
                  const isBreak=ti===4;
                  return (
                    <td key={day} style={{padding:'4px',border:'1px solid var(--border)',height:44}}>
                      {isBreak?(
                        <div style={{textAlign:'center',fontSize:10,color:'var(--muted)',padding:'8px',fontStyle:'italic'}}>LUNCH</div>
                      ):(
                        <div onClick={()=>clickCell(day,ti)} style={{height:'100%',minHeight:36,borderRadius:8,display:'flex',alignItems:'center',justifyContent:'center',fontSize:11,fontWeight:700,background:sub?`${col}25`:'transparent',color:sub?col:'rgba(255,255,255,0.1)',border:sub?`1px solid ${col}44`:'1px dashed rgba(255,255,255,0.06)',transition:'.15s',cursor:(active||eraser)?'pointer':'default',userSelect:'none'}} title={sub||'Click to place subject'}>
                          {sub||''}
                        </div>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
