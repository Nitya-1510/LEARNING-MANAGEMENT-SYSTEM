import React from 'react';
import { useDept } from '../context/DeptContext';

export default function ExamCalendar({ showToast }) {
  const { dept, currentDept } = useDept();
  const exams = dept.exams || [];

  return (
    <div className="page">
      <div className="page-header">
        <h2>Exam Calendar 📅</h2>
        <p style={{display:'flex',alignItems:'center',gap:8}}>
          <span style={{background:`${dept.color}22`,color:dept.color,padding:'2px 10px',borderRadius:20,fontSize:12,fontWeight:700}}>{dept.icon} {currentDept}</span>
          Upcoming exams for {dept.name}
        </p>
      </div>

      <div className="grid-4" style={{marginBottom:18}}>
        {[
          ['📅','Total Exams',exams.length,'#6375ff'],
          ['🔴','This Week',exams.filter(e=>e.days<=7).length,'#f87171'],
          ['🟡','Next Week',exams.filter(e=>e.days>7&&e.days<=14).length,'#fbbf24'],
          ['🟢','Later',exams.filter(e=>e.days>14).length,'#34d399'],
        ].map(([icon,label,val,color])=>(
          <div className="card card-sm" key={label} style={{display:'flex',alignItems:'center',gap:10}}>
            <div style={{width:40,height:40,borderRadius:11,background:`${color}22`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:18,flexShrink:0}}>{icon}</div>
            <div>
              <div style={{fontSize:22,fontWeight:800,fontFamily:'Syne,sans-serif',color}}>{val}</div>
              <div style={{fontSize:11,color:'var(--muted)'}}>{label}</div>
            </div>
          </div>
        ))}
      </div>

      {exams.length === 0 ? (
        <div className="card" style={{textAlign:'center',padding:40}}>
          <div style={{fontSize:40,marginBottom:12}}>📅</div>
          <h4>No exams scheduled for {dept.name}</h4>
        </div>
      ) : (
        exams.map((e,i) => (
          <div key={e.code} className="card" style={{marginBottom:12,borderLeft:`4px solid ${e.color}`}}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',flexWrap:'wrap',gap:10}}>
              <div style={{flex:1}}>
                <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:6}}>
                  <div style={{width:32,height:32,borderRadius:9,background:`${e.color}22`,display:'flex',alignItems:'center',justifyContent:'center',fontSize:14,fontWeight:800,color:e.color,flexShrink:0}}>{i+1}</div>
                  <div>
                    <div style={{fontSize:14,fontWeight:700}}>{e.subject}</div>
                    <div style={{fontSize:11,color:'var(--muted)'}}>{e.code}</div>
                  </div>
                </div>
                <div style={{display:'flex',gap:8,flexWrap:'wrap',marginBottom:8}}>
                  <span className="tag tag-blue">📅 {e.date}</span>
                  <span className="tag tag-purple">⏰ {e.time}</span>
                  <span className="tag tag-green">🏛️ {e.hall}</span>
                  <span className="tag tag-orange">⏱️ {e.duration}</span>
                </div>
                <div style={{background:'var(--bg3)',borderRadius:9,padding:'9px 12px',fontSize:12,color:'var(--muted)'}}>
                  📚 <strong>Syllabus:</strong> {e.syllabus}
                </div>
              </div>
              <div style={{textAlign:'center',background:`${e.color}15`,border:`2px solid ${e.color}33`,borderRadius:12,padding:'12px 16px',minWidth:80}}>
                <div style={{fontSize:28,fontWeight:900,fontFamily:'Syne,sans-serif',color:e.color,lineHeight:1}}>{e.days}</div>
                <div style={{fontSize:10,fontWeight:700,color:'var(--muted)',marginTop:2}}>DAYS LEFT</div>
              </div>
            </div>
          </div>
        ))
      )}
    </div>
  );
}
