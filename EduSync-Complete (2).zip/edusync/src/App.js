import React, { useState, useEffect } from 'react';
import './index.css';
import { DeptProvider } from './context/DeptContext';
import Login from './pages/Login';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Departments from './pages/Departments';
import Assignments from './pages/Assignments';
import QuestionPapers from './pages/QuestionPapers';
import ExamCalendar from './pages/ExamCalendar';
import Timetable from './pages/Timetable';
import TimetableBuilder from './pages/TimetableBuilder';
import Quiz from './pages/Quiz';
import Courses from './pages/Courses';
import NPTEL from './pages/NPTEL';
import Notes from './pages/Notes';
import GPACalculator from './pages/GPACalculator';
import Internships from './pages/Internships';
import Placements from './pages/Placements';
import Roadmap from './pages/Roadmap';
import Reminders from './pages/Reminders';
import Events from './pages/Events';
import Chatbot from './pages/Chatbot';
import AdminPanel from './pages/AdminPanel';

const BOTTOM_NAV = [
  { id:'dashboard',   icon:'🏠', label:'Home'   },
  { id:'departments', icon:'🏛️', label:'Depts'  },
  { id:'internships', icon:'💼', label:'Intern' },
  { id:'quiz',        icon:'🧩', label:'Quiz'   },
  { id:'chatbot',     icon:'🤖', label:'AI Bot' },
];

export default function App() {
  // ── Restore session from localStorage ──
  const [user,        setUser]        = useState(() => {
    try { const u = localStorage.getItem('edusync_user'); return u ? JSON.parse(u) : null; } catch { return null; }
  });
  const [page,        setPage]        = useState(() => localStorage.getItem('edusync_page') || 'dashboard');
  const [toast,       setToast]       = useState(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showLogout,  setShowLogout]  = useState(false);

  // ── Save session on every change ──
  useEffect(() => {
    if (user) localStorage.setItem('edusync_user', JSON.stringify(user));
    else       localStorage.removeItem('edusync_user');
  }, [user]);

  useEffect(() => {
    localStorage.setItem('edusync_page', page);
  }, [page]);

  // ── Warn before closing/refreshing tab ──
  useEffect(() => {
    if (!user) return;
    const handleBeforeUnload = (e) => {
      e.preventDefault();
      e.returnValue = 'You are logged in. Are you sure you want to leave EduSync?';
      return e.returnValue;
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [user]);

  const showToast = (msg, icon = '✅') => {
    setToast({ msg, icon });
    setTimeout(() => setToast(null), 3000);
  };

  const navigate = (p) => {
    setPage(p);
    setSidebarOpen(false);
    window.scrollTo(0, 0);
  };

  const handleLogin = (userData) => {
    setUser(userData);
    setPage('dashboard');
    showToast(`Welcome back, ${userData.name.split(' ')[0]}! 🎉`, '👋');
  };

  const handleLogout = () => {
    setShowLogout(false);
    setUser(null);
    setPage('dashboard');
    localStorage.removeItem('edusync_user');
    localStorage.removeItem('edusync_page');
  };

  if (!user) return <Login onLogin={handleLogin} />;

  const props = { showToast, setActivePage: navigate };

  const pages = {
    dashboard:           <Dashboard {...props} />,
    departments:         <Departments {...props} />,
    assignments:         <Assignments {...props} />,
    'question-papers':   <QuestionPapers {...props} />,
    'exam-calendar':     <ExamCalendar {...props} />,
    timetable:           <Timetable {...props} />,
    'timetable-builder': <TimetableBuilder {...props} />,
    quiz:                <Quiz {...props} />,
    courses:             <Courses {...props} />,
    nptel:               <NPTEL {...props} />,
    notes:               <Notes {...props} />,
    gpa:                 <GPACalculator {...props} />,
    internships:         <Internships {...props} />,
    placements:          <Placements {...props} />,
    roadmap:             <Roadmap {...props} />,
    reminders:           <Reminders {...props} />,
    events:              <Events {...props} />,
    chatbot:             <Chatbot {...props} />,
    admin:               <AdminPanel user={user} {...props} />,
  };

  return (
    <DeptProvider>
      <div className="app-layout">
        {sidebarOpen && <div className="sidebar-overlay" onClick={() => setSidebarOpen(false)} />}

        <Layout
          activePage={page}
          setActivePage={navigate}
          user={user}
          onLogout={() => setShowLogout(true)}
          sidebarOpen={sidebarOpen}
        />

        <main className="main-content">
          <div className="mobile-topbar">
            <button className="hamburger-btn" onClick={() => setSidebarOpen(!sidebarOpen)}>☰</button>
            <div style={{ display:'flex', alignItems:'center', gap:8 }}>
              <div className="logo-icon" style={{ width:30, height:30, fontSize:14 }}>🎓</div>
              <span style={{ fontFamily:'Syne,sans-serif', fontWeight:800, fontSize:16 }}>EduSync</span>
            </div>
            <div className="user-avatar" style={{ width:32, height:32, fontSize:13 }}>{user?.name?.[0] || 'A'}</div>
          </div>
          {pages[page] || pages.dashboard}
        </main>

        <nav className="bottom-nav">
          {BOTTOM_NAV.map(item => (
            <button key={item.id} className={`bnav-item ${page === item.id ? 'active' : ''}`} onClick={() => navigate(item.id)}>
              <span>{item.icon}</span>
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        {/* ── Toast ── */}
        {toast && (
          <div className="toast">
            <span>{toast.icon}</span>
            <span>{toast.msg}</span>
          </div>
        )}

        {/* ── Logout Confirmation Modal ── */}
        {showLogout && (
          <div className="modal-overlay" style={{ zIndex:9999 }}>
            <div className="modal" style={{ maxWidth:400, textAlign:'center', padding:36 }}>
              <div style={{ fontSize:52, marginBottom:12 }}>👋</div>
              <h3 style={{ fontSize:20, marginBottom:8 }}>Logging out?</h3>
              <p style={{ color:'var(--muted)', fontSize:14, lineHeight:1.7, marginBottom:24 }}>
                You are signed in as <strong style={{ color:'var(--text)' }}>{user?.name}</strong>.<br/>
                Your session will be cleared. Are you sure you want to logout?
              </p>
              <div style={{ display:'flex', gap:12, justifyContent:'center' }}>
                <button
                  className="btn btn-ghost"
                  style={{ flex:1, padding:'12px' }}
                  onClick={() => setShowLogout(false)}
                >
                  ← Stay
                </button>
                <button
                  className="btn btn-primary"
                  style={{ flex:1, padding:'12px', background:'#dc2626', borderColor:'#dc2626' }}
                  onClick={handleLogout}
                >
                  Logout →
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </DeptProvider>
  );
}
