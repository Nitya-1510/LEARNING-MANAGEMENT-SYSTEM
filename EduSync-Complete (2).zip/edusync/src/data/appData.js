// src/data/appData.js

export const USERS = [
  { email:'akshayadarshini.n@gmail.com', password:'aksh@2006', name:'Akshaya Darshini', sem:5, dept:'Computer Science', reg:'CS21001', role:'admin', cgpa:8.7, phone:'9876543210' },
  { email:'harivignesh@gmail.com', password:'hari@1111', name:'Hari Vignesh', sem:5, dept:'Computer Science', reg:'CS21002', role:'student', cgpa:8.4, phone:'9876543211' },
];

export const ASSIGNMENTS = [
  { id:1, title:'Sorting Algorithms Implementation', code:'CS3401', subject:'Data Structures', due:'Mar 18, 2026', daysLeft:5, maxMarks:25, status:'pending', progress:0, questions:['Implement Merge Sort and analyze its time complexity with examples.','Compare Quick Sort and Heap Sort performance on 10,000 random elements.','Write a program demonstrating Radix Sort for non-negative integers.'] },
  { id:2, title:'ER Diagram & Normalization', code:'CS3402', subject:'Database Management Systems', due:'Mar 22, 2026', daysLeft:9, maxMarks:20, status:'pending', progress:1, questions:['Design an ER diagram for a Library Management System with all entities and relationships.','Normalize the given relation to 3NF with proper explanation and steps.'] },
  { id:3, title:'TCP/IP Protocol Analysis', code:'CS3404', subject:'Computer Networks', due:'Mar 10, 2026', daysLeft:0, maxMarks:20, status:'submitted', progress:2, scored:18, questions:['Explain the TCP three-way handshake with a packet diagram.','Compare TCP and UDP with use cases for each protocol.'] },
  { id:4, title:'Process Scheduling Algorithms', code:'CS3403', subject:'Operating Systems', due:'Mar 8, 2026', daysLeft:-5, maxMarks:30, status:'overdue', progress:0, questions:['Simulate FCFS, SJF and Round Robin scheduling with given process table.','Calculate average waiting time and turnaround time for all algorithms.','Explain deadlock avoidance using Bankers Algorithm with an example.'] },
  { id:5, title:'Computer Architecture Lab', code:'CS3405', subject:'Computer Organization', due:'Mar 30, 2026', daysLeft:17, maxMarks:25, status:'pending', progress:0, questions:['Implement a 4-bit adder circuit and verify its truth table.','Design a simple ALU supporting ADD, SUB, AND, OR operations.'] },
];

export const EXAMS = [
  { id:1, subject:'Data Structures', code:'CS3401', date:'Mar 15', day:15, time:'10:00 AM', hall:'Hall A - Block 2', duration:'3 Hours', daysLeft:2, month:'MAR', syllabus:'Units 1-5: Arrays, Linked Lists, Trees, Graphs, Sorting' },
  { id:2, subject:'Database Management', code:'CS3402', date:'Mar 18', day:18, time:'10:00 AM', hall:'Hall B - Block 2', duration:'3 Hours', daysLeft:5, month:'MAR', syllabus:'Units 1-5: ER Model, SQL, Normalization, Transactions' },
  { id:3, subject:'Operating Systems', code:'CS3403', date:'Mar 22', day:22, time:'10:00 AM', hall:'Hall A - Block 3', duration:'3 Hours', daysLeft:9, month:'MAR', syllabus:'Units 1-5: Process Management, Memory, File Systems' },
  { id:4, subject:'Computer Networks', code:'CS3404', date:'Mar 26', day:26, time:'2:00 PM', hall:'Hall C - Block 1', duration:'3 Hours', daysLeft:13, month:'MAR', syllabus:'Units 1-5: OSI Model, TCP/IP, Routing, Security' },
  { id:5, subject:'Probability & Statistics', code:'MA3451', date:'Mar 30', day:30, time:'10:00 AM', hall:'Hall D - Block 4', duration:'3 Hours', daysLeft:17, month:'MAR', syllabus:'Units 1-5: Probability, Distributions, Hypothesis Testing' },
];

export const TIMETABLE = {
  times:['8:00-9:00','9:00-10:00','10:00-11:00','11:00-12:00','12:00-1:00','2:00-3:00','3:00-4:00'],
  days:['Monday','Tuesday','Wednesday','Thursday','Friday'],
  schedule:[
    [['DS','#6375ff'],['DBMS','#0891b2'],['OS','#d97706'],['BREAK',''],['CN','#059669'],['Prob','#7c3aed'],['Lab','#be123c']],
    [['DBMS','#0891b2'],['DS','#6375ff'],['CN','#059669'],['BREAK',''],['OS','#d97706'],['Prob','#7c3aed'],['DS','#6375ff']],
    [['CN','#059669'],['Prob','#7c3aed'],['DBMS','#0891b2'],['BREAK',''],['DS','#6375ff'],['Lab','#be123c'],['Lab','#be123c']],
    [['OS','#d97706'],['DS','#6375ff'],['Prob','#7c3aed'],['BREAK',''],['DBMS','#0891b2'],['CN','#059669'],['OS','#d97706']],
    [['Prob','#7c3aed'],['OS','#d97706'],['DS','#6375ff'],['BREAK',''],['CN','#059669'],['DBMS','#0891b2'],['Free','']],
  ]
};

export const INTERNSHIPS = [
  { id:1, company:'Google', logo:'G', color:'#4285F4', ctc:'₹80,000/mo', role:'SWE Intern', dept:['CS','IT'], skills:['Python','DSA','System Design'], type:'Paid', mode:'Hybrid', duration:'3 months', location:'Bangalore', deadline:'Apr 15, 2026', resources:['LeetCode','System Design Primer','Cracking the Coding Interview'], desc:'Work with cutting-edge teams on real Google products. Selected interns get pre-placement offers.', rounds:['Online Test (90 min)','Technical Round 1 - DSA','Technical Round 2 - System Design','HR Round'] },
  { id:2, company:'Microsoft', logo:'M', color:'#00A4EF', ctc:'₹75,000/mo', role:'SDE Intern', dept:['CS','IT','ECE'], skills:['C++','OOP','Azure'], type:'Paid', mode:'Online', duration:'2 months', location:'Hyderabad', deadline:'Apr 20, 2026', resources:['HackerRank','MS Learn','Azure Docs'], desc:'Contribute to Microsoft products used by millions worldwide. Great learning experience with senior engineers.', rounds:['Coding Round (3 problems)','Technical Interview 1','Technical Interview 2 - Design','HR Discussion'] },
  { id:3, company:'Amazon', logo:'A', color:'#FF9900', ctc:'₹60,000/mo', role:'SDE Intern', dept:['CS','IT'], skills:['Java','DSA','AWS'], type:'Paid', mode:'Hybrid', duration:'6 months', location:'Chennai', deadline:'May 1, 2026', resources:['LeetCode','Leadership Principles','AWS Docs'], desc:'Amazon SDE internship with chance to work on AWS, Alexa, or Prime. PPO available for top performers.', rounds:['Online Assessment (2 coding)','Technical Loop 1','Technical Loop 2','Bar Raiser Round'] },
  { id:4, company:'Zoho', logo:'Z', color:'#E42527', ctc:'₹20,000/mo', role:'Software Developer Intern', dept:['CS','IT'], skills:['Java','React','SQL'], type:'Paid', mode:'Offline', duration:'6 months', location:'Chennai', deadline:'Apr 10, 2026', resources:['Zoho Campus','HackerEarth'], desc:'Zoho is known for giving full-time roles after internship. Great product-based company exposure.', rounds:['Written Test','Advanced Programming Round','Technical Interview','HR Discussion'] },
  { id:5, company:'ISRO', logo:'I', color:'#FF6600', ctc:'Unpaid', role:'Research Intern', dept:['CS','ECE','EEE'], skills:['C','Embedded Systems','Signal Processing'], type:'Free', mode:'Offline', duration:'2 months', location:'Bangalore', deadline:'Mar 30, 2026', resources:['ISRO Website','Embedded C Tutorials'], desc:'Prestigious government internship. Certificate from ISRO adds great value to resume.', rounds:['Application Screening','Technical Interview','Document Verification'] },
  { id:6, company:'TCS', logo:'T', color:'#0033A0', ctc:'₹12,000/mo', role:'Systems Engineer Intern', dept:['CS','IT','ECE','EEE'], skills:['Java','SQL','Agile'], type:'Paid', mode:'Hybrid', duration:'3 months', location:'Multiple', deadline:'May 15, 2026', resources:['InfyTQ','TCS iON'], desc:'TCS internship with exposure to enterprise software development and Agile methodology.', rounds:['TCS NQT','Technical Interview','HR Round'] },
  { id:7, company:'Infosys', logo:'In', color:'#007CC3', ctc:'₹15,000/mo', role:'Systems Engineer Intern', dept:['CS','IT','ECE'], skills:['Python','Testing','Agile'], type:'Paid', mode:'Hybrid', duration:'3 months', location:'Pune', deadline:'May 5, 2026', resources:['InfyTQ','Coursera'], desc:'Great exposure to large-scale enterprise projects with mentorship from senior engineers.', rounds:['InfyTQ Test','Technical Interview','HR Interview'] },
  { id:8, company:'Wipro', logo:'W', color:'#341C75', ctc:'₹18,000/mo', role:'Project Intern', dept:['CS','IT','ECE','EEE'], skills:['Python','Testing','Cloud'], type:'Paid', mode:'Hybrid', duration:'3 months', location:'Bangalore', deadline:'May 10, 2026', resources:['Wipro TalentNext','Coursera'], desc:'Wipro internship focuses on project delivery and client management exposure.', rounds:['Online Test','Technical Round','HR Round'] },
];

export const COMPANIES = [
  { id:1, name:'TCS', logo:'T', color:'#0033A0', ctc:'₹7 LPA', roles:['System Engineer','Digital Specialist'], dept:['CS','IT','ECE','EEE','MECH'], rounds:[{name:'TCS NQT',type:'test',desc:'Numerical + Verbal + Reasoning + Coding – 3 hours on TCS iON platform. 30 aptitude, 25 verbal, 30 reasoning, 2 coding questions.'},{name:'Technical Interview',type:'tech',desc:'Core CS: OOP, DBMS, OS, CN basics. One coding question. Basic Java/C program may be asked.'},{name:'Managerial Round',type:'mgr',desc:'Situational questions, project experience, team skills, problem-solving approach.'},{name:'HR Round',type:'hr',desc:'Salary negotiation, joining location preference, background verification.'}], skills:['C/Java','Aptitude','DBMS','OS Basics'], commTest:true, visitDate:'Mar 25, 2026', status:'ongoing', batch:'2026', cgpaCutoff:'6.0', backlogPolicy:'No active backlogs' },
  { id:2, name:'Infosys', logo:'In', color:'#007CC3', ctc:'₹6.5 LPA', roles:['Systems Engineer','Digital Specialist'], dept:['CS','IT','ECE','EEE'], rounds:[{name:'InfyTQ Test',type:'test',desc:'Coding (2 problems) + Core CS Fundamentals – 2 hours. Tests basic programming and CS knowledge.'},{name:'Technical Interview',type:'tech',desc:'OOP concepts, DBMS queries, one coding problem, project discussion.'},{name:'HR Interview',type:'hr',desc:'Career goals, relocation, adaptability questions.'}], skills:['Java','Python','DBMS'], commTest:false, visitDate:'Mar 28, 2026', status:'ongoing', batch:'2026', cgpaCutoff:'6.5', backlogPolicy:'No backlogs' },
  { id:3, name:'Google', logo:'G', color:'#4285F4', ctc:'₹45 LPA', roles:['SWE','SRE'], dept:['CS','IT'], rounds:[{name:'Online Assessment',type:'test',desc:'2 DSA problems (Medium-Hard LeetCode level) on HackerRank, 90 minutes.'},{name:'Technical Round 1',type:'tech',desc:'DSA deep dive – 2 problems, discuss time/space complexity, code on shared editor.'},{name:'Technical Round 2',type:'tech',desc:'System Design – Design a scalable system (e.g., URL shortener, chat app).'},{name:'HR Round',type:'hr',desc:'Behavioral: leadership, teamwork, conflict resolution using STAR method.'}], skills:['DSA','System Design','Python/Java'], commTest:false, visitDate:'Apr 10, 2026', status:'upcoming', batch:'2026', cgpaCutoff:'7.5', backlogPolicy:'No backlogs' },
  { id:4, name:'Microsoft', logo:'M', color:'#00A4EF', ctc:'₹40 LPA', roles:['SDE','PM'], dept:['CS','IT','ECE'], rounds:[{name:'Coding Round',type:'test',desc:'3 DSA problems, 1.5 hours on CodePair. Easy + Medium + Hard difficulty.'},{name:'Technical Interview 1',type:'tech',desc:'DSA + OOP + problem solving. May include puzzles and system design basics.'},{name:'Technical Interview 2',type:'tech',desc:'System design, scalability concepts, advanced technical discussion.'},{name:'HR Round',type:'hr',desc:'Culture fit, Microsoft values, career aspirations.'}], skills:['DSA','C++/Java','System Design'], commTest:true, visitDate:'Apr 15, 2026', status:'upcoming', batch:'2026', cgpaCutoff:'7.0', backlogPolicy:'No active backlogs' },
  { id:5, name:'Amazon', logo:'A', color:'#FF9900', ctc:'₹35 LPA', roles:['SDE-1','Data Analyst'], dept:['CS','IT'], rounds:[{name:'Online Assessment',type:'test',desc:'2 coding + work simulation + debugging, 105 minutes. Amazon-specific OA format.'},{name:'Technical Loop 1',type:'tech',desc:'DSA-focused: 1-2 problems, discuss approach, time complexity analysis.'},{name:'Technical Loop 2',type:'tech',desc:'OOP + Design patterns + Leadership Principles discussion.'},{name:'Bar Raiser',type:'hr',desc:'Most important round – Leadership Principles + technical. Tests culture fit deeply.'}], skills:['Java','DSA','Leadership Principles'], commTest:false, visitDate:'Apr 20, 2026', status:'upcoming', batch:'2026', cgpaCutoff:'7.0', backlogPolicy:'No backlogs in last 2 semesters' },
  { id:6, name:'Zoho', logo:'Z', color:'#E42527', ctc:'₹12 LPA', roles:['Software Developer'], dept:['CS','IT'], rounds:[{name:'Written Test',type:'test',desc:'Programming + Aptitude, no calculator allowed. 3 hours, tests fundamental coding skills.'},{name:'Advanced Programming',type:'tech',desc:'Complex coding problems in your preferred language. 3 hours – very rigorous.'},{name:'Technical Interview',type:'tech',desc:'Deep discussion on your projects, code quality, problem solving approach.'},{name:'HR Discussion',type:'hr',desc:'Culture fit, long-term goals, Zoho work culture alignment.'}], skills:['C/Java','Problem Solving','Projects'], commTest:false, visitDate:'May 5, 2026', status:'upcoming', batch:'2026', cgpaCutoff:'6.0', backlogPolicy:'No active backlogs' },
];

export const ROADMAP = {
  CS: [
    { year:1, title:'Foundation Year', emoji:'🌱', color:'#6375ff',
      semesters:[
        { num:1, subjects:['Engineering Maths I','Physics','Programming in C','Engineering Drawing','English Communication'], skills:['C Programming','Basic Logic','Communication'], labs:['Physics Lab','C Programming Lab'], tip:'Master C fundamentals. Attend every lab. Build calculator and simple programs.', certifications:['NPTEL – Python','freeCodeCamp – HTML/CSS'] },
        { num:2, subjects:['Engineering Maths II','Chemistry','Data Structures','Digital Electronics','Environmental Science'], skills:['Data Structures','Digital Logic','Python Basics'], labs:['Chemistry Lab','DSA Lab'], tip:'Start LeetCode Easy problems. Learn Python alongside. Join coding club.', certifications:['NPTEL – Data Structures','HackerRank – Python'] }
      ], clubs:['Coding Club','IEEE Student Branch'], focus:'Academics + Foundation Skills' },
    { year:2, title:'Core Building Year', emoji:'🔨', color:'#0891b2',
      semesters:[
        { num:3, subjects:['Discrete Mathematics','OOP with Java','Computer Organization','Database Management','Statistics'], skills:['Java OOP','SQL & DBMS','Number Theory'], labs:['Java Lab','DBMS Lab'], tip:'Build Java projects. Learn SQL deeply. Start competitive programming.', certifications:['NPTEL – DBMS','Oracle SQL Certified'] },
        { num:4, subjects:['TOC','Computer Networks','Operating Systems','Web Technology','Software Engineering'], skills:['Networking Basics','OS Concepts','React.js'], labs:['Networks Lab','Web Dev Lab'], tip:'Build your first full-stack web app. Learn React. Apply for summer internships.', certifications:['AWS Cloud Practitioner','Meta React Developer'] }
      ], clubs:['Web Dev Club','Open Source Club'], focus:'Development Skills + First Internship' },
    { year:3, title:'Specialization Year', emoji:'⚡', color:'#d97706',
      semesters:[
        { num:5, subjects:['Compiler Design','Artificial Intelligence','Cloud Computing','Mobile Applications','Cryptography'], skills:['AI/ML Basics','Cloud (AWS/GCP)','Mobile Dev'], labs:['AI Lab','Mobile Dev Lab'], tip:'Do a summer internship. Build 3+ projects. Start DSA preparation for placements.', certifications:['AWS Solutions Architect','Google ML Crash Course'] },
        { num:6, subjects:['Machine Learning','Big Data Analytics','IoT','Distributed Systems','Mini Project'], skills:['ML Algorithms','Data Analysis','Project Management'], labs:['ML Lab','Big Data Lab'], tip:'Apply for core company internships. Contribute to open source. Build strong GitHub.', certifications:['IBM Data Science','Google Data Analytics'] }
      ], clubs:['AI/ML Club','Hackathon Squad'], focus:'Internships + Project Portfolio' },
    { year:4, title:'Placement Year', emoji:'🚀', color:'#059669',
      semesters:[
        { num:7, subjects:['Information Security','Cloud Architecture','Advanced Algorithms','Elective I','Project Phase I'], skills:['System Design','Security','Leadership'], labs:['Security Lab','Project Lab'], tip:'Focus 100% on placement prep. Practice mock interviews daily. Attend all campus drives.', certifications:['Google Cloud Professional','Microsoft Azure','CISSP Basics'] },
        { num:8, subjects:['Elective II','Elective III','Project Phase II','Industrial Training'], skills:['Full Stack','DevOps','Communication'], labs:['Project Lab','Training'], tip:'Complete your final project. Network actively. Get your offer letter. Prepare for first job.', certifications:['Meta Frontend Developer','AWS DevOps'] }
      ], clubs:['E-Cell','Placement Prep Group'], focus:'Placements + Final Project' }
  ]
};

export const NPTEL_COURSES = [
  { id:1, title:'Data Structures and Algorithms', instructor:'Prof. Naveen Garg', inst:'IIT Delhi', weeks:12, credits:3, category:'cs', difficulty:'Intermediate', enrolled:true, progress:65, startDate:'Jan 2026', endDate:'Apr 2026', cert:'Elite+Gold', desc:'Complete coverage of DSA: arrays, linked lists, trees, graphs, algorithm design using divide & conquer and dynamic programming.', tags:['DSA','IIT Delhi','Core CS'], rating:4.8, enrolled_count:'45,231' },
  { id:2, title:'Database Management Systems', instructor:'Prof. D. Janakiram', inst:'IIT Madras', weeks:12, credits:3, category:'cs', difficulty:'Intermediate', enrolled:true, progress:30, startDate:'Jan 2026', endDate:'Apr 2026', cert:'Elite', desc:'Complete DBMS: ER modeling, relational algebra, SQL, normalization, transactions, concurrency control and recovery.', tags:['DBMS','SQL','IIT Madras'], rating:4.7, enrolled_count:'38,421' },
  { id:3, title:'Operating Systems', instructor:'Prof. Chester Rebeiro', inst:'IIT Madras', weeks:8, credits:2, category:'cs', difficulty:'Advanced', enrolled:false, progress:0, startDate:'Feb 2026', endDate:'Apr 2026', cert:'Elite+Gold', desc:'Process management, memory management, file systems, I/O management, and OS security with real Linux examples.', tags:['OS','Linux','IIT Madras'], rating:4.9, enrolled_count:'52,100' },
  { id:4, title:'Computer Networks', instructor:'Prof. S. Ghosh', inst:'IIT Kharagpur', weeks:12, credits:3, category:'cs', difficulty:'Intermediate', enrolled:false, progress:0, startDate:'Jan 2026', endDate:'Apr 2026', cert:'Elite', desc:'OSI model, TCP/IP stack, routing algorithms, transport layer, application protocols and network security.', tags:['Networks','TCP/IP','IIT KGP'], rating:4.6, enrolled_count:'29,876' },
  { id:5, title:'Machine Learning', instructor:'Prof. Balaram Ravindran', inst:'IIT Madras', weeks:12, credits:3, category:'ai', difficulty:'Advanced', enrolled:false, progress:0, startDate:'Jan 2026', endDate:'Apr 2026', cert:'Elite+Gold', desc:'Supervised, unsupervised and reinforcement learning with mathematical foundations and Python implementation.', tags:['ML','Python','AI'], rating:4.9, enrolled_count:'78,543' },
  { id:6, title:'Deep Learning', instructor:'Prof. Mitesh Khapra', inst:'IIT Madras', weeks:8, credits:2, category:'ai', difficulty:'Expert', enrolled:false, progress:0, startDate:'Feb 2026', endDate:'Apr 2026', cert:'Elite+Gold', desc:'Neural networks, CNNs, RNNs, transformers and real-world DL applications with PyTorch.', tags:['DL','PyTorch','Transformers'], rating:4.9, enrolled_count:'61,234' },
  { id:7, title:'Joy of Computing using Python', instructor:'Prof. Sudarshan Iyengar', inst:'IIT Ropar', weeks:12, credits:3, category:'programming', difficulty:'Beginner', enrolled:false, progress:0, startDate:'Jan 2026', endDate:'Apr 2026', cert:'Elite', desc:'Fun Python intro with games, data, art. Perfect for absolute beginners. Most popular NPTEL course.', tags:['Python','Beginner','Fun'], rating:4.8, enrolled_count:'1,23,456' },
  { id:8, title:'Cloud Computing', instructor:'Prof. S.K. Ghosh', inst:'IIT Kharagpur', weeks:8, credits:2, category:'cloud', difficulty:'Intermediate', enrolled:false, progress:0, startDate:'Feb 2026', endDate:'Apr 2026', cert:'Elite+Gold', desc:'Cloud service models, AWS/Azure/GCP overview, containerization with Docker and Kubernetes.', tags:['Cloud','AWS','Docker'], rating:4.5, enrolled_count:'34,567' },
  { id:9, title:'Ethical Hacking', instructor:'Prof. Indranil Sengupta', inst:'IIT Kharagpur', weeks:12, credits:3, category:'security', difficulty:'Advanced', enrolled:false, progress:0, startDate:'Jan 2026', endDate:'Apr 2026', cert:'Elite+Gold', desc:'Penetration testing, network security, web security, cryptography and ethical hacking methodologies.', tags:['Security','Hacking','Cryptography'], rating:4.7, enrolled_count:'41,089' },
];

export const QUIZ_DATA = [
  { id:1, title:'Sorting Algorithms', subject:'Data Structures', cat:'ds', icon:'🔀', difficulty:'Medium', time:15, color:'#6375ff',
    questions:[
      { q:'What is the time complexity of Merge Sort in all cases?', opts:['O(n)','O(n²)','O(n log n)','O(log n)'], ans:2, explanation:'Merge Sort always divides array in half and merges, giving O(n log n) in all cases.' },
      { q:'Which sorting algorithm is best for nearly sorted data?', opts:['Quick Sort','Merge Sort','Insertion Sort','Heap Sort'], ans:2, explanation:'Insertion Sort runs in O(n) for nearly sorted data since few swaps are needed.' },
      { q:'Quick Sort worst-case time complexity:', opts:['O(n log n)','O(n²)','O(n)','O(log n)'], ans:1, explanation:'Worst case occurs when pivot is always smallest/largest element, causing n² comparisons.' },
      { q:'Which sorting algorithm is NOT in-place?', opts:['Quick Sort','Insertion Sort','Merge Sort','Heap Sort'], ans:2, explanation:'Merge Sort requires O(n) extra space for the auxiliary array used during merging.' },
      { q:'Best case time complexity of Bubble Sort:', opts:['O(n²)','O(n log n)','O(n)','O(1)'], ans:2, explanation:'With early termination optimization, Bubble Sort runs O(n) on already sorted arrays.' },
      { q:'Which algorithm uses divide and conquer AND is not stable?', opts:['Merge Sort','Insertion Sort','Quick Sort','Counting Sort'], ans:2, explanation:'Quick Sort uses divide and conquer but is not stable – equal elements may swap positions.' },
      { q:'Radix Sort time complexity for n numbers with d digits:', opts:['O(nd)','O(n log n)','O(n²)','O(d log n)'], ans:0, explanation:'Radix Sort runs in O(nd) – linear for each digit, d passes total.' },
    ]
  },
  { id:2, title:'Trees & Graphs', subject:'Data Structures', cat:'ds', icon:'🌳', difficulty:'Hard', time:20, color:'#6375ff',
    questions:[
      { q:'Height of a complete binary tree with n nodes:', opts:['O(n)','O(log n)','O(n²)','O(1)'], ans:1, explanation:'A complete binary tree has height floor(log₂n), growing logarithmically.' },
      { q:'Which traversal gives sorted order in BST?', opts:['Preorder','Postorder','Inorder','Level order'], ans:2, explanation:'Inorder traversal (Left → Root → Right) of a BST always produces sorted output.' },
      { q:'BFS uses which data structure?', opts:['Stack','Queue','Heap','Priority Queue'], ans:1, explanation:'BFS explores nodes level by level using a Queue (FIFO) data structure.' },
      { q:"Dijkstra's algorithm cannot handle:", opts:['Directed graphs','Negative weight edges','Disconnected graphs','Weighted graphs'], ans:1, explanation:"Dijkstra's fails with negative edges as it assumes adding edges only increases path cost." },
      { q:'A graph with V vertices and V-1 edges with no cycle is a:', opts:['Complete graph','Bipartite graph','Tree','DAG'], ans:2, explanation:'A connected graph with V vertices and V-1 edges without cycles is always a tree.' },
      { q:'AVL tree maintains balance by keeping height difference at most:', opts:['0','1','2','3'], ans:1, explanation:'AVL tree ensures |height(left) - height(right)| ≤ 1 for every node.' },
    ]
  },
  { id:3, title:'SQL & Normalization', subject:'DBMS', cat:'dbms', icon:'🗃️', difficulty:'Medium', time:15, color:'#0891b2',
    questions:[
      { q:'Which normal form eliminates multi-valued dependencies?', opts:['1NF','2NF','3NF','4NF'], ans:3, explanation:'4NF eliminates multi-valued dependencies that exist beyond the key dependencies.' },
      { q:'INNER JOIN returns:', opts:['All rows from left','All rows from both','Only matching rows','Rows with NULL'], ans:2, explanation:'INNER JOIN returns only rows where the join condition is satisfied in both tables.' },
      { q:'ACID property ensuring partial transactions are rolled back:', opts:['Consistency','Isolation','Durability','Atomicity'], ans:3, explanation:'Atomicity ensures transactions are all-or-nothing – partial failures are rolled back.' },
      { q:'Which SQL command removes a table structure permanently?', opts:['DELETE','TRUNCATE','DROP','REMOVE'], ans:2, explanation:'DROP removes the entire table structure and data. Cannot be rolled back.' },
      { q:'Second Normal Form requires:', opts:['No transitive dependencies','No partial dependencies','No multi-valued','All attributes atomic'], ans:1, explanation:'2NF requires 1NF + no partial dependencies (non-key attributes fully dependent on PK).' },
      { q:'Which JOIN returns all rows from left table even without match?', opts:['INNER JOIN','RIGHT JOIN','LEFT JOIN','FULL JOIN'], ans:2, explanation:'LEFT JOIN returns all rows from left table; NULLs for unmatched right table columns.' },
    ]
  },
  { id:4, title:'Process Management', subject:'Operating Systems', cat:'os', icon:'⚙️', difficulty:'Medium', time:15, color:'#d97706',
    questions:[
      { q:'Which scheduling algorithm may cause starvation?', opts:['FCFS','Round Robin','SJF/Priority','Multilevel Queue'], ans:2, explanation:'SJF and Priority scheduling can starve long/low-priority processes indefinitely.' },
      { q:'Deadlock requires how many conditions simultaneously?', opts:['2','3','4','5'], ans:2, explanation:'4 Coffman conditions: Mutual Exclusion, Hold & Wait, No Preemption, Circular Wait.' },
      { q:"Banker's Algorithm is used for:", opts:['Memory allocation','Deadlock avoidance','CPU scheduling','File management'], ans:1, explanation:"Banker's Algorithm is a deadlock avoidance algorithm that checks safe state before allocation." },
      { q:'Context switch overhead is a problem because:', opts:['It increases throughput','No useful work is done during it','It prevents deadlock','It increases CPU speed'], ans:1, explanation:'During context switch, CPU saves/restores state – no useful computation happens.' },
      { q:'Which is NOT a valid process state?', opts:['Running','Waiting','Suspended','Floating'], ans:3, explanation:'Valid states: New, Ready, Running, Waiting, Terminated. "Floating" is not a state.' },
      { q:'Semaphore is used to solve:', opts:['Deadlock','Race conditions/synchronization','Memory leaks','Thrashing'], ans:1, explanation:'Semaphores are synchronization primitives used to prevent race conditions.' },
    ]
  },
  { id:5, title:'TCP/IP & Networking', subject:'Computer Networks', cat:'cn', icon:'🌐', difficulty:'Easy', time:12, color:'#059669',
    questions:[
      { q:'TCP three-way handshake sequence:', opts:['SYN, ACK, FIN','SYN, SYN-ACK, ACK','ACK, NAK, SYN','OPEN, SYNC, ACK'], ans:1, explanation:'TCP connection: Client sends SYN → Server replies SYN-ACK → Client sends ACK.' },
      { q:'Which layer does IP operate at in OSI model?', opts:['Application','Transport','Network','Data Link'], ans:2, explanation:'IP (Internet Protocol) operates at Layer 3 – Network layer of the OSI model.' },
      { q:'UDP differs from TCP because it is:', opts:['Connection-oriented','Reliable','Connectionless','Slower'], ans:2, explanation:'UDP is connectionless – no handshake, no reliability, but much faster than TCP.' },
      { q:'DNS primarily uses which port?', opts:['80','443','53','21'], ans:2, explanation:'DNS (Domain Name System) uses port 53 for both UDP (queries) and TCP (zone transfers).' },
      { q:'Which protocol is used to assign IP addresses automatically?', opts:['DNS','ARP','DHCP','ICMP'], ans:2, explanation:'DHCP (Dynamic Host Configuration Protocol) automatically assigns IP addresses to devices.' },
    ]
  },
];

export const EVENTS = [
  { id:1, title:'Anna University Hackathon 2026', date:'Mar 20-21, 2026', time:'9:00 AM', venue:'Main Auditorium', type:'Hackathon', dept:'All', prize:'₹1,00,000', teamSize:'2-4', desc:'36-hour hackathon. Build innovative solutions for smart cities, healthcare or education. Top teams get cash prizes and PPO offers from sponsors.', deadline:'Mar 15, 2026', registered:false },
  { id:2, title:'National Level Paper Presentation', date:'Mar 25, 2026', time:'10:00 AM', venue:'Seminar Hall - Block 3', type:'Technical', dept:'All', prize:'₹25,000', teamSize:'1-2', desc:'Present research papers on AI, ML, IoT, Blockchain, Cybersecurity. Best papers get published in college journal.', deadline:'Mar 18, 2026', registered:false },
  { id:3, title:'TCS Campus Connect Drive', date:'Mar 28, 2026', time:'8:00 AM', venue:'Placement Cell', type:'Placement', dept:'CS,IT,ECE,EEE,MECH', prize:'₹7 LPA', teamSize:'Individual', desc:'TCS mass recruitment drive for 2026 batch. Written test + Technical + HR. Carry resume, photo ID and all mark sheets.', deadline:'Mar 22, 2026', registered:true },
  { id:4, title:'Technical Symposium – Technovate 2026', date:'Apr 5, 2026', time:'9:00 AM', venue:'College Ground', type:'Symposium', dept:'All', prize:'₹50,000 total', teamSize:'1-4', desc:'Annual technical symposium with 15+ events: coding contest, robotics, web design, quiz, debugging challenge and more.', deadline:'Apr 1, 2026', registered:false },
  { id:5, title:'Guest Lecture – AI in Industry', date:'Mar 22, 2026', time:'2:00 PM', venue:'Seminar Hall - Block 1', type:'Workshop', dept:'CS,IT', prize:'Certificate', teamSize:'Individual', desc:'Industry expert from Google shares insights on how AI is transforming industries. Q&A session included. Certificate provided to all attendees.', deadline:'Mar 20, 2026', registered:true },
  { id:6, title:'Coding Workshop – DSA Masterclass', date:'Apr 10-12, 2026', time:'9:00 AM', venue:'CS Department Lab', type:'Workshop', dept:'CS,IT', prize:'Certificate + Goodies', teamSize:'Individual', desc:'3-day intensive DSA workshop by placement toppers. Covers arrays to graphs with LeetCode problems. Placement-focused curriculum.', deadline:'Apr 5, 2026', registered:false },
];
