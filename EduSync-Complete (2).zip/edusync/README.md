# 🎓 EduSync — Academic Portal

> A complete Learning Management System built with React.js for students and educators.

![EduSync](https://img.shields.io/badge/EduSync-v3.0-6375ff?style=for-the-badge)
![React](https://img.shields.io/badge/React-18.2.0-61DAFB?style=for-the-badge&logo=react)
![Node.js](https://img.shields.io/badge/Node.js-18.x-339933?style=for-the-badge&logo=node.js)
![MongoDB](https://img.shields.io/badge/MongoDB-8.0-47A248?style=for-the-badge&logo=mongodb)

---

## ✨ Features

| Feature | Description |
|---------|-------------|
| 💼 **Internships** | Filter by dept, mode, paid/free with resources |
| 🏢 **Upcoming Companies** | Interview rounds, skills, communication test info |
| 🗺️ **Career Roadmap** | Year 1–4 guide, department based |
| 🎓 **NPTEL Courses** | IIT certified courses with progress tracking |
| 🔨 **Timetable Builder** | Click-to-place custom schedule builder |
| 🛡️ **Admin Panel** | Post announcements, manage all sections |
| 📝 **Assignments** | Track deadlines and submission status |
| 🧩 **Quiz Practice** | DS, DBMS, OS questions with explanations |
| ▶️ **Video Courses** | Embedded YouTube lectures |
| 🤖 **AI Study Bot** | Smart chatbot for academic queries |
| 📊 **GPA Calculator** | Simulate grades and predict CGPA |
| 📅 **Exam Calendar** | Interactive calendar with hall details |

---

## 🚀 Quick Start

### Frontend
```bash
cd edusync
npm install
npm start
```
Opens at → http://localhost:3000

### Backend
```bash
cd edusync-backend
npm install
node seed.js
npm run dev
```
Runs at → http://localhost:5000

---

## 🔑 Demo Login

| Role | Email | Password |
|------|-------|----------|
| 🛡️ Admin | akshayadarshini.n@gmail.com | aksh@2006 |
| 👤 Student | harivignesh@gmail.com | hari@1111 |

---

## 🏗️ Tech Stack

**Frontend**
- React.js 18
- Custom CSS (Dark Theme)
- Google Fonts (Syne + DM Sans)
- Fully Mobile Responsive

**Backend**
- Node.js + Express.js
- MongoDB + Mongoose
- JWT Authentication
- bcryptjs Password Hashing

---

## 📁 Project Structure

```
edusync/                    ← Frontend
  src/
    pages/                  ← 18 page components
    components/             ← Layout, Navbar
    data/                   ← App data
    App.js
    index.css

edusync-backend/            ← Backend
  models/                   ← MongoDB schemas
  routes/                   ← API endpoints
  middleware/               ← JWT auth
  server.js
  seed.js
```

---

## 👩‍💻 Built By

**Akshaya Darshini** — Semester 5, Computer Science
Hackathon Project 2026
