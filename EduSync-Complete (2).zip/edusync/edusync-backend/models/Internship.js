const mongoose = require('mongoose');

const internshipSchema = new mongoose.Schema({
  company:   { type: String, required: true },
  logo:      { type: String },
  color:     { type: String, default: '#6375ff' },
  ctc:       { type: String, required: true },
  role:      { type: String, required: true },
  dept:      [{ type: String }],
  skills:    [{ type: String }],
  type:      { type: String, enum: ['Paid','Free'], default: 'Paid' },
  mode:      { type: String, enum: ['Online','Offline','Hybrid'], default: 'Hybrid' },
  duration:  { type: String },
  location:  { type: String },
  deadline:  { type: String },
  resources: [{ type: String }],
  desc:      { type: String },
  rounds:    [{ type: String }],
  isActive:  { type: Boolean, default: true },
}, { timestamps: true });

module.exports = mongoose.model('Internship', internshipSchema);
