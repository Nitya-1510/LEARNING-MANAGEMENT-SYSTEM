const mongoose = require('mongoose');

const subjectSchema = new mongoose.Schema({
  name:       { type: String, required: true },
  code:       { type: String, required: true },
  dept:       { type: String, required: true },  // CS, IT, ECE, EEE, MECH
  sem:        { type: Number, required: true },   // 1-8
  credits:    { type: Number, default: 4 },
  type:       { type: String, enum: ['Theory','Lab','Elective'], default: 'Theory' },
  syllabus:   [{ type: String }],                 // list of units/topics
  faculty:    { type: String, default: '' },
  color:      { type: String, default: '#6375ff' },
}, { timestamps: true });

module.exports = mongoose.model('Subject', subjectSchema);
