const mongoose = require('mongoose');

const announcementSchema = new mongoose.Schema({
  title:    { type: String, required: true },
  msg:      { type: String, required: true },
  type:     { type: String, default: 'General' },
  priority: { type: String, enum: ['High','Medium','Low'], default: 'Medium' },
  postedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
}, { timestamps: true });

module.exports = mongoose.model('Announcement', announcementSchema);
