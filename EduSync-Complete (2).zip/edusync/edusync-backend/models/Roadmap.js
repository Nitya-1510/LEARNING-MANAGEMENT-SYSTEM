const mongoose = require('mongoose');

const semesterSchema = new mongoose.Schema({
  num:      { type: Number, required: true },
  subjects: [{ type: String }],
  skills:   [{ type: String }],
  labs:     [{ type: String }],
  certifications: [{ type: String }],
  tip:      { type: String, default: '' },
});

const yearSchema = new mongoose.Schema({
  year:      { type: Number, required: true },
  title:     { type: String, required: true },
  emoji:     { type: String, default: '🎓' },
  color:     { type: String, default: '#6375ff' },
  focus:     { type: String, default: '' },
  semesters: [semesterSchema],
  clubs:     [{ type: String }],
});

const roadmapSchema = new mongoose.Schema({
  dept:    { type: String, required: true, unique: true },
  years:   [yearSchema],
  isActive:{ type: Boolean, default: true },
}, { timestamps: true });

module.exports = mongoose.model('Roadmap', roadmapSchema);
