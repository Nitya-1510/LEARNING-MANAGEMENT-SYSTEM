const mongoose = require('mongoose');

const departmentSchema = new mongoose.Schema({
  name:      { type: String, required: true, unique: true },
  code:      { type: String, required: true, unique: true },
  shortName: { type: String, required: true },
  hod:       { type: String, default: '' },
  totalStudents: { type: Number, default: 0 },
  color:     { type: String, default: '#6375ff' },
  icon:      { type: String, default: '🎓' },
  semesters: { type: Number, default: 8 },
  isActive:  { type: Boolean, default: true },
}, { timestamps: true });

module.exports = mongoose.model('Department', departmentSchema);
