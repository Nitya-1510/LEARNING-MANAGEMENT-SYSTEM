const mongoose = require('mongoose');
const bcrypt   = require('bcryptjs');

const userSchema = new mongoose.Schema({
  name:     { type: String, required: true, trim: true },
  email:    { type: String, required: true, unique: true, lowercase: true },
  password: { type: String, required: true, minlength: 6 },
  role:     { type: String, enum: ['student','admin'], default: 'student' },

  // Academic Info — NO strict enum, accepts any department
  dept:     { type: String, default: 'Computer Science & Engineering' },
  deptCode: { type: String, default: 'CSE' },
  sem:      { type: Number, min:1, max:8, default: 5 },
  section:  { type: String, default: 'A' },
  reg:      { type: String, sparse: true },
  cgpa:     { type: Number, default: 0.0 },
  phone:    { type: String, default: '' },
  avatar:   { type: String, default: '' },

  // Tracking
  enrolledNPTEL:    [{ type: String }],
  appliedInterns:   [{ type: String }],
  registeredDrives: [{ type: String }],

}, { timestamps: true });

// Hash password before saving
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

// Compare password
userSchema.methods.matchPassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

module.exports = mongoose.model('User', userSchema);
