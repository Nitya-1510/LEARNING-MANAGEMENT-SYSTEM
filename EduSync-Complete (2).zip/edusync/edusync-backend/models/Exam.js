const mongoose = require('mongoose');

const examSchema = new mongoose.Schema({
  subject:  { type: String, required: true },
  code:     { type: String, required: true },
  dept:     { type: String, default: 'CSE' },
  date:     { type: String, required: true },
  time:     { type: String, default: '10:00 AM' },
  hall:     { type: String, default: '' },
  duration: { type: String, default: '3 Hours' },
  daysLeft: { type: Number, default: 0 },
  color:    { type: String, default: '#6375ff' },
  syllabus: { type: String, default: '' },
}, { timestamps: true });

module.exports = mongoose.model('Exam', examSchema);
