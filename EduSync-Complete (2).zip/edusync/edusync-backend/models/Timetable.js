const mongoose = require('mongoose');

const slotSchema = new mongoose.Schema({
  day:     { type: String, required: true },  // Monday-Friday
  time:    { type: String, required: true },  // 8:00-9:00
  subject: { type: String, default: '' },
  code:    { type: String, default: '' },
  faculty: { type: String, default: '' },
  room:    { type: String, default: '' },
  color:   { type: String, default: '#6375ff' },
  isBreak: { type: Boolean, default: false },
});

const timetableSchema = new mongoose.Schema({
  dept:    { type: String, required: true },
  sem:     { type: Number, required: true },
  section: { type: String, default: 'A' },
  slots:   [slotSchema],
  isActive:{ type: Boolean, default: true },
}, { timestamps: true });

module.exports = mongoose.model('Timetable', timetableSchema);
