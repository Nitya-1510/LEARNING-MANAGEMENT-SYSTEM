const mongoose = require('mongoose');

const assignmentSchema = new mongoose.Schema({
  title:     { type: String, required: true },
  subject:   { type: String, required: true },
  code:      { type: String, required: true },
  dept:      { type: String, default: 'CSE' },
  due:       { type: String, required: true },
  daysLeft:  { type: Number, default: 0 },
  maxMarks:  { type: Number, default: 25 },
  status:    { type: String, enum: ['pending','submitted','overdue'], default: 'pending' },
  progress:  { type: Number, default: 0 },
  questions: [{ type: String }],
  postedBy:  { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
}, { timestamps: true });

module.exports = mongoose.model('Assignment', assignmentSchema);
