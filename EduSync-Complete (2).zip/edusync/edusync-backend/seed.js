// ============================================
//  EduSync Complete Database Seeder
//  Run once: node seed.js
// ============================================
const mongoose = require('mongoose');
const dotenv   = require('dotenv');
dotenv.config();

const User         = require('./models/User');
const Department   = require('./models/Department');
const Subject      = require('./models/Subject');
const Timetable    = require('./models/Timetable');
const Roadmap      = require('./models/Roadmap');
const Assignment   = require('./models/Assignment');
const Internship   = require('./models/Internship');
const Exam         = require('./models/Exam');
const Announcement = require('./models/Announcement');

const seed = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('\n✅ Connected to MongoDB:', mongoose.connection.name);

    // Clear all
    await Promise.all([
      User.deleteMany(), Department.deleteMany(), Subject.deleteMany(),
      Timetable.deleteMany(), Roadmap.deleteMany(), Assignment.deleteMany(),
      Internship.deleteMany(), Exam.deleteMany(), Announcement.deleteMany()
    ]);
    console.log('🗑️  Cleared old data\n');

    // ── 1. DEPARTMENTS ─────────────────────
    await Department.create([
      // Engineering
      { name:'Computer Science & Engineering',          code:'CSE',   shortName:'CSE',   color:'#6375ff', icon:'💻', hod:'Dr. R. Kavitha',   totalStudents:240, category:'Engineering'  },
      { name:'Information Technology',                  code:'IT',    shortName:'IT',    color:'#0891b2', icon:'🌐', hod:'Dr. S. Priya',     totalStudents:180, category:'Engineering'  },
      { name:'Electronics & Communication Engineering', code:'ECE',   shortName:'ECE',   color:'#d97706', icon:'📡', hod:'Dr. P. Ramesh',    totalStudents:200, category:'Engineering'  },
      { name:'Electrical & Electronics Engineering',    code:'EEE',   shortName:'EEE',   color:'#059669', icon:'⚡', hod:'Dr. K. Murugan',   totalStudents:160, category:'Engineering'  },
      { name:'Mechanical Engineering',                  code:'MECH',  shortName:'MECH',  color:'#be123c', icon:'⚙️', hod:'Dr. V. Suresh',    totalStudents:220, category:'Engineering'  },
      { name:'Civil Engineering',                       code:'CIVIL', shortName:'CIVIL', color:'#92400e', icon:'🏗️', hod:'Dr. T. Anand',     totalStudents:160, category:'Engineering'  },
      { name:'Chemical Engineering',                    code:'CHEM',  shortName:'CHEM',  color:'#065f46', icon:'🧪', hod:'Dr. M. Lakshmi',   totalStudents:120, category:'Engineering'  },
      { name:'Aerospace Engineering',                   code:'AERO',  shortName:'AERO',  color:'#1e3a8a', icon:'✈️', hod:'Dr. N. Karthik',   totalStudents:100, category:'Engineering'  },
      // Specialised
      { name:'VLSI Design',                             code:'VLSI',  shortName:'VLSI',  color:'#7c3aed', icon:'🔬', hod:'Dr. A. Senthil',   totalStudents:60,  category:'Specialised'  },
      { name:'Artificial Intelligence & ML',            code:'AIML',  shortName:'AIML',  color:'#db2777', icon:'🤖', hod:'Dr. B. Divya',     totalStudents:120, category:'Specialised'  },
      { name:'Cyber Security',                          code:'CYS',   shortName:'CyS',   color:'#dc2626', icon:'🔐', hod:'Dr. C. Vijay',     totalStudents:80,  category:'Specialised'  },
      { name:'Internet of Things',                      code:'IOT',   shortName:'IoT',   color:'#0284c7', icon:'📶', hod:'Dr. D. Meena',     totalStudents:60,  category:'Specialised'  },
      { name:'Robotics & Automation',                   code:'ROB',   shortName:'ROB',   color:'#ea580c', icon:'🦾', hod:'Dr. E. Suresh',    totalStudents:60,  category:'Specialised'  },
      { name:'Data Science',                            code:'DSC',   shortName:'DS',    color:'#0891b2', icon:'📊', hod:'Dr. F. Nisha',     totalStudents:100, category:'Specialised'  },
      // Science
      { name:'Biotechnology',                           code:'BIO',   shortName:'BIO',   color:'#16a34a', icon:'🧬', hod:'Dr. G. Preethi',   totalStudents:80,  category:'Science'      },
      { name:'Biomedical Engineering',                  code:'BME',   shortName:'BME',   color:'#0d9488', icon:'🏥', hod:'Dr. H. Saranya',   totalStudents:60,  category:'Science'      },
      { name:'Physics',                                 code:'PHY',   shortName:'PHY',   color:'#4338ca', icon:'⚛️', hod:'Dr. I. Ramesh',    totalStudents:60,  category:'Science'      },
      { name:'Mathematics',                             code:'MATH',  shortName:'MATH',  color:'#0369a1', icon:'📐', hod:'Dr. J. Kavya',     totalStudents:60,  category:'Science'      },
      // Management
      { name:'Master of Business Administration',       code:'MBA',   shortName:'MBA',   color:'#b45309', icon:'📈', hod:'Dr. K. Arjun',     totalStudents:120, category:'Management'   },
      { name:'Master of Computer Applications',        code:'MCA',   shortName:'MCA',   color:'#6d28d9', icon:'🖥️', hod:'Dr. L. Rekha',     totalStudents:60,  category:'Management'   },
    ]);
    console.log('🏛️  Departments created: 20');

    // ── 2. SUBJECTS ────────────────────────
    await Subject.create([
      // CSE Sem 5
      {name:'Data Structures & Algorithms',code:'CS3401',dept:'CSE', sem:5,credits:4,type:'Theory',color:'#6375ff',faculty:'Prof. A. Kumar',   syllabus:['Arrays & Linked Lists','Stack & Queue','Trees & BST','Graphs BFS/DFS','Sorting Algorithms']},
      {name:'Database Management Systems', code:'CS3402',dept:'CSE', sem:5,credits:3,type:'Theory',color:'#0891b2',faculty:'Prof. B. Priya',   syllabus:['ER Model','SQL & Relational Algebra','Normalization','Transactions','Indexing & B+ Trees']},
      {name:'Operating Systems',           code:'CS3403',dept:'CSE', sem:5,credits:4,type:'Theory',color:'#d97706',faculty:'Prof. C. Raj',     syllabus:['Process Management','CPU Scheduling','Memory Management','File Systems','Deadlock']},
      {name:'Computer Networks',           code:'CS3404',dept:'CSE', sem:5,credits:3,type:'Theory',color:'#059669',faculty:'Prof. D. Meena',   syllabus:['OSI & TCP/IP','Data Link Layer','Network Layer','Transport Layer','Application Layer']},
      {name:'Probability & Statistics',    code:'MA3451',dept:'CSE', sem:5,credits:4,type:'Theory',color:'#7c3aed',faculty:'Prof. E. Sathya',  syllabus:['Probability Theory','Random Variables','Sampling','Hypothesis Testing','Regression']},
      {name:'DS & Algorithms Lab',         code:'CS3411',dept:'CSE', sem:5,credits:2,type:'Lab',   color:'#be123c',faculty:'Prof. A. Kumar',   syllabus:['Stack & Queue','BST Operations','Graph Algorithms','Sorting','Hashing']},
      // IT Sem 5
      {name:'Web Technology',              code:'IT3401',dept:'IT',  sem:5,credits:4,type:'Theory',color:'#6375ff',faculty:'Prof. F. Nisha',   syllabus:['HTML5 & CSS3','JavaScript ES6','React.js','Node.js','REST APIs']},
      {name:'Software Engineering',        code:'IT3402',dept:'IT',  sem:5,credits:3,type:'Theory',color:'#0891b2',faculty:'Prof. G. Senthil', syllabus:['SDLC Models','Agile & Scrum','Requirements','Software Testing','Project Management']},
      {name:'Database Management',         code:'IT3403',dept:'IT',  sem:5,credits:3,type:'Theory',color:'#d97706',faculty:'Prof. H. Radha',   syllabus:['Relational Design','Advanced SQL','NoSQL','Database Security','Cloud DB']},
      {name:'Computer Networks',           code:'IT3404',dept:'IT',  sem:5,credits:4,type:'Theory',color:'#059669',faculty:'Prof. I. Vijay',   syllabus:['Network Protocols','TCP/IP','Network Security','Wireless','Cloud Networking']},
      {name:'Probability & Queueing',      code:'MA3452',dept:'IT',  sem:5,credits:4,type:'Theory',color:'#7c3aed',faculty:'Prof. J. Rekha',   syllabus:['Probability Distributions','Stochastic Processes','Queueing Models','Simulation','SQC']},
      {name:'Web Technology Lab',          code:'IT3411',dept:'IT',  sem:5,credits:2,type:'Lab',   color:'#be123c',faculty:'Prof. F. Nisha',   syllabus:['HTML/CSS Projects','JavaScript DOM','React','REST API','Full Stack Project']},
      // ECE Sem 5
      {name:'Digital Signal Processing',   code:'EC3501',dept:'ECE', sem:5,credits:4,type:'Theory',color:'#6375ff',faculty:'Prof. K. Arjun',   syllabus:['DT Signals','Z-Transform & DFT','FIR Filter','IIR Filter','FFT Algorithms']},
      {name:'Microprocessors & Controllers',code:'EC3502',dept:'ECE',sem:5,credits:3,type:'Theory',color:'#0891b2',faculty:'Prof. L. Divya',   syllabus:['8086 Architecture','Assembly Language','Memory Interfacing','I/O Interfacing','ARM Cortex']},
      {name:'Electromagnetic Fields',      code:'EC3503',dept:'ECE', sem:5,credits:4,type:'Theory',color:'#d97706',faculty:'Prof. M. Krishna',  syllabus:['Vector Calculus','Electrostatics','Magnetostatics','EM Waves','Transmission Lines']},
      {name:'Communication Theory',        code:'EC3504',dept:'ECE', sem:5,credits:3,type:'Theory',color:'#059669',faculty:'Prof. N. Lakshmi',  syllabus:['AM & FM Modulation','Digital Modulation','Noise Analysis','Information Theory','Error Correction']},
      {name:'VLSI Design',                 code:'EC3505',dept:'ECE', sem:5,credits:4,type:'Theory',color:'#7c3aed',faculty:'Prof. O. Ganesh',   syllabus:['MOS Technology','CMOS Logic','Combinational Circuits','Sequential Circuits','Layout Rules']},
      {name:'DSP Lab',                     code:'EC3511',dept:'ECE', sem:5,credits:2,type:'Lab',   color:'#be123c',faculty:'Prof. K. Arjun',   syllabus:['MATLAB Signal Processing','FIR Filter','FFT','Audio Processing','Real-time DSP']},
      // EEE Sem 5
      {name:'Power Systems Analysis',      code:'EE3501',dept:'EEE', sem:5,credits:4,type:'Theory',color:'#6375ff',faculty:'Prof. P. Rajan',   syllabus:['Power System Components','Load Flow Analysis','Fault Analysis','Stability','Protection']},
      {name:'Electrical Machines II',      code:'EE3502',dept:'EEE', sem:5,credits:3,type:'Theory',color:'#0891b2',faculty:'Prof. Q. Selvi',   syllabus:['Synchronous Generators','Synchronous Motors','3-Phase Induction Motors','Single Phase IM','Special Machines']},
      {name:'Control Systems',             code:'EE3503',dept:'EEE', sem:5,credits:4,type:'Theory',color:'#d97706',faculty:'Prof. R. Anand',   syllabus:['Transfer Functions','Block Diagram','Time Domain','Frequency Domain','State Space']},
      {name:'Power Electronics',           code:'EE3504',dept:'EEE', sem:5,credits:3,type:'Theory',color:'#059669',faculty:'Prof. S. Kavya',   syllabus:['Power Semiconductor Devices','Rectifiers','Inverters & Choppers','AC Controllers','SMPS']},
      {name:'Signals & Systems',           code:'EE3505',dept:'EEE', sem:5,credits:4,type:'Theory',color:'#7c3aed',faculty:'Prof. T. Babu',    syllabus:['Continuous & Discrete Signals','Fourier Series','Laplace Transform','Z-Transform','System Analysis']},
      {name:'Electrical Machines Lab',     code:'EE3511',dept:'EEE', sem:5,credits:2,type:'Lab',   color:'#be123c',faculty:'Prof. Q. Selvi',   syllabus:['DC Motor Characteristics','Induction Motor Testing','Synchronous Machine','Transformer Tests','Power Factor']},
      // MECH Sem 5
      {name:'Heat & Mass Transfer',        code:'ME3501',dept:'MECH',sem:5,credits:4,type:'Theory',color:'#6375ff',faculty:'Prof. U. Sathish',  syllabus:['Conduction','Convection','Radiation','Heat Exchangers','Mass Transfer']},
      {name:'Design of Machine Elements',  code:'ME3502',dept:'MECH',sem:5,credits:3,type:'Theory',color:'#0891b2',faculty:'Prof. V. Pradeep',  syllabus:['Design Fundamentals','Shaft Design','Coupling & Clutch','Gear Design','Spring & Bearing']},
      {name:'Manufacturing Technology II', code:'ME3503',dept:'MECH',sem:5,credits:4,type:'Theory',color:'#d97706',faculty:'Prof. W. Natarajan',syllabus:['Metal Cutting','Lathe Operations','Milling & Drilling','CNC Machining','Advanced Manufacturing']},
      {name:'Fluid Mechanics & Machinery', code:'ME3504',dept:'MECH',sem:5,credits:3,type:'Theory',color:'#059669',faculty:'Prof. X. Murugesan',syllabus:['Fluid Properties','Bernoulli Equation','Flow Measurement','Centrifugal Pumps','Turbines']},
      {name:'Engineering Materials',       code:'ME3505',dept:'MECH',sem:5,credits:4,type:'Theory',color:'#7c3aed',faculty:'Prof. Y. Chandran', syllabus:['Crystal Structure','Iron-Carbon Diagram','Heat Treatment','Composites','Nanomaterials']},
      {name:'Manufacturing Lab',           code:'ME3511',dept:'MECH',sem:5,credits:2,type:'Lab',   color:'#be123c',faculty:'Prof. W. Natarajan',syllabus:['Lathe Practice','Milling','Welding','CNC Programming','Metrology']},
      // VLSI Sem 5
      {name:'VLSI Design & Technology',    code:'VL3501',dept:'VLSI',sem:5,credits:4,type:'Theory',color:'#7c3aed',faculty:'Prof. A1. Senthil', syllabus:['MOS Device Physics','CMOS Inverter','Combinational VLSI','Sequential VLSI','Low Power Design']},
      {name:'Analog IC Design',            code:'VL3502',dept:'VLSI',sem:5,credits:3,type:'Theory',color:'#6375ff',faculty:'Prof. B1. Deepa',   syllabus:['Op-Amp Design','Differential Amplifiers','Current Mirrors','PLL Design','ADC/DAC']},
      {name:'FPGA & Embedded Systems',     code:'VL3503',dept:'VLSI',sem:5,credits:4,type:'Theory',color:'#0891b2',faculty:'Prof. C1. Ravi',    syllabus:['FPGA Architecture','VHDL Programming','Verilog HDL','RTL Design','SoC Design']},
      {name:'Physical Design & EDA',       code:'VL3504',dept:'VLSI',sem:5,credits:3,type:'Theory',color:'#d97706',faculty:'Prof. D1. Priya',   syllabus:['Floorplanning','Placement & Routing','Clock Tree Synthesis','Static Timing Analysis','DFT']},
      {name:'Testing & Verification',      code:'VL3505',dept:'VLSI',sem:5,credits:4,type:'Theory',color:'#059669',faculty:'Prof. E1. Kumar',   syllabus:['Fault Models','ATPG','Boundary Scan','Formal Verification','Functional Simulation']},
      {name:'VLSI Design Lab',             code:'VL3511',dept:'VLSI',sem:5,credits:2,type:'Lab',   color:'#be123c',faculty:'Prof. A1. Senthil', syllabus:['Cadence Virtuoso','Synopsys Design Compiler','Modelsim','Layout Design','FPGA Implementation']},
      // AIML Sem 5
      {name:'Machine Learning',            code:'AI3501',dept:'AIML',sem:5,credits:4,type:'Theory',color:'#db2777',faculty:'Prof. F1. Divya',   syllabus:['Supervised Learning','Unsupervised Learning','Neural Networks','Decision Trees','Model Evaluation']},
      {name:'Deep Learning',               code:'AI3502',dept:'AIML',sem:5,credits:3,type:'Theory',color:'#7c3aed',faculty:'Prof. G1. Ramesh',  syllabus:['CNN Architecture','RNN & LSTM','Transfer Learning','GANs','Transformer Models']},
      {name:'Natural Language Processing', code:'AI3503',dept:'AIML',sem:5,credits:4,type:'Theory',color:'#6375ff',faculty:'Prof. H1. Nisha',   syllabus:['Text Preprocessing','Word Embeddings','Sentiment Analysis','NER','LLM Basics']},
      {name:'Computer Vision',             code:'AI3504',dept:'AIML',sem:5,credits:3,type:'Theory',color:'#0891b2',faculty:'Prof. I1. Vijay',   syllabus:['Image Processing','Object Detection','Image Segmentation','Face Recognition','YOLO & OpenCV']},
      {name:'AI Ethics & Applications',    code:'AI3505',dept:'AIML',sem:5,credits:4,type:'Theory',color:'#059669',faculty:'Prof. J1. Rekha',   syllabus:['AI Ethics','Bias & Fairness','Explainable AI','AI in Healthcare','AI in Industry 4.0']},
      {name:'ML Lab (Python/TensorFlow)',  code:'AI3511',dept:'AIML',sem:5,credits:2,type:'Lab',   color:'#be123c',faculty:'Prof. F1. Divya',   syllabus:['Python ML Libraries','Sklearn Pipelines','TensorFlow/Keras','PyTorch Basics','ML Project']},
      // Cyber Security Sem 5
      {name:'Network Security',            code:'CY3501',dept:'CYS', sem:5,credits:4,type:'Theory',color:'#dc2626',faculty:'Prof. K1. Arjun',   syllabus:['Network Attacks','Firewalls & IDS','VPN & Tunneling','Wireless Security','Cloud Security']},
      {name:'Cryptography',                code:'CY3502',dept:'CYS', sem:5,credits:3,type:'Theory',color:'#7c3aed',faculty:'Prof. L1. Selvi',   syllabus:['Symmetric Encryption','Asymmetric Encryption','Hash Functions','Digital Signatures','PKI']},
      {name:'Ethical Hacking',             code:'CY3503',dept:'CYS', sem:5,credits:4,type:'Theory',color:'#6375ff',faculty:'Prof. M1. Anand',   syllabus:['Reconnaissance','Scanning & Enumeration','Exploitation','Post Exploitation','Reporting']},
      {name:'Digital Forensics',           code:'CY3504',dept:'CYS', sem:5,credits:3,type:'Theory',color:'#0891b2',faculty:'Prof. N1. Kavya',   syllabus:['Forensic Investigation','Disk Analysis','Memory Forensics','Network Forensics','Evidence']},
      {name:'Malware Analysis',            code:'CY3505',dept:'CYS', sem:5,credits:4,type:'Theory',color:'#059669',faculty:'Prof. O1. Babu',    syllabus:['Static Analysis','Dynamic Analysis','Assembly Basics','Disassemblers','Malware Types']},
      {name:'Cybersecurity Lab',           code:'CY3511',dept:'CYS', sem:5,credits:2,type:'Lab',   color:'#be123c',faculty:'Prof. K1. Arjun',   syllabus:['Kali Linux','Metasploit','Wireshark','Nmap Scanning','CTF Challenges']},
      // Biotechnology Sem 5
      {name:'Molecular Biology',           code:'BT3501',dept:'BIO', sem:5,credits:4,type:'Theory',color:'#16a34a',faculty:'Prof. P1. Preethi', syllabus:['DNA Structure & Replication','Transcription & Translation','Gene Regulation','Mutations','Recombinant DNA']},
      {name:'Genetic Engineering',         code:'BT3502',dept:'BIO', sem:5,credits:3,type:'Theory',color:'#0891b2',faculty:'Prof. Q1. Saranya', syllabus:['Restriction Enzymes','Cloning Vectors','Gene Expression','CRISPR-Cas9','Gene Therapy']},
      {name:'Biochemistry',                code:'BT3503',dept:'BIO', sem:5,credits:4,type:'Theory',color:'#d97706',faculty:'Prof. R1. Ramesh',  syllabus:['Proteins & Enzymes','Carbohydrate Metabolism','Lipid Metabolism','Vitamins','Metabolic Pathways']},
      {name:'Bioprocess Technology',       code:'BT3504',dept:'BIO', sem:5,credits:3,type:'Theory',color:'#7c3aed',faculty:'Prof. S1. Kavya',   syllabus:['Fermentation Technology','Bioreactor Design','Downstream Processing','Enzyme Technology','Industrial Biotech']},
      {name:'Immunology',                  code:'BT3505',dept:'BIO', sem:5,credits:4,type:'Theory',color:'#059669',faculty:'Prof. T1. Babu',    syllabus:['Innate Immunity','Adaptive Immunity','Antibodies','Vaccines','Immunological Disorders']},
      {name:'Biotech Lab',                 code:'BT3511',dept:'BIO', sem:5,credits:2,type:'Lab',   color:'#be123c',faculty:'Prof. P1. Preethi', syllabus:['PCR Techniques','Gel Electrophoresis','Cell Culture','ELISA Assay','Protein Extraction']},
      // Biomedical Engineering Sem 5
      {name:'Medical Instrumentation',     code:'BM3501',dept:'BME', sem:5,credits:4,type:'Theory',color:'#0d9488',faculty:'Prof. U1. Sathish', syllabus:['ECG & EEG Instruments','Blood Pressure Measurement','Patient Monitoring','Therapeutic Devices','Imaging Systems']},
      {name:'Biomechanics',                code:'BM3502',dept:'BME', sem:5,credits:3,type:'Theory',color:'#6375ff',faculty:'Prof. V1. Pradeep', syllabus:['Mechanics of Human Body','Gait Analysis','Joint Biomechanics','Orthopedic Implants','Prosthetic Design']},
      {name:'DSP for Biomedical',          code:'BM3503',dept:'BME', sem:5,credits:4,type:'Theory',color:'#0891b2',faculty:'Prof. W1. Natarajan',syllabus:['Biomedical Signals','ECG Signal Processing','EEG Analysis','EMG Processing','Noise Filtering']},
      {name:'Medical Imaging',             code:'BM3504',dept:'BME', sem:5,credits:3,type:'Theory',color:'#d97706',faculty:'Prof. X1. Murugesan',syllabus:['X-Ray Imaging','CT Scan Principles','MRI Physics','Ultrasound Imaging','Nuclear Imaging']},
      {name:'Tissue Engineering',          code:'BM3505',dept:'BME', sem:5,credits:4,type:'Theory',color:'#7c3aed',faculty:'Prof. Y1. Chandran', syllabus:['Scaffolds','Stem Cell Biology','3D Bioprinting','Organ-on-Chip','Clinical Applications']},
      {name:'Biomedical Lab',              code:'BM3511',dept:'BME', sem:5,credits:2,type:'Lab',   color:'#be123c',faculty:'Prof. U1. Sathish', syllabus:['ECG Recording','Patient Monitor Calibration','PCB Design for Medical','Biosignal Processing','Imaging Lab']},
      // IoT Sem 5
      {name:'IoT Architecture & Protocols',code:'IO3501',dept:'IOT', sem:5,credits:4,type:'Theory',color:'#0284c7',faculty:'Prof. Z1. Rajan',   syllabus:['IoT Architecture','MQTT & CoAP','LoRaWAN','Zigbee & Z-Wave','IPv6 for IoT']},
      {name:'Embedded Systems for IoT',   code:'IO3502',dept:'IOT', sem:5,credits:3,type:'Theory',color:'#7c3aed',faculty:'Prof. A2. Selvi',   syllabus:['Arduino & ESP8266','Raspberry Pi','FreeRTOS','Edge Computing','Sensor Interfacing']},
      {name:'Cloud Computing for IoT',    code:'IO3503',dept:'IOT', sem:5,credits:4,type:'Theory',color:'#6375ff',faculty:'Prof. B2. Anand',   syllabus:['AWS IoT','Azure IoT Hub','Google Cloud IoT','Edge-Cloud Integration','Data Management']},
      {name:'IoT Security',               code:'IO3504',dept:'IOT', sem:5,credits:3,type:'Theory',color:'#dc2626',faculty:'Prof. C2. Kavya',   syllabus:['IoT Threat Landscape','Authentication','Secure Boot','Encryption for IoT','Vulnerability Assessment']},
      {name:'IoT Applications',           code:'IO3505',dept:'IOT', sem:5,credits:4,type:'Theory',color:'#059669',faculty:'Prof. D2. Babu',    syllabus:['Smart Home Systems','Industrial IoT','Healthcare IoT','Smart Agriculture','Smart City']},
      {name:'IoT Lab',                    code:'IO3511',dept:'IOT', sem:5,credits:2,type:'Lab',   color:'#be123c',faculty:'Prof. Z1. Rajan',   syllabus:['Arduino Projects','Raspberry Pi Projects','MQTT Dashboard','Cloud Integration','IoT Project']},
      // Data Science Sem 5
      {name:'Statistical Learning',       code:'DS3501',dept:'DSC', sem:5,credits:4,type:'Theory',color:'#0891b2',faculty:'Prof. E2. Nisha',   syllabus:['Regression Analysis','Classification','Clustering','Dimensionality Reduction','Model Selection']},
      {name:'Big Data Analytics',         code:'DS3502',dept:'DSC', sem:5,credits:3,type:'Theory',color:'#7c3aed',faculty:'Prof. F2. Vijay',   syllabus:['Hadoop MapReduce','Apache Spark','Hive & Pig','Data Lakes','Real-time Analytics']},
      {name:'Data Visualization',         code:'DS3503',dept:'DSC', sem:5,credits:4,type:'Theory',color:'#6375ff',faculty:'Prof. G2. Rekha',   syllabus:['Matplotlib & Seaborn','Tableau','Power BI','D3.js','Dashboard Design']},
      {name:'Database Systems',           code:'DS3504',dept:'DSC', sem:5,credits:3,type:'Theory',color:'#d97706',faculty:'Prof. H2. Arjun',   syllabus:['Relational DB','NoSQL MongoDB','Graph DB Neo4j','Time Series DB','Data Warehousing']},
      {name:'Business Intelligence',      code:'DS3505',dept:'DSC', sem:5,credits:4,type:'Theory',color:'#059669',faculty:'Prof. I2. Kumar',   syllabus:['OLAP & OLTP','ETL Pipelines','KPI & Metrics','Predictive Analytics','BI Tools']},
      {name:'Data Science Lab',           code:'DS3511',dept:'DSC', sem:5,credits:2,type:'Lab',   color:'#be123c',faculty:'Prof. E2. Nisha',   syllabus:['Pandas & NumPy','EDA Projects','Sklearn ML Pipelines','Data Visualization Project','Capstone Project']},
    ]);
    console.log('📚 Subjects created: 72 (across all departments)');

    // ── 3. USERS ───────────────────────────
    const users = await User.create([
      { name:'Akshaya Darshini', email:'akshayadarshini.n@gmail.com', password:'aksh@2006', role:'admin', dept:'Computer Science & Engineering', deptCode:'CSE',  sem:5, reg:'CS21001', cgpa:8.7 },
      { name:'Hari Vignesh',     email:'harivignesh@gmail.com',       password:'hari@1111', role:'student',dept:'Computer Science & Engineering', deptCode:'CSE',  sem:5, reg:'CS21002', cgpa:8.4 },
      { name:'Priya Dharshini',  email:'priya.it@gmail.com',          password:'priya@123', role:'student',dept:'Information Technology',         deptCode:'IT',   sem:5, reg:'IT21001', cgpa:8.2 },
      { name:'Rajan Kumar',      email:'rajan.ece@gmail.com',         password:'rajan@123', role:'student',dept:'Electronics & Communication Engineering',deptCode:'ECE', sem:5, reg:'EC21001', cgpa:7.9 },
      { name:'Deepa Lakshmi',    email:'deepa.eee@gmail.com',         password:'deepa@123', role:'student',dept:'Electrical & Electronics Engineering',deptCode:'EEE', sem:5, reg:'EE21001', cgpa:8.1 },
      { name:'Arun Prasad',      email:'arun.mech@gmail.com',         password:'arun@123',  role:'student',dept:'Mechanical Engineering',         deptCode:'MECH', sem:5, reg:'ME21001', cgpa:7.8 },
      { name:'Kavya Senthil',    email:'kavya.vlsi@gmail.com',        password:'kavya@123', role:'student',dept:'VLSI Design',                    deptCode:'VLSI', sem:5, reg:'VL21001', cgpa:8.5 },
      { name:'Rahul Sharma',     email:'rahul.aiml@gmail.com',        password:'rahul@123', role:'student',dept:'Artificial Intelligence & ML',   deptCode:'AIML', sem:5, reg:'AI21001', cgpa:8.9 },
      { name:'Sneha Priya',      email:'sneha.bio@gmail.com',         password:'sneha@123', role:'student',dept:'Biotechnology',                  deptCode:'BIO',  sem:5, reg:'BT21001', cgpa:8.0 },
    ]);
    console.log('👥 Users created:', users.length, '(1 admin + 8 students across all depts)');

    // ── 4. ASSIGNMENTS ─────────────────────
    await Assignment.create([
      { title:'Sorting Algorithms Implementation',  subject:'Data Structures',     code:'CS3401', dept:'CSE',  due:'Mar 18, 2026', daysLeft:5,  maxMarks:25, status:'pending',  progress:0, questions:['Implement Merge Sort with time complexity analysis.','Compare Quick Sort vs Heap Sort on 10,000 elements.','Write Radix Sort for non-negative integers.'], postedBy:users[0]._id },
      { title:'ER Diagram & Normalization',         subject:'DBMS',                code:'CS3402', dept:'CSE',  due:'Mar 22, 2026', daysLeft:9,  maxMarks:20, status:'pending',  progress:1, questions:['Design ER diagram for Library Management System.','Normalize given relation to 3NF with proper steps.'], postedBy:users[0]._id },
      { title:'TCP/IP Protocol Analysis',           subject:'Computer Networks',   code:'CS3404', dept:'CSE',  due:'Mar 10, 2026', daysLeft:0,  maxMarks:20, status:'submitted',progress:2, questions:['Explain TCP 3-way handshake with packet diagram.','Compare TCP and UDP with real use cases.'], postedBy:users[0]._id },
      { title:'Process Scheduling Algorithms',      subject:'Operating Systems',   code:'CS3403', dept:'CSE',  due:'Mar 8,  2026', daysLeft:-5, maxMarks:30, status:'overdue',  progress:0, questions:['Simulate FCFS, SJF and Round Robin scheduling.','Calculate average waiting time for all algorithms.'], postedBy:users[0]._id },
      { title:'React.js Component Development',     subject:'Web Technology',      code:'IT3401', dept:'IT',   due:'Mar 20, 2026', daysLeft:7,  maxMarks:25, status:'pending',  progress:0, questions:['Build a responsive dashboard using React.js.','Implement React hooks: useState, useEffect, useContext.'], postedBy:users[0]._id },
      { title:'FIR Filter Design Using MATLAB',     subject:'DSP',                 code:'EC3501', dept:'ECE',  due:'Mar 19, 2026', daysLeft:6,  maxMarks:25, status:'pending',  progress:0, questions:['Design a low-pass FIR filter with cutoff 1kHz.','Compare FIR and IIR filter characteristics.'], postedBy:users[0]._id },
      { title:'Load Flow Analysis Report',          subject:'Power Systems',       code:'EE3501', dept:'EEE',  due:'Mar 21, 2026', daysLeft:8,  maxMarks:25, status:'pending',  progress:0, questions:['Perform Gauss-Seidel load flow for 3-bus system.','Analyze voltage profile and reactive power.'], postedBy:users[0]._id },
      { title:'Heat Exchanger Design Project',      subject:'Heat & Mass Transfer', code:'ME3501', dept:'MECH', due:'Mar 23, 2026', daysLeft:10, maxMarks:30, status:'pending',  progress:0, questions:['Design a shell-and-tube heat exchanger.','Calculate LMTD and overall heat transfer coefficient.'], postedBy:users[0]._id },
      { title:'CMOS Inverter Design using Cadence', subject:'VLSI Design',         code:'VL3501', dept:'VLSI', due:'Mar 25, 2026', daysLeft:12, maxMarks:25, status:'pending',  progress:0, questions:['Design CMOS inverter in Cadence Virtuoso.','Perform DC and transient analysis. Calculate noise margins.'], postedBy:users[0]._id },
      { title:'Image Classification using CNN',     subject:'Deep Learning',       code:'AI3502', dept:'AIML', due:'Mar 24, 2026', daysLeft:11, maxMarks:25, status:'pending',  progress:0, questions:['Build CNN model for CIFAR-10 dataset.','Achieve minimum 85% accuracy. Plot training curves.'], postedBy:users[0]._id },
      { title:'PCR and Gel Electrophoresis Report', subject:'Molecular Biology',   code:'BT3501', dept:'BIO',  due:'Mar 20, 2026', daysLeft:7,  maxMarks:20, status:'pending',  progress:0, questions:['Perform PCR amplification of given DNA sample.','Analyze gel electrophoresis results and interpret bands.'], postedBy:users[0]._id },
    ]);
    console.log('📝 Assignments created: 11 (across all departments)');

    // ── 5. EXAMS ───────────────────────────
    await Exam.create([
      { subject:'Data Structures',      code:'CS3401', dept:'CSE',  date:'Mar 15', time:'10:00 AM', hall:'Hall A - Block 2', duration:'3 Hours', daysLeft:2,  color:'#f87171', syllabus:'Units 1-5: Arrays, Trees, Graphs, Sorting & Searching' },
      { subject:'Database Management',  code:'CS3402', dept:'CSE',  date:'Mar 18', time:'10:00 AM', hall:'Hall B - Block 2', duration:'3 Hours', daysLeft:5,  color:'#fb923c', syllabus:'Units 1-5: ER Model, SQL, Normalization, Transactions' },
      { subject:'Operating Systems',    code:'CS3403', dept:'CSE',  date:'Mar 22', time:'10:00 AM', hall:'Hall A - Block 3', duration:'3 Hours', daysLeft:9,  color:'#fbbf24', syllabus:'Units 1-5: Process Management, Memory, File Systems' },
      { subject:'Computer Networks',    code:'CS3404', dept:'CSE',  date:'Mar 26', time:'2:00 PM',  hall:'Hall C - Block 1', duration:'3 Hours', daysLeft:13, color:'#34d399', syllabus:'Units 1-5: OSI, TCP/IP, Routing, Security' },
      { subject:'Probability & Stats',  code:'MA3451', dept:'CSE',  date:'Mar 30', time:'10:00 AM', hall:'Hall D - Block 4', duration:'3 Hours', daysLeft:17, color:'#a78bfa', syllabus:'Units 1-5: Probability, Distributions, Testing' },
      { subject:'Web Technology',       code:'IT3401', dept:'IT',   date:'Mar 16', time:'10:00 AM', hall:'Hall E - Block 2', duration:'3 Hours', daysLeft:3,  color:'#f87171', syllabus:'Units 1-5: HTML, CSS, JS, React, Node.js' },
      { subject:'Software Engineering', code:'IT3402', dept:'IT',   date:'Mar 20', time:'10:00 AM', hall:'Hall F - Block 3', duration:'3 Hours', daysLeft:7,  color:'#fb923c', syllabus:'Units 1-5: SDLC, Agile, Testing, Project Management' },
      { subject:'DSP',                  code:'EC3501', dept:'ECE',  date:'Mar 17', time:'10:00 AM', hall:'Hall G - Block 4', duration:'3 Hours', daysLeft:4,  color:'#f87171', syllabus:'Units 1-5: DT Signals, DFT, FIR, IIR, FFT' },
      { subject:'VLSI Design',          code:'EC3505', dept:'ECE',  date:'Mar 21', time:'2:00 PM',  hall:'Hall H - Block 1', duration:'3 Hours', daysLeft:8,  color:'#fbbf24', syllabus:'Units 1-5: MOS, CMOS, Layout Design' },
      { subject:'Power Systems',        code:'EE3501', dept:'EEE',  date:'Mar 18', time:'2:00 PM',  hall:'Hall I - Block 3', duration:'3 Hours', daysLeft:5,  color:'#34d399', syllabus:'Units 1-5: Power Flow, Fault Analysis, Protection' },
      { subject:'Heat & Mass Transfer',  code:'ME3501', dept:'MECH', date:'Mar 19', time:'10:00 AM', hall:'Hall J - Block 2', duration:'3 Hours', daysLeft:6,  color:'#fb923c', syllabus:'Units 1-5: Conduction, Convection, Radiation, Heat Exchangers' },
      { subject:'VLSI Design & Technology',code:'VL3501',dept:'VLSI',date:'Mar 22',time:'10:00 AM', hall:'Hall K - Block 5', duration:'3 Hours', daysLeft:9,  color:'#7c3aed', syllabus:'Units 1-5: MOS Physics, CMOS, Combinational, Sequential, Low Power' },
      { subject:'Machine Learning',     code:'AI3501', dept:'AIML', date:'Mar 20', time:'10:00 AM', hall:'Hall L - Block 5', duration:'3 Hours', daysLeft:7,  color:'#db2777', syllabus:'Units 1-5: Supervised, Unsupervised, Neural Networks, Evaluation' },
      { subject:'Molecular Biology',    code:'BT3501', dept:'BIO',  date:'Mar 23', time:'10:00 AM', hall:'Hall M - Block 6', duration:'3 Hours', daysLeft:10, color:'#16a34a', syllabus:'Units 1-5: DNA, Transcription, Gene Regulation, Mutations, Recombinant DNA' },
    ]);
    console.log('📅 Exams created: 14 (across all departments)');

    // ── 6. INTERNSHIPS ─────────────────────
    await Internship.create([
      { company:'Google',     logo:'G',  color:'#4285F4', ctc:'₹80,000/mo', role:'SWE Intern',          dept:['CSE','IT','AIML','DSC'],      skills:['Python','DSA','System Design'],      type:'Paid', mode:'Hybrid',  duration:'3 months', location:'Bangalore',  deadline:'Apr 15', rounds:['OA – 2 DSA problems','Technical Round 1 – DSA','Technical Round 2 – System Design','HR Round'],      desc:'Work on real Google products with cutting-edge tech teams.', resources:['LeetCode','System Design Primer'] },
      { company:'Microsoft',  logo:'M',  color:'#00A4EF', ctc:'₹75,000/mo', role:'SDE Intern',          dept:['CSE','IT','ECE','AIML'],      skills:['C++','OOP','Azure'],                type:'Paid', mode:'Online',  duration:'2 months', location:'Hyderabad',  deadline:'Apr 20', rounds:['Coding Round – 3 problems','Technical Interview 1','Technical Interview 2','HR Round'],          desc:'Contribute to Microsoft products used by millions.', resources:['HackerRank','MS Learn'] },
      { company:'Amazon',     logo:'A',  color:'#FF9900', ctc:'₹60,000/mo', role:'SDE Intern',          dept:['CSE','IT','DSC'],            skills:['Java','DSA','AWS'],                  type:'Paid', mode:'Hybrid',  duration:'6 months', location:'Chennai',    deadline:'May 1',  rounds:['Online Assessment','Technical Loop 1','Technical Loop 2','Bar Raiser Round'],              desc:'Amazon internship with PPO available for top performers.', resources:['LeetCode','Leadership Principles'] },
      { company:'Qualcomm',   logo:'Q',  color:'#3253DC', ctc:'₹70,000/mo', role:'VLSI Design Intern',  dept:['VLSI','ECE'],                skills:['VLSI','VHDL/Verilog','Signal Processing'],type:'Paid',mode:'Hybrid', duration:'6 months', location:'Hyderabad',  deadline:'Apr 8',  rounds:['OA – DSP/VLSI questions','Technical Round 1','Technical Round 2','HR Round'],              desc:'Work on semiconductor chip design with world-class engineers.', resources:['Cadence Tutorials','VLSI Books'] },
      { company:'ISRO',       logo:'I',  color:'#FF6600', ctc:'Unpaid',      role:'Research Intern',     dept:['ECE','EEE','MECH','AERO','VLSI'],skills:['C','Embedded Systems','Signal Processing'],type:'Free',mode:'Offline',duration:'2 months',location:'Bangalore', deadline:'Mar 30', rounds:['Application Screening','Technical Interview','Document Verification'],                     desc:'Prestigious government internship. Certificate adds great value.', resources:['ISRO Website','Embedded C'] },
      { company:'DRDO',       logo:'D',  color:'#1B4F72', ctc:'Unpaid',      role:'Technical Intern',    dept:['ECE','EEE','MECH','AERO'],   skills:['Signal Processing','Electronics','Defence Tech'],type:'Free',mode:'Offline',duration:'2 months',location:'Hyderabad', deadline:'Apr 5',  rounds:['Application Screening','Technical Interview'],                                             desc:'Defence research internship. Great for core engineering students.', resources:['DRDO Website'] },
      { company:'TCS',        logo:'T',  color:'#0033A0', ctc:'₹7 LPA',     role:'Systems Engineer',    dept:['CSE','IT','ECE','EEE','MECH','CYS','DSC','AIML','IOT','MBA','MCA'],skills:['Java/C','Aptitude','DBMS','OS'],type:'Paid',mode:'Hybrid',duration:'3 months',location:'Multiple',   deadline:'May 15', rounds:['TCS NQT – Aptitude + Coding','Technical Interview','Managerial Round','HR Round'],          desc:'Mass recruiter with good exposure to enterprise projects.', resources:['TCS iON','InfyTQ'] },
      { company:'Infosys',    logo:'In', color:'#007CC3', ctc:'₹6.5 LPA',   role:'Systems Engineer',    dept:['CSE','IT','ECE','AIML','DSC','MBA','MCA'],skills:['Python','Testing','Agile'],    type:'Paid', mode:'Hybrid',  duration:'3 months', location:'Pune',       deadline:'May 5',  rounds:['InfyTQ Test','Technical Interview','HR Interview'],                                           desc:'Good exposure to large-scale enterprise projects.', resources:['InfyTQ','Coursera'] },
      { company:'Biocon',     logo:'Bc', color:'#008000', ctc:'₹6 LPA',     role:'Research Scientist',  dept:['BIO','BME','CHEM'],          skills:['Molecular Biology','Cell Culture','Bioinformatics'],type:'Paid',mode:'Offline',duration:'6 months',location:'Bangalore', deadline:'Apr 20', rounds:['Written Test – Biology Concepts','Lab Test','Technical Interview','HR Round'],              desc:'Leading biotech company. Work on drug discovery and development.', resources:['Biocon Website','Biology Books'] },
      { company:'GE Healthcare',logo:'GE',color:'#1F88E5',ctc:'₹12 LPA',   role:'Biomedical Engineer', dept:['BME','EEE','ECE'],           skills:['Medical Devices','Signal Processing','LabVIEW'],type:'Paid',mode:'Offline',duration:'6 months',location:'Bangalore', deadline:'Apr 25', rounds:['Written Test','Technical Interview 1','Technical Interview 2','HR Round'],                  desc:'Work on life-saving medical imaging and monitoring devices.', resources:['GE Healthcare Website','LabVIEW Tutorials'] },
      { company:'L&T',        logo:'L',  color:'#D4351C', ctc:'₹8 LPA',     role:'Graduate Apprentice', dept:['MECH','CIVIL','EEE','CHEM','AERO'],skills:['AutoCAD','Engineering Design','Project Management'],type:'Paid',mode:'Offline',duration:'6 months',location:'Mumbai',deadline:'Apr 25',  rounds:['Written Test','Technical Interview','HR Round'],                                             desc:'Leading engineering company with mega project exposure.', resources:['L&T Institute','Coursera'] },
      { company:'Zoho',       logo:'Z',  color:'#E42527', ctc:'₹12 LPA',    role:'Software Developer',  dept:['CSE','IT','AIML','MCA'],     skills:['Java','React','SQL','Problem Solving'],type:'Paid',mode:'Offline', duration:'6 months', location:'Chennai',    deadline:'Apr 10', rounds:['Written Test – Coding + Aptitude','Advanced Programming Round','Technical Interview','HR'],  desc:'Great product company with high PPO rate for top performers.', resources:['Zoho Campus','HackerEarth'] },
    ]);
    console.log('💼 Internships created: 12 (for all departments)');

    // ── 7. ANNOUNCEMENTS ───────────────────
    await Announcement.create([
      { title:'Internal Exam Schedule Released',   msg:'Internal exams from Mar 15–30, 2026. Check calendar for dept-wise dates, hall assignments and syllabus coverage.',  type:'Exam',      priority:'High',   postedBy:users[0]._id },
      { title:'Hackathon Registration Open',       msg:'Anna University Hackathon 2026. Team: 2–4 members. Prize: ₹1,00,000. Register before Mar 15. All departments eligible.', type:'Event',  priority:'Medium', postedBy:users[0]._id },
      { title:'TCS & Infosys Campus Drive',        msg:'Drives scheduled for Mar 25–28. CSE, IT, ECE, EEE, MECH, MBA eligible. Register with placement cell by Mar 20.',    type:'Placement', priority:'High',   postedBy:users[0]._id },
      { title:'NPTEL Enrollment Deadline',         msg:'Last date to enroll for NPTEL courses: Mar 31. Elite certificate significantly boosts your placement profile!',        type:'Academic',  priority:'Medium', postedBy:users[0]._id },
      { title:'Industrial Visit — BHEL Trichy',    msg:'Industrial visit to BHEL Trichy on Apr 5 for EEE & MECH students. Provides great exposure to power sector. Register by Mar 25.', type:'Event', priority:'Low', postedBy:users[0]._id },
      { title:'Qualcomm VLSI Drive Announced',     msg:'Qualcomm visiting for VLSI Design Engineer roles. VLSI & ECE students with 7.5+ CGPA eligible. Drive date: Apr 8.',  type:'Placement', priority:'High',   postedBy:users[0]._id },
      { title:'Biocon Campus Recruitment',         msg:'Biocon recruiting Research Scientists from BIO, BME and CHEM departments. Minimum 7.0 CGPA required. Apply by Apr 20.', type:'Placement',priority:'High',  postedBy:users[0]._id },
    ]);
    console.log('📢 Announcements created: 7');

    // ── Summary ───────────────────────────
    console.log('\n🎉 ════════════════════════════════════════════════════');
    console.log('   EduSync Database Seeded Successfully!');
    console.log('════════════════════════════════════════════════════════');
    console.log('📊 Data Summary:');
    console.log('   🏛️  Departments  : 20 (Engineering + Specialised + Science + Management)');
    console.log('   📚  Subjects     : 72 (6 per dept × 12 depts for Sem 5)');
    console.log('   👥  Users        : 9  (1 admin + 8 students across depts)');
    console.log('   📝  Assignments  : 11 (across all departments)');
    console.log('   📅  Exams        : 14 (across all departments)');
    console.log('   💼  Internships  : 12 (for all departments)');
    console.log('   📢  Announcements: 7');
    console.log('════════════════════════════════════════════════════════');
    console.log('🔑 Login Credentials:');
    console.log('   🛡️  Admin   → akshayadarshini.n@gmail.com / aksh@2006  (CSE)');
    console.log('   👤  Student → harivignesh@gmail.com  / hari@1111        (CSE)');
    console.log('   👤  Student → priya.it@gmail.com     / priya@123        (IT)');
    console.log('   👤  Student → rajan.ece@gmail.com    / rajan@123        (ECE)');
    console.log('   👤  Student → deepa.eee@gmail.com    / deepa@123        (EEE)');
    console.log('   👤  Student → arun.mech@gmail.com    / arun@123         (MECH)');
    console.log('   👤  Student → kavya.vlsi@gmail.com   / kavya@123        (VLSI)');
    console.log('   👤  Student → rahul.aiml@gmail.com   / rahul@123        (AIML)');
    console.log('   👤  Student → sneha.bio@gmail.com    / sneha@123        (BIO)');
    console.log('════════════════════════════════════════════════════════\n');

    process.exit(0);
  } catch (err) {
    console.error('❌ Seed error:', err.message);
    process.exit(1);
  }
};

seed();
