// ============================================
//  EduSync Backend Server
//  Node.js + Express + MongoDB
//  Run: npm run dev
// ============================================
const express  = require('express');
const mongoose = require('mongoose');
const cors     = require('cors');
const dotenv   = require('dotenv');

dotenv.config();
const app = express();

// ── Middleware ────────────────────────────
app.use(cors({
  origin: process.env.CLIENT_URL || 'http://localhost:3000',
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ── Database Connection ───────────────────
mongoose.connect(process.env.MONGO_URI)
  .then(() => {
    console.log('✅ MongoDB Connected:', mongoose.connection.name);
    console.log('📍 Host:', mongoose.connection.host);
  })
  .catch(err => console.error('❌ MongoDB Error:', err.message));

// ── Routes ───────────────────────────────
app.use('/api/auth',          require('./routes/auth'));
app.use('/api/users',         require('./routes/users'));
app.use('/api/departments',   require('./routes/departments'));
app.use('/api/subjects',      require('./routes/subjects'));
app.use('/api/timetable',     require('./routes/timetable'));
app.use('/api/roadmap',       require('./routes/roadmap'));
app.use('/api/assignments',   require('./routes/assignments'));
app.use('/api/internships',   require('./routes/internships'));
app.use('/api/placements',    require('./routes/placements'));
app.use('/api/nptel',         require('./routes/nptel'));
app.use('/api/notes',         require('./routes/notes'));
app.use('/api/reminders',     require('./routes/reminders'));
app.use('/api/events',        require('./routes/events'));
app.use('/api/exams',         require('./routes/exams'));
app.use('/api/announcements', require('./routes/announcements'));

// ── Health Check ─────────────────────────
app.get('/', (req, res) => {
  res.json({
    message: '🎓 EduSync API is running!',
    version: '3.0.0',
    status:  'OK',
    database:'MongoDB Connected ✅',
    departments: ['CSE','IT','ECE','EEE','MECH','VLSI','AIML','CYS','IOT','DSC','BIO','BME','ROB','AERO','CIVIL','CHEM','PHY','MATH','MBA','MCA'],
    api_endpoints: {
      auth:          'POST /api/auth/login  |  POST /api/auth/register',
      departments:   'GET  /api/departments  |  GET /api/departments/:code',
      subjects:      'GET  /api/subjects?dept=CSE&sem=5',
      timetable:     'GET  /api/timetable?dept=CSE&sem=5',
      roadmap:       'GET  /api/roadmap?dept=CSE',
      assignments:   'GET  /api/assignments',
      internships:   'GET  /api/internships',
      placements:    'GET  /api/placements',
      exams:         'GET  /api/exams',
      notes:         'GET  /api/notes  |  POST /api/notes',
      reminders:     'GET  /api/reminders  |  POST /api/reminders',
      announcements: 'GET  /api/announcements',
    }
  });
});

// ── 404 Handler ──────────────────────────
app.use((req, res) => {
  res.status(404).json({ message: `Route ${req.url} not found` });
});

// ── Error Handler ────────────────────────
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Server Error', error: err.message });
});

// ── Start Server ─────────────────────────
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log('');
  console.log('🎓 ══════════════════════════════════════');
  console.log(`🚀  EduSync Server → http://localhost:${PORT}`);
  console.log('📚  All 20 Departments Ready');
  console.log('🔐  JWT Authentication Enabled');
  console.log('═══════════════════════════════════════');
  console.log('');
});
