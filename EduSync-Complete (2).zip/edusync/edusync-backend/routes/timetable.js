const express   = require('express');
const router    = express.Router();
const Timetable = require('../models/Timetable');
const { protect, adminOnly } = require('../middleware/auth');

// GET timetable by dept & sem
// GET /api/timetable?dept=CS&sem=5
router.get('/', protect, async (req, res) => {
  try {
    const filter = { isActive: true };
    if (req.query.dept) filter.dept = req.query.dept.toUpperCase();
    if (req.query.sem)  filter.sem  = parseInt(req.query.sem);
    const timetable = await Timetable.findOne(filter);
    if (!timetable) return res.status(404).json({ message: 'Timetable not found for this dept/sem' });
    res.json(timetable);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET all timetables
router.get('/all', protect, async (req, res) => {
  try {
    const timetables = await Timetable.find({ isActive: true });
    res.json(timetables);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST create timetable (admin)
router.post('/', protect, adminOnly, async (req, res) => {
  try {
    const timetable = await Timetable.create(req.body);
    res.status(201).json(timetable);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// PUT update timetable (admin)
router.put('/:id', protect, adminOnly, async (req, res) => {
  try {
    const timetable = await Timetable.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(timetable);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

module.exports = router;
