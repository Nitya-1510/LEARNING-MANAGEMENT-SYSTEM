const express = require('express');
const router = express.Router();
const { protect, adminOnly } = require('../middleware/auth');

// Static placement data (can move to DB later)
const companies = [
  { id:1, name:'TCS', ctc:'₹7 LPA', status:'ongoing', date:'Mar 25', cutoff:'6.0', rounds:['TCS NQT – Aptitude + Coding','Technical Interview','Managerial Round','HR Round'], skills:['Java/C','Aptitude','DBMS'], commTest:true },
  { id:2, name:'Infosys', ctc:'₹6.5 LPA', status:'ongoing', date:'Mar 28', cutoff:'6.5', rounds:['InfyTQ Test','Technical Interview','HR Interview'], skills:['Java','Python','DBMS'], commTest:false },
  { id:3, name:'Google', ctc:'₹45 LPA', status:'upcoming', date:'Apr 10', cutoff:'7.5', rounds:['OA – DSA Problems','Technical Round 1','Technical Round 2 – Design','HR Round'], skills:['DSA','System Design','Python'], commTest:false },
  { id:4, name:'Microsoft', ctc:'₹40 LPA', status:'upcoming', date:'Apr 15', cutoff:'7.0', rounds:['Coding Round','Technical Interview 1','Technical Interview 2','HR Round'], skills:['DSA','C++/Java','System Design'], commTest:true },
  { id:5, name:'Amazon', ctc:'₹35 LPA', status:'upcoming', date:'Apr 20', cutoff:'7.0', rounds:['Online Assessment','Technical Loop 1','Technical Loop 2','Bar Raiser'], skills:['Java','DSA','Leadership Principles'], commTest:false },
];

router.get('/', protect, async (req, res) => {
  res.json(companies);
});

module.exports = router;
