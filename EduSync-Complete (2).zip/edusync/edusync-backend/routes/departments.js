const express = require('express');
const router  = express.Router();
const Department = require('../models/Department');
const Subject    = require('../models/Subject');
const Timetable  = require('../models/Timetable');
const Roadmap    = require('../models/Roadmap');
const { protect, adminOnly } = require('../middleware/auth');

// ── GET all departments ───────────────────
// GET /api/departments
router.get('/', protect, async (req, res) => {
  try {
    const depts = await Department.find({ isActive: true });
    res.json(depts);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── GET single department ─────────────────
// GET /api/departments/:code  (e.g. CS, IT, ECE)
router.get('/:code', protect, async (req, res) => {
  try {
    const dept = await Department.findOne({
      code: req.params.code.toUpperCase()
    });
    if (!dept) return res.status(404).json({ message: 'Department not found' });
    res.json(dept);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── GET subjects by dept & sem ────────────
// GET /api/departments/:code/subjects?sem=5
router.get('/:code/subjects', protect, async (req, res) => {
  try {
    const filter = { dept: req.params.code.toUpperCase() };
    if (req.query.sem) filter.sem = parseInt(req.query.sem);
    const subjects = await Subject.find(filter).sort({ sem: 1, name: 1 });
    res.json(subjects);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── GET timetable by dept & sem ───────────
// GET /api/departments/:code/timetable?sem=5
router.get('/:code/timetable', protect, async (req, res) => {
  try {
    const sem = req.query.sem ? parseInt(req.query.sem) : 5;
    const timetable = await Timetable.findOne({
      dept: req.params.code.toUpperCase(),
      sem,
      isActive: true
    });
    if (!timetable) return res.status(404).json({ message: 'Timetable not found' });
    res.json(timetable);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── GET roadmap by dept ───────────────────
// GET /api/departments/:code/roadmap
router.get('/:code/roadmap', protect, async (req, res) => {
  try {
    const roadmap = await Roadmap.findOne({
      dept: req.params.code.toUpperCase()
    });
    if (!roadmap) return res.status(404).json({ message: 'Roadmap not found' });
    res.json(roadmap);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── GET internships by dept ───────────────
// GET /api/departments/:code/internships
router.get('/:code/internships', protect, async (req, res) => {
  try {
    const Internship = require('../models/Internship');
    const internships = await Internship.find({
      dept: req.params.code.toUpperCase(),
      isActive: true
    });
    res.json(internships);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── CREATE department (admin only) ────────
router.post('/', protect, adminOnly, async (req, res) => {
  try {
    const dept = await Department.create(req.body);
    res.status(201).json(dept);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// ── UPDATE department (admin only) ────────
router.put('/:code', protect, adminOnly, async (req, res) => {
  try {
    const dept = await Department.findOneAndUpdate(
      { code: req.params.code.toUpperCase() },
      req.body,
      { new: true }
    );
    res.json(dept);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

module.exports = router;
