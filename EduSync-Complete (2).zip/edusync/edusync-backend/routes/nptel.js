const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');

const courses = [
  { id:1, title:'Data Structures & Algorithms', inst:'IIT Delhi', weeks:12, cert:'Elite+Gold', diff:'Intermediate', progress:65 },
  { id:2, title:'Database Management Systems', inst:'IIT Madras', weeks:12, cert:'Elite', diff:'Intermediate', progress:30 },
  { id:3, title:'Operating Systems', inst:'IIT Madras', weeks:8, cert:'Elite+Gold', diff:'Advanced', progress:0 },
  { id:4, title:'Machine Learning', inst:'IIT Madras', weeks:12, cert:'Elite+Gold', diff:'Advanced', progress:0 },
  { id:5, title:'Computer Networks', inst:'IIT KGP', weeks:12, cert:'Elite', diff:'Intermediate', progress:0 },
];

router.get('/', protect, async (req, res) => { res.json(courses); });

module.exports = router;
