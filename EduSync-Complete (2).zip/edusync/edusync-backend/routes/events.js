const express = require('express');
const router = express.Router();
const { protect, adminOnly } = require('../middleware/auth');

const events = [
  { id:1, title:'Anna University Hackathon 2026', date:'Mar 20-21', type:'Hackathon', prize:'₹1,00,000', venue:'Main Auditorium', deadline:'Mar 15' },
  { id:2, title:'National Paper Presentation', date:'Mar 25', type:'Technical', prize:'₹25,000', venue:'Seminar Hall', deadline:'Mar 18' },
  { id:3, title:'TCS Campus Connect Drive', date:'Mar 28', type:'Placement', prize:'₹7 LPA', venue:'Placement Cell', deadline:'Mar 22' },
];

router.get('/', protect, async (req, res) => { res.json(events); });

module.exports = router;
