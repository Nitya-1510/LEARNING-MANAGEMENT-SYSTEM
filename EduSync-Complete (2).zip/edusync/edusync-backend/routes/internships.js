const express = require('express');
const router = express.Router();
const Internship = require('../models/Internship');
const { protect, adminOnly } = require('../middleware/auth');

// GET all internships (with filters)
router.get('/', protect, async (req, res) => {
  try {
    const { dept, mode, type } = req.query;
    let filter = { isActive: true };
    if (dept && dept !== 'All') filter.dept = dept;
    if (mode && mode !== 'All') filter.mode = mode;
    if (type && type !== 'All') filter.type = type;
    const internships = await Internship.find(filter).sort({ createdAt: -1 });
    res.json(internships);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST create internship (admin only)
router.post('/', protect, adminOnly, async (req, res) => {
  try {
    const internship = await Internship.create(req.body);
    res.status(201).json(internship);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// PUT update internship (admin only)
router.put('/:id', protect, adminOnly, async (req, res) => {
  try {
    const internship = await Internship.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(internship);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// DELETE internship (admin only)
router.delete('/:id', protect, adminOnly, async (req, res) => {
  try {
    await Internship.findByIdAndDelete(req.params.id);
    res.json({ message: 'Internship deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
