const express = require('express');
const router  = express.Router();
const Subject = require('../models/Subject');
const { protect, adminOnly } = require('../middleware/auth');

// GET all subjects (filter by dept/sem)
// GET /api/subjects?dept=CS&sem=5
router.get('/', protect, async (req, res) => {
  try {
    const filter = {};
    if (req.query.dept) filter.dept = req.query.dept.toUpperCase();
    if (req.query.sem)  filter.sem  = parseInt(req.query.sem);
    if (req.query.type) filter.type = req.query.type;
    const subjects = await Subject.find(filter).sort({ sem: 1, name: 1 });
    res.json(subjects);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET single subject
router.get('/:id', protect, async (req, res) => {
  try {
    const subject = await Subject.findById(req.params.id);
    if (!subject) return res.status(404).json({ message: 'Subject not found' });
    res.json(subject);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST create subject (admin)
router.post('/', protect, adminOnly, async (req, res) => {
  try {
    const subject = await Subject.create(req.body);
    res.status(201).json(subject);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// PUT update subject (admin)
router.put('/:id', protect, adminOnly, async (req, res) => {
  try {
    const subject = await Subject.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(subject);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// DELETE subject (admin)
router.delete('/:id', protect, adminOnly, async (req, res) => {
  try {
    await Subject.findByIdAndDelete(req.params.id);
    res.json({ message: 'Subject deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
