const express = require('express');
const router = express.Router();
const User = require('../models/User');
const { protect, adminOnly } = require('../middleware/auth');

// GET all users (admin only)
router.get('/', protect, adminOnly, async (req, res) => {
  try {
    const users = await User.find().select('-password').sort({ createdAt: -1 });
    res.json(users);
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// GET single user profile
router.get('/profile', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select('-password');
    res.json(user);
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// PUT update profile
router.put('/profile', protect, async (req, res) => {
  try {
    const { name, dept, sem, phone, cgpa } = req.body;
    const user = await User.findByIdAndUpdate(
      req.user._id,
      { name, dept, sem, phone, cgpa },
      { new: true }
    ).select('-password');
    res.json({ message: 'Profile updated!', user });
  } catch (err) { res.status(400).json({ message: err.message }); }
});

module.exports = router;
