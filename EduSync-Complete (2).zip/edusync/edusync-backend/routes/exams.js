const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');

const exams = [
  { id:1, subject:'Data Structures', code:'CS3401', date:'Mar 15', hall:'Hall A - Block 2', time:'10:00 AM', daysLeft:2 },
  { id:2, subject:'Database Management', code:'CS3402', date:'Mar 18', hall:'Hall B - Block 2', time:'10:00 AM', daysLeft:5 },
  { id:3, subject:'Operating Systems', code:'CS3403', date:'Mar 22', hall:'Hall A - Block 3', time:'10:00 AM', daysLeft:9 },
  { id:4, subject:'Computer Networks', code:'CS3404', date:'Mar 26', hall:'Hall C - Block 1', time:'2:00 PM', daysLeft:13 },
  { id:5, subject:'Probability & Stats', code:'MA3451', date:'Mar 30', hall:'Hall D - Block 4', time:'10:00 AM', daysLeft:17 },
];

router.get('/', protect, async (req, res) => { res.json(exams); });

module.exports = router;
