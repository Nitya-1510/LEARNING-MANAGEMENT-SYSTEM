const express = require('express');
const router  = express.Router();
const Roadmap = require('../models/Roadmap');
const { protect, adminOnly } = require('../middleware/auth');

// GET roadmap by dept
// GET /api/roadmap?dept=CS
router.get('/', protect, async (req, res) => {
  try {
    const filter = {};
    if (req.query.dept) filter.dept = req.query.dept.toUpperCase();
    const roadmap = req.query.dept
      ? await Roadmap.findOne(filter)
      : await Roadmap.find();
    if (!roadmap) return res.status(404).json({ message: 'Roadmap not found' });
    res.json(roadmap);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET all roadmaps
router.get('/all', protect, async (req, res) => {
  try {
    const roadmaps = await Roadmap.find();
    res.json(roadmaps);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST create roadmap (admin)
router.post('/', protect, adminOnly, async (req, res) => {
  try {
    const roadmap = await Roadmap.create(req.body);
    res.status(201).json(roadmap);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

module.exports = router;
