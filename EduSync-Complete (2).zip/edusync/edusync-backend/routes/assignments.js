const express = require('express');
const router = express.Router();
const Assignment = require('../models/Assignment');
const { protect, adminOnly } = require('../middleware/auth');

// GET all assignments
router.get('/', protect, async (req, res) => {
  try {
    const assignments = await Assignment.find().sort({ createdAt: -1 });
    res.json(assignments);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET single assignment
router.get('/:id', protect, async (req, res) => {
  try {
    const assignment = await Assignment.findById(req.params.id);
    if (!assignment) return res.status(404).json({ message: 'Assignment not found' });
    res.json(assignment);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST create assignment (admin only)
router.post('/', protect, adminOnly, async (req, res) => {
  try {
    const assignment = await Assignment.create({ ...req.body, postedBy: req.user._id });
    res.status(201).json(assignment);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// PUT update assignment
router.put('/:id', protect, async (req, res) => {
  try {
    const assignment = await Assignment.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(assignment);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// DELETE assignment (admin only)
router.delete('/:id', protect, adminOnly, async (req, res) => {
  try {
    await Assignment.findByIdAndDelete(req.params.id);
    res.json({ message: 'Assignment deleted successfully' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
