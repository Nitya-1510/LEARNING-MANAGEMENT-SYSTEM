// All department subjects for Semester 5
const SUBJECTS = [
  // CSE
  {name:'Data Structures & Algorithms',code:'CS3401',dept:'CSE',sem:5,credits:4,type:'Theory',color:'#6375ff',faculty:'Prof. A. Kumar',   syllabus:['Arrays, Linked Lists','Stack & Queue','Trees & BST','Graphs BFS/DFS','Sorting Algorithms']},
  {name:'Database Management Systems', code:'CS3402',dept:'CSE',sem:5,credits:3,type:'Theory',color:'#0891b2',faculty:'Prof. B. Priya',   syllabus:['ER Model','SQL & Relational Algebra','Normalization','Transactions','Indexing & B+ Trees']},
  {name:'Operating Systems',           code:'CS3403',dept:'CSE',sem:5,credits:4,type:'Theory',color:'#d97706',faculty:'Prof. C. Raj',     syllabus:['Process Management','CPU Scheduling','Memory Management','File Systems','Deadlock']},
  {name:'Computer Networks',           code:'CS3404',dept:'CSE',sem:5,credits:3,type:'Theory',color:'#059669',faculty:'Prof. D. Meena',   syllabus:['OSI & TCP/IP','Data Link Layer','Network Layer','Transport Layer','Application Layer']},
  {name:'Probability & Statistics',    code:'MA3451',dept:'CSE',sem:5,credits:4,type:'Theory',color:'#7c3aed',faculty:'Prof. E. Sathya',  syllabus:['Probability Theory','Random Variables','Sampling','Hypothesis Testing','Regression']},
  {name:'DS & Algorithms Lab',         code:'CS3411',dept:'CSE',sem:5,credits:2,type:'Lab',   color:'#be123c',faculty:'Prof. A. Kumar',   syllabus:['Stack & Queue Implementation','BST Operations','Graph Algorithms','Sorting Comparison','Hashing']},

  // IT
  {name:'Web Technology',              code:'IT3401',dept:'IT', sem:5,credits:4,type:'Theory',color:'#6375ff',faculty:'Prof. F. Nisha',   syllabus:['HTML5 & CSS3','JavaScript ES6','React.js','Node.js','REST APIs']},
  {name:'Software Engineering',        code:'IT3402',dept:'IT', sem:5,credits:3,type:'Theory',color:'#0891b2',faculty:'Prof. G. Senthil', syllabus:['SDLC Models','Agile & Scrum','Requirements Engineering','Software Testing','Project Management']},
  {name:'Database Management',         code:'IT3403',dept:'IT', sem:5,credits:3,type:'Theory',color:'#d97706',faculty:'Prof. H. Radha',   syllabus:['Relational Design','Advanced SQL','NoSQL','Database Security','Cloud DB']},
  {name:'Computer Networks',           code:'IT3404',dept:'IT', sem:5,credits:4,type:'Theory',color:'#059669',faculty:'Prof. I. Vijay',   syllabus:['Network Protocols','TCP/IP','Network Security','Wireless Networks','Cloud Networking']},
  {name:'Probability & Queueing',      code:'MA3452',dept:'IT', sem:5,credits:4,type:'Theory',color:'#7c3aed',faculty:'Prof. J. Rekha',   syllabus:['Probability Distributions','Stochastic Processes','Queueing Models','Simulation','SQC']},
  {name:'Web Technology Lab',          code:'IT3411',dept:'IT', sem:5,credits:2,type:'Lab',   color:'#be123c',faculty:'Prof. F. Nisha',   syllabus:['HTML/CSS Projects','JavaScript DOM','React Components','REST API','Full Stack Project']},

  // ECE
  {name:'Digital Signal Processing',   code:'EC3501',dept:'ECE',sem:5,credits:4,type:'Theory',color:'#6375ff',faculty:'Prof. K. Arjun',   syllabus:['DT Signals & Systems','Z-Transform & DFT','FIR Filter Design','IIR Filter Design','FFT Algorithms']},
  {name:'Microprocessors & Controllers',code:'EC3502',dept:'ECE',sem:5,credits:3,type:'Theory',color:'#0891b2',faculty:'Prof. L. Divya',   syllabus:['8086 Architecture','Assembly Language','Memory Interfacing','I/O Interfacing','ARM Cortex']},
  {name:'Electromagnetic Fields',      code:'EC3503',dept:'ECE',sem:5,credits:4,type:'Theory',color:'#d97706',faculty:'Prof. M. Krishna',  syllabus:['Vector Calculus','Electrostatics','Magnetostatics','EM Waves','Transmission Lines']},
  {name:'Communication Theory',        code:'EC3504',dept:'ECE',sem:5,credits:3,type:'Theory',color:'#059669',faculty:'Prof. N. Lakshmi',  syllabus:['AM & FM Modulation','Digital Modulation','Noise Analysis','Information Theory','Error Correction']},
  {name:'VLSI Design',                 code:'EC3505',dept:'ECE',sem:5,credits:4,type:'Theory',color:'#7c3aed',faculty:'Prof. O. Ganesh',   syllabus:['MOS Technology','CMOS Logic','Combinational Circuits','Sequential Circuits','Layout Rules']},
  {name:'DSP Lab',                     code:'EC3511',dept:'ECE',sem:5,credits:2,type:'Lab',   color:'#be123c',faculty:'Prof. K. Arjun',   syllabus:['MATLAB Signal Processing','FIR Filter','FFT Implementation','Audio Processing','Real-time DSP']},

  // EEE
  {name:'Power Systems Analysis',      code:'EE3501',dept:'EEE',sem:5,credits:4,type:'Theory',color:'#6375ff',faculty:'Prof. P. Rajan',   syllabus:['Power System Components','Load Flow Analysis','Fault Analysis','Stability','Protection']},
  {name:'Electrical Machines II',      code:'EE3502',dept:'EEE',sem:5,credits:3,type:'Theory',color:'#0891b2',faculty:'Prof. Q. Selvi',   syllabus:['Synchronous Generators','Synchronous Motors','3-Phase Induction Motors','Single Phase IM','Special Machines']},
  {name:'Control Systems',             code:'EE3503',dept:'EEE',sem:5,credits:4,type:'Theory',color:'#d97706',faculty:'Prof. R. Anand',   syllabus:['Transfer Functions','Block Diagram Algebra','Time Domain Analysis','Frequency Domain','State Space']},
  {name:'Power Electronics',           code:'EE3504',dept:'EEE',sem:5,credits:3,type:'Theory',color:'#059669',faculty:'Prof. S. Kavya',   syllabus:['Power Semiconductor Devices','Rectifiers','Inverters & Choppers','AC Voltage Controllers','SMPS']},
  {name:'Signals & Systems',           code:'EE3505',dept:'EEE',sem:5,credits:4,type:'Theory',color:'#7c3aed',faculty:'Prof. T. Babu',    syllabus:['Continuous & Discrete Signals','Fourier Series','Laplace Transform','Z-Transform','System Analysis']},
  {name:'Electrical Machines Lab',     code:'EE3511',dept:'EEE',sem:5,credits:2,type:'Lab',   color:'#be123c',faculty:'Prof. Q. Selvi',   syllabus:['DC Motor Characteristics','Induction Motor Testing','Synchronous Machine','Transformer Tests','Power Factor']},

  // MECH
  {name:'Heat & Mass Transfer',        code:'ME3501',dept:'MECH',sem:5,credits:4,type:'Theory',color:'#6375ff',faculty:'Prof. U. Sathish', syllabus:['Conduction','Convection','Radiation','Heat Exchangers','Mass Transfer']},
  {name:'Design of Machine Elements',  code:'ME3502',dept:'MECH',sem:5,credits:3,type:'Theory',color:'#0891b2',faculty:'Prof. V. Pradeep', syllabus:['Design Fundamentals','Shaft Design','Coupling & Clutch','Gear Design','Spring & Bearing']},
  {name:'Manufacturing Technology II', code:'ME3503',dept:'MECH',sem:5,credits:4,type:'Theory',color:'#d97706',faculty:'Prof. W. Natarajan',syllabus:['Metal Cutting','Lathe Operations','Milling & Drilling','CNC Machining','Advanced Manufacturing']},
  {name:'Fluid Mechanics & Machinery', code:'ME3504',dept:'MECH',sem:5,credits:3,type:'Theory',color:'#059669',faculty:'Prof. X. Murugesan',syllabus:['Fluid Properties','Bernoulli Equation','Flow Measurement','Centrifugal Pumps','Turbines']},
  {name:'Engineering Materials',       code:'ME3505',dept:'MECH',sem:5,credits:4,type:'Theory',color:'#7c3aed',faculty:'Prof. Y. Chandran', syllabus:['Crystal Structure','Iron-Carbon Diagram','Heat Treatment','Composites','Nanomaterials']},
  {name:'Manufacturing Lab',           code:'ME3511',dept:'MECH',sem:5,credits:2,type:'Lab',   color:'#be123c',faculty:'Prof. W. Natarajan',syllabus:['Lathe Practice','Milling','Welding','CNC Programming','Metrology']},

  // VLSI
  {name:'VLSI Design & Technology',    code:'VL3501',dept:'VLSI',sem:5,credits:4,type:'Theory',color:'#7c3aed',faculty:'Prof. A1. Senthil',syllabus:['MOS Device Physics','CMOS Inverter Design','Combinational VLSI','Sequential VLSI','Low Power Design']},
  {name:'Analog IC Design',            code:'VL3502',dept:'VLSI',sem:5,credits:3,type:'Theory',color:'#6375ff',faculty:'Prof. B1. Deepa',  syllabus:['Op-Amp Design','Differential Amplifiers','Current Mirrors','PLL Design','ADC/DAC Circuits']},
  {name:'FPGA & Embedded Systems',     code:'VL3503',dept:'VLSI',sem:5,credits:4,type:'Theory',color:'#0891b2',faculty:'Prof. C1. Ravi',   syllabus:['FPGA Architecture','VHDL Programming','Verilog HDL','RTL Design','SoC Design']},
  {name:'Physical Design & EDA',       code:'VL3504',dept:'VLSI',sem:5,credits:3,type:'Theory',color:'#d97706',faculty:'Prof. D1. Priya',  syllabus:['Floorplanning','Placement & Routing','Clock Tree Synthesis','Static Timing Analysis','DFT']},
  {name:'Testing & Verification',      code:'VL3505',dept:'VLSI',sem:5,credits:4,type:'Theory',color:'#059669',faculty:'Prof. E1. Kumar',  syllabus:['Fault Models','ATPG','Boundary Scan','Formal Verification','Functional Simulation']},
  {name:'VLSI Design Lab',             code:'VL3511',dept:'VLSI',sem:5,credits:2,type:'Lab',   color:'#be123c',faculty:'Prof. A1. Senthil',syllabus:['Cadence Virtuoso','Synopsys Design Compiler','Modelsim Simulation','Layout Design','FPGA Implementation']},

  // AIML
  {name:'Machine Learning',            code:'AI3501',dept:'AIML',sem:5,credits:4,type:'Theory',color:'#db2777',faculty:'Prof. F1. Divya',  syllabus:['Supervised Learning','Unsupervised Learning','Neural Networks','Decision Trees','Model Evaluation']},
  {name:'Deep Learning',               code:'AI3502',dept:'AIML',sem:5,credits:3,type:'Theory',color:'#7c3aed',faculty:'Prof. G1. Ramesh', syllabus:['CNN Architecture','RNN & LSTM','Transfer Learning','GANs','Transformer Models']},
  {name:'Natural Language Processing', code:'AI3503',dept:'AIML',sem:5,credits:4,type:'Theory',color:'#6375ff',faculty:'Prof. H1. Nisha',  syllabus:['Text Preprocessing','Word Embeddings','Sentiment Analysis','Named Entity Recognition','LLM Basics']},
  {name:'Computer Vision',             code:'AI3504',dept:'AIML',sem:5,credits:3,type:'Theory',color:'#0891b2',faculty:'Prof. I1. Vijay',  syllabus:['Image Processing','Object Detection','Image Segmentation','Face Recognition','YOLO & OpenCV']},
  {name:'AI Ethics & Applications',    code:'AI3505',dept:'AIML',sem:5,credits:4,type:'Theory',color:'#059669',faculty:'Prof. J1. Rekha',  syllabus:['AI Ethics','Bias & Fairness','Explainable AI','AI in Healthcare','AI in Industry 4.0']},
  {name:'ML Lab (Python/TensorFlow)',  code:'AI3511',dept:'AIML',sem:5,credits:2,type:'Lab',   color:'#be123c',faculty:'Prof. F1. Divya',  syllabus:['Python ML Libraries','Sklearn Pipelines','TensorFlow/Keras','PyTorch Basics','Real-world ML Project']},

  // Cyber Security
  {name:'Network Security',            code:'CY3501',dept:'CYS', sem:5,credits:4,type:'Theory',color:'#dc2626',faculty:'Prof. K1. Arjun',  syllabus:['Network Attacks','Firewalls & IDS','VPN & Tunneling','Wireless Security','Cloud Security']},
  {name:'Cryptography',                code:'CY3502',dept:'CYS', sem:5,credits:3,type:'Theory',color:'#7c3aed',faculty:'Prof. L1. Selvi',  syllabus:['Symmetric Encryption','Asymmetric Encryption','Hash Functions','Digital Signatures','PKI']},
  {name:'Ethical Hacking & Pen Testing',code:'CY3503',dept:'CYS',sem:5,credits:4,type:'Theory',color:'#6375ff',faculty:'Prof. M1. Anand', syllabus:['Reconnaissance','Scanning & Enumeration','Exploitation','Post Exploitation','Reporting']},
  {name:'Digital Forensics',           code:'CY3504',dept:'CYS', sem:5,credits:3,type:'Theory',color:'#0891b2',faculty:'Prof. N1. Kavya',  syllabus:['Forensic Investigation','Disk Analysis','Memory Forensics','Network Forensics','Evidence Collection']},
  {name:'Malware Analysis & Reverse Engineering',code:'CY3505',dept:'CYS',sem:5,credits:4,type:'Theory',color:'#059669',faculty:'Prof. O1. Babu',syllabus:['Static Analysis','Dynamic Analysis','Assembly Basics','Disassemblers','Malware Types & Behavior']},
  {name:'Cybersecurity Lab',           code:'CY3511',dept:'CYS', sem:5,credits:2,type:'Lab',   color:'#be123c',faculty:'Prof. K1. Arjun',  syllabus:['Kali Linux','Metasploit','Wireshark','Nmap Scanning','CTF Challenges']},

  // Biotechnology
  {name:'Molecular Biology',           code:'BT3501',dept:'BIO', sem:5,credits:4,type:'Theory',color:'#16a34a',faculty:'Prof. P1. Preethi',syllabus:['DNA Structure & Replication','Transcription & Translation','Gene Regulation','Mutations','Recombinant DNA Technology']},
  {name:'Genetic Engineering',         code:'BT3502',dept:'BIO', sem:5,credits:3,type:'Theory',color:'#0891b2',faculty:'Prof. Q1. Saranya',syllabus:['Restriction Enzymes','Cloning Vectors','Gene Expression Systems','CRISPR-Cas9','Gene Therapy']},
  {name:'Biochemistry',                code:'BT3503',dept:'BIO', sem:5,credits:4,type:'Theory',color:'#d97706',faculty:'Prof. R1. Ramesh', syllabus:['Proteins & Enzymes','Carbohydrate Metabolism','Lipid Metabolism','Vitamins & Coenzymes','Metabolic Pathways']},
  {name:'Bioprocess Technology',       code:'BT3504',dept:'BIO', sem:5,credits:3,type:'Theory',color:'#7c3aed',faculty:'Prof. S1. Kavya',  syllabus:['Fermentation Technology','Bioreactor Design','Downstream Processing','Enzyme Technology','Industrial Biotechnology']},
  {name:'Immunology',                  code:'BT3505',dept:'BIO', sem:5,credits:4,type:'Theory',color:'#059669',faculty:'Prof. T1. Babu',   syllabus:['Innate Immunity','Adaptive Immunity','Antibodies','Vaccines','Immunological Disorders']},
  {name:'Biotech Lab',                 code:'BT3511',dept:'BIO', sem:5,credits:2,type:'Lab',   color:'#be123c',faculty:'Prof. P1. Preethi',syllabus:['PCR Techniques','Gel Electrophoresis','Cell Culture','ELISA Assay','Protein Extraction']},

  // Biomedical Engineering
  {name:'Medical Instrumentation',     code:'BM3501',dept:'BME', sem:5,credits:4,type:'Theory',color:'#0d9488',faculty:'Prof. U1. Sathish',syllabus:['ECG & EEG Instruments','Blood Pressure Measurement','Patient Monitoring Systems','Therapeutic Devices','Imaging Systems']},
  {name:'Biomechanics',                code:'BM3502',dept:'BME', sem:5,credits:3,type:'Theory',color:'#6375ff',faculty:'Prof. V1. Pradeep',syllabus:['Mechanics of Human Body','Gait Analysis','Joint Biomechanics','Orthopedic Implants','Prosthetic Design']},
  {name:'Digital Signal Processing (Bio)',code:'BM3503',dept:'BME',sem:5,credits:4,type:'Theory',color:'#0891b2',faculty:'Prof. W1. Natarajan',syllabus:['Biomedical Signals','ECG Signal Processing','EEG Analysis','EMG Processing','Noise Filtering']},
  {name:'Medical Imaging',             code:'BM3504',dept:'BME', sem:5,credits:3,type:'Theory',color:'#d97706',faculty:'Prof. X1. Murugesan',syllabus:['X-Ray Imaging','CT Scan Principles','MRI Physics','Ultrasound Imaging','Nuclear Imaging']},
  {name:'Tissue Engineering',          code:'BM3505',dept:'BME', sem:5,credits:4,type:'Theory',color:'#7c3aed',faculty:'Prof. Y1. Chandran',syllabus:['Scaffolds','Stem Cell Biology','3D Bioprinting','Organ-on-Chip','Clinical Applications']},
  {name:'Biomedical Lab',              code:'BM3511',dept:'BME', sem:5,credits:2,type:'Lab',   color:'#be123c',faculty:'Prof. U1. Sathish',syllabus:['ECG Recording & Analysis','Patient Monitor Calibration','PCB Design for Medical','Biosignal Processing','Imaging Lab']},

  // IoT
  {name:'IoT Architecture & Protocols',code:'IO3501',dept:'IOT', sem:5,credits:4,type:'Theory',color:'#0284c7',faculty:'Prof. Z1. Rajan',  syllabus:['IoT Architecture','MQTT & CoAP','LoRaWAN','Zigbee & Z-Wave','IPv6 for IoT']},
  {name:'Embedded Systems for IoT',   code:'IO3502',dept:'IOT', sem:5,credits:3,type:'Theory',color:'#7c3aed',faculty:'Prof. A2. Selvi',  syllabus:['Arduino & ESP8266','Raspberry Pi','FreeRTOS','Edge Computing','Sensor Interfacing']},
  {name:'Cloud Computing for IoT',    code:'IO3503',dept:'IOT', sem:5,credits:4,type:'Theory',color:'#6375ff',faculty:'Prof. B2. Anand',  syllabus:['AWS IoT','Azure IoT Hub','Google Cloud IoT','Edge-Cloud Integration','Data Management']},
  {name:'IoT Security',               code:'IO3504',dept:'IOT', sem:5,credits:3,type:'Theory',color:'#dc2626',faculty:'Prof. C2. Kavya',  syllabus:['IoT Threat Landscape','Authentication & Authorization','Secure Boot','Encryption for IoT','Vulnerability Assessment']},
  {name:'IoT Applications',           code:'IO3505',dept:'IOT', sem:5,credits:4,type:'Theory',color:'#059669',faculty:'Prof. D2. Babu',   syllabus:['Smart Home Systems','Industrial IoT','Healthcare IoT','Smart Agriculture','Smart City Applications']},
  {name:'IoT Lab',                    code:'IO3511',dept:'IOT', sem:5,credits:2,type:'Lab',   color:'#be123c',faculty:'Prof. Z1. Rajan',  syllabus:['Arduino Projects','Raspberry Pi Projects','MQTT Dashboard','Cloud Integration','IoT End-to-End Project']},

  // Data Science
  {name:'Statistical Learning',       code:'DS3501',dept:'DSC', sem:5,credits:4,type:'Theory',color:'#0891b2',faculty:'Prof. E2. Nisha',  syllabus:['Regression Analysis','Classification','Clustering','Dimensionality Reduction','Model Selection']},
  {name:'Big Data Analytics',         code:'DS3502',dept:'DSC', sem:5,credits:3,type:'Theory',color:'#7c3aed',faculty:'Prof. F2. Vijay',  syllabus:['Hadoop MapReduce','Apache Spark','Hive & Pig','Data Lakes','Real-time Analytics']},
  {name:'Data Visualization',         code:'DS3503',dept:'DSC', sem:5,credits:4,type:'Theory',color:'#6375ff',faculty:'Prof. G2. Rekha',  syllabus:['Matplotlib & Seaborn','Tableau','Power BI','D3.js','Dashboard Design Principles']},
  {name:'Database Systems',           code:'DS3504',dept:'DSC', sem:5,credits:3,type:'Theory',color:'#d97706',faculty:'Prof. H2. Arjun',  syllabus:['Relational DB','NoSQL MongoDB','Graph DB Neo4j','Time Series DB','Data Warehousing']},
  {name:'Business Intelligence',      code:'DS3505',dept:'DSC', sem:5,credits:4,type:'Theory',color:'#059669',faculty:'Prof. I2. Kumar',  syllabus:['OLAP & OLTP','ETL Pipelines','KPI & Metrics','Predictive Analytics','BI Tools']},
  {name:'Data Science Lab (Python)',  code:'DS3511',dept:'DSC', sem:5,credits:2,type:'Lab',   color:'#be123c',faculty:'Prof. E2. Nisha',  syllabus:['Pandas & NumPy','EDA Projects','Sklearn ML Pipelines','Data Visualization Project','Capstone Analytics Project']},
];
module.exports = SUBJECTS;
