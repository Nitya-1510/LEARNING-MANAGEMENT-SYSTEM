const DEPARTMENTS = [
  // Engineering
  { name:'Computer Science & Engineering',          code:'CSE',  shortName:'CSE',  color:'#6375ff', icon:'💻', hod:'Dr. R. Kavitha',  totalStudents:240, category:'Engineering'  },
  { name:'Information Technology',                  code:'IT',   shortName:'IT',   color:'#0891b2', icon:'🌐', hod:'Dr. S. Priya',    totalStudents:180, category:'Engineering'  },
  { name:'Electronics & Communication Engineering', code:'ECE',  shortName:'ECE',  color:'#d97706', icon:'📡', hod:'Dr. P. Ramesh',   totalStudents:200, category:'Engineering'  },
  { name:'Electrical & Electronics Engineering',    code:'EEE',  shortName:'EEE',  color:'#059669', icon:'⚡', hod:'Dr. K. Murugan',  totalStudents:160, category:'Engineering'  },
  { name:'Mechanical Engineering',                  code:'MECH', shortName:'MECH', color:'#be123c', icon:'⚙️', hod:'Dr. V. Suresh',   totalStudents:220, category:'Engineering'  },
  { name:'Civil Engineering',                       code:'CIVIL',shortName:'CIVIL',color:'#92400e', icon:'🏗️', hod:'Dr. T. Anand',    totalStudents:160, category:'Engineering'  },
  { name:'Chemical Engineering',                    code:'CHEM', shortName:'CHEM', color:'#065f46', icon:'🧪', hod:'Dr. M. Lakshmi',  totalStudents:120, category:'Engineering'  },
  { name:'Aerospace Engineering',                   code:'AERO', shortName:'AERO', color:'#1e3a8a', icon:'✈️', hod:'Dr. N. Karthik',  totalStudents:100, category:'Engineering'  },
  // Specialised
  { name:'VLSI Design',                             code:'VLSI', shortName:'VLSI', color:'#7c3aed', icon:'🔬', hod:'Dr. A. Senthil',  totalStudents:60,  category:'Specialised'  },
  { name:'Artificial Intelligence & ML',            code:'AIML', shortName:'AIML', color:'#db2777', icon:'🤖', hod:'Dr. B. Divya',    totalStudents:120, category:'Specialised'  },
  { name:'Cyber Security',                          code:'CYS',  shortName:'CyS',  color:'#dc2626', icon:'🔐', hod:'Dr. C. Vijay',    totalStudents:80,  category:'Specialised'  },
  { name:'Internet of Things',                      code:'IOT',  shortName:'IoT',  color:'#0284c7', icon:'📶', hod:'Dr. D. Meena',    totalStudents:60,  category:'Specialised'  },
  { name:'Robotics & Automation',                   code:'ROB',  shortName:'ROB',  color:'#ea580c', icon:'🦾', hod:'Dr. E. Suresh',   totalStudents:60,  category:'Specialised'  },
  { name:'Data Science',                            code:'DSC',  shortName:'DS',   color:'#0891b2', icon:'📊', hod:'Dr. F. Nisha',    totalStudents:100, category:'Specialised'  },
  // Science
  { name:'Biotechnology',                           code:'BIO',  shortName:'BIO',  color:'#16a34a', icon:'🧬', hod:'Dr. G. Preethi',  totalStudents:80,  category:'Science'      },
  { name:'Biomedical Engineering',                  code:'BME',  shortName:'BME',  color:'#0d9488', icon:'🏥', hod:'Dr. H. Saranya',  totalStudents:60,  category:'Science'      },
  { name:'Physics',                                 code:'PHY',  shortName:'PHY',  color:'#4338ca', icon:'⚛️', hod:'Dr. I. Ramesh',   totalStudents:60,  category:'Science'      },
  { name:'Mathematics',                             code:'MATH', shortName:'MATH', color:'#0369a1', icon:'📐', hod:'Dr. J. Kavya',    totalStudents:60,  category:'Science'      },
  // Management
  { name:'Master of Business Administration',       code:'MBA',  shortName:'MBA',  color:'#b45309', icon:'📈', hod:'Dr. K. Arjun',    totalStudents:120, category:'Management'   },
  { name:'Master of Computer Applications',         code:'MCA',  shortName:'MCA',  color:'#6d28d9', icon:'🖥️', hod:'Dr. L. Rekha',    totalStudents:60,  category:'Management'   },
];
module.exports = DEPARTMENTS;
