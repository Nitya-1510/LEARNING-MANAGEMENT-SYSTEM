# 🎓 EduSync Backend API

> REST API for EduSync Academic Portal — Node.js + Express + MongoDB

---

## 🚀 Quick Start

```bash
npm install
node seed.js     # Seed database with sample data
npm run dev      # Start server with auto-reload
```

Server runs at → **http://localhost:5000**

---

## 📡 API Endpoints

| Method | Route | Description | Auth |
|--------|-------|-------------|------|
| POST | /api/auth/register | Register new user | ❌ |
| POST | /api/auth/login | Login user | ❌ |
| GET | /api/auth/me | Get current user | ✅ |
| GET | /api/assignments | Get all assignments | ✅ |
| POST | /api/assignments | Create assignment | Admin |
| GET | /api/internships | Get internships | ✅ |
| POST | /api/internships | Add internship | Admin |
| GET | /api/placements | Get companies | ✅ |
| GET | /api/nptel | Get NPTEL courses | ✅ |
| GET | /api/notes | Get user notes | ✅ |
| POST | /api/notes | Create note | ✅ |
| GET | /api/reminders | Get reminders | ✅ |
| POST | /api/reminders | Create reminder | ✅ |
| GET | /api/exams | Get exam schedule | ✅ |
| GET | /api/events | Get events | ✅ |
| GET | /api/announcements | Get announcements | ✅ |
| POST | /api/announcements | Post announcement | Admin |

---

## 🔑 Demo Credentials

| Role | Email | Password |
|------|-------|----------|
| Admin | akshayadarshini.n@gmail.com | aksh@2006 |
| Student | harivignesh@gmail.com | hari@1111 |
